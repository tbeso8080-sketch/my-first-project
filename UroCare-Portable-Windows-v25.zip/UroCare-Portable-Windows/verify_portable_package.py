#!/usr/bin/env python3
"""Create or verify integrity hashes for a UroCare portable Windows package."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path, PurePosixPath


MANIFEST_NAME = "UroCare-Portable-Manifest.json"
MANIFEST_FORMAT = 1


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def package_files(root: Path):
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root)
        if "__pycache__" in relative.parts or path.suffix.casefold() == ".pyc":
            continue
        if path.is_symlink():
            raise ValueError(f"Symbolic links are not allowed in the package: {relative}")
        if not path.is_file():
            continue
        if relative.as_posix() == MANIFEST_NAME or relative.parts[0].casefold() == "data":
            continue
        yield relative, path


def create_manifest(root: Path) -> Path:
    entries = [
        {"path": relative.as_posix(), "length": path.stat().st_size, "sha256": sha256(path)}
        for relative, path in package_files(root)
    ]
    if not entries:
        raise ValueError("No package files found")
    target = root / MANIFEST_NAME
    target.write_text(
        json.dumps({"app": "UroCare Portable Windows", "format": MANIFEST_FORMAT, "files": entries},
                   ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return target


def verify_manifest(root: Path) -> list[str]:
    manifest_path = root / MANIFEST_NAME
    if not manifest_path.is_file():
        return [f"{MANIFEST_NAME} is missing"]
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        return [f"Cannot read manifest: {exc}"]
    if not isinstance(manifest, dict) or manifest.get("app") != "UroCare Portable Windows" or manifest.get("format") != MANIFEST_FORMAT:
        return ["Manifest format is invalid"]
    entries = manifest.get("files")
    if not isinstance(entries, list) or not entries:
        return ["Manifest file list is empty or invalid"]

    errors: list[str] = []
    listed: set[str] = set()
    for entry in entries:
        if not isinstance(entry, dict):
            errors.append("Invalid manifest entry")
            continue
        name = entry.get("path")
        if not isinstance(name, str) or not name or "\\" in name:
            errors.append(f"Invalid manifest path: {name!r}")
            continue
        relative = PurePosixPath(name)
        if relative.is_absolute() or "." in relative.parts or ".." in relative.parts or not relative.parts or any(":" in part for part in relative.parts):
            errors.append(f"Unsafe manifest path: {name!r}")
            continue
        if relative.parts[0].casefold() == "data" or relative.as_posix() == MANIFEST_NAME:
            errors.append(f"Mutable or reserved path in manifest: {name}")
            continue
        key = relative.as_posix()
        if key in listed:
            errors.append(f"Duplicate manifest path: {key}")
            continue
        listed.add(key)
        target = root.joinpath(*relative.parts)
        try:
            target.resolve().relative_to(root.resolve())
        except (OSError, ValueError):
            errors.append(f"Manifest path escapes package: {key}")
            continue
        if not target.is_file() or target.is_symlink():
            errors.append(f"Missing or invalid file: {key}")
            continue
        if not isinstance(entry.get("length"), int) or target.stat().st_size != entry["length"]:
            errors.append(f"File size changed: {key}")
            continue
        expected_hash = entry.get("sha256")
        if not isinstance(expected_hash, str) or len(expected_hash) != 64 or sha256(target) != expected_hash.lower():
            errors.append(f"File hash changed: {key}")

    try:
        actual = {relative.as_posix() for relative, _path in package_files(root)}
    except (OSError, ValueError) as exc:
        errors.append(str(exc))
        actual = set()
    for key in sorted(actual - listed):
        errors.append(f"Unlisted package file: {key}")
    for key in sorted(listed - actual):
        errors.append(f"Manifest file is unavailable: {key}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify UroCare portable package file integrity")
    parser.add_argument("package", type=Path, help="Extracted package directory")
    parser.add_argument("--create", action="store_true", help="Create or refresh the package manifest")
    args = parser.parse_args()
    root = args.package.resolve()
    if not root.is_dir():
        print("Package directory does not exist")
        return 2
    try:
        if args.create:
            print(f"Created {create_manifest(root).name}")
            return 0
        errors = verify_manifest(root)
    except (OSError, ValueError) as exc:
        print(f"Integrity check failed: {exc}")
        return 2
    if errors:
        print("Integrity check failed:")
        for error in errors:
            print(f"- {error}")
        return 2
    print("Package files match the integrity manifest.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
