﻿param(
    [Parameter(Mandatory = $true)]
    [string]$CertificatePath
)

$ErrorActionPreference = 'Stop'
$resolvedCertificate = (Resolve-Path -LiteralPath $CertificatePath -ErrorAction Stop).Path
$certificate = [System.Security.Cryptography.X509Certificates.X509Certificate2]::new($resolvedCertificate)
if ($certificate.Subject -ne 'CN=UroCare Local Trust CA') {
    throw 'هذه ليست شهادة الثقة المحلية المتوقعة لبرنامج UroCare.'
}
$basicConstraints = $certificate.Extensions | Where-Object { $_.Oid.Value -eq '2.5.29.19' } | Select-Object -First 1
if (-not $basicConstraints) { throw 'الشهادة لا تحتوي على خصائص CA.' }
$constraints = [System.Security.Cryptography.X509Certificates.X509BasicConstraintsExtension]::new($basicConstraints, $basicConstraints.Critical)
if (-not $constraints.CertificateAuthority) { throw 'الشهادة المحددة ليست جهة إصدار شهادات.' }

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$windowsPrincipal = [Security.Principal.WindowsPrincipal]::new($identity)
if (-not $windowsPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'شغّل PowerShell بصلاحية المسؤول لإضافة الشهادة إلى مخزن الجهاز.'
}

$fingerprint = (Get-FileHash -LiteralPath $resolvedCertificate -Algorithm SHA256).Hash.ToUpperInvariant()
Write-Host "بصمة شهادة UroCare (SHA-256): $fingerprint" -ForegroundColor Cyan
$expected = (Read-Host 'اكتب البصمة كاملة بعد مطابقتها مع مسؤول السيرفر').Replace(':', '').Replace(' ', '').ToUpperInvariant()
if ($expected -cne $fingerprint) { throw 'البصمة غير متطابقة؛ لم تتم إضافة الشهادة.' }

& certutil.exe -addstore -f Root $resolvedCertificate | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'تعذر إضافة شهادة UroCare إلى مخزن الثقة المحلي.' }
Write-Host 'تم تثبيت شهادة الثقة. افتح عنوان HTTPS الذي أعطاك مسؤول السيرفر.' -ForegroundColor Green
