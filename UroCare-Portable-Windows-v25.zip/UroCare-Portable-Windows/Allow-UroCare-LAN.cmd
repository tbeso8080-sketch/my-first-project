@echo off
setlocal EnableExtensions
fltmc >nul 2>&1
if errorlevel 1 (
  echo Right-click this file and choose Run as administrator once to add the firewall rule.
  pause
  exit /b 5
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "New-NetFirewallRule -DisplayName 'UroCare Suite LAN' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 8765 -Profile Private -RemoteAddress LocalSubnet -ErrorAction Stop | Out-Null"
if errorlevel 1 (
  echo Could not add the Private-network firewall rule.
  pause
  exit /b 6
)
echo UroCare LAN access is allowed on the Windows Private network only.
echo Start the server with Start-UroCare-Network.cmd.
pause
endlocal
