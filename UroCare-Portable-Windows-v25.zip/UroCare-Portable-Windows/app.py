#!/usr/bin/env python3
"""UroCare Suite local-first application server (Python standard library + cryptography)."""
from __future__ import annotations

import base64
import binascii
import csv
import hashlib
import hmac
import html
import ipaddress
import io
import json
import mimetypes
import os
import secrets
import shutil
import socket
import sqlite3
import ssl
import struct
import sys
import tempfile
import threading
import time
import urllib.parse
import uuid
import zipfile
import xml.etree.ElementTree as ET
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
from email import policy
from email.parser import BytesParser
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

try:
    from cryptography import x509
    from cryptography.fernet import Fernet, InvalidToken
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID
except ImportError:  # App can open without the optional backup feature in development.
    Fernet = None
    InvalidToken = Exception
    x509 = None
    hashes = serialization = rsa = ExtendedKeyUsageOID = NameOID = None


APP_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
DATA_DIR = Path(os.environ.get("UROCARE_DATA_DIR", APP_DIR / "data")).resolve()
UPLOAD_DIR = DATA_DIR / "uploads"
BACKUP_DIR = DATA_DIR / "backups"
DB_PATH = DATA_DIR / "urocare.sqlite3"
KEY_PATH = DATA_DIR / "backup.key"
PORT = int(os.environ.get("UROCARE_PORT", "8765"))
HOST_OVERRIDE = os.environ.get("UROCARE_HOST")
SESSION_COOKIE_SECONDS = 30 * 24 * 60 * 60
MAX_JSON_BYTES = 16 * 1024 * 1024
DB_LOCK = threading.RLock()
SETUP_LOCK = threading.Lock()
BACKUP_LOCK = threading.Lock()
LOGIN_ATTEMPTS: dict[str, list[float]] = {}
LOGIN_ACCOUNT_ATTEMPTS: dict[str, list[float]] = {}
SENSITIVE_READ_LAST: dict[tuple[str, str], float] = {}
SYSTEM_ALERT_SEVERITIES = {"warning", "critical"}

OWNER = "OWNER_SUPER_ADMIN"
ANNOUNCEMENT_TYPES = {"holiday", "occasion", "notice"}
PREPARATION_CHECKLIST_DEFAULTS = [
    "تأكيد هوية المريض والملف",
    "التحقق من الموافقة والمستندات المطلوبة حسب سياسة المنشأة",
    "تأكيد الإجراء والجهة مع الفريق المختص",
    "مراجعة تعليمات التحضير المعتمدة للحالة",
    "استكمال التقييمات والنتائج المطلوبة حسب بروتوكول القسم",
    "تجهيز الغرفة والأدوات المطلوبة",
    "تأكيد الفريق والموعد ومكان الإجراء",
    "تأكيد الموافقة المستنيرة والمستندات المطلوبة",
    "مراجعة الصيام وتعليمات التحضير",
    "مراجعة أدوية السيولة وخطة الإيقاف أو الاستمرار",
    "مراجعة تقييم التخدير ومخاطر التخدير",
    "مراجعة وظائف الكلى والتحاليل المطلوبة",
    "تحديد خطة المضاد الحيوي الوقائي حسب بروتوكول المنشأة",
    "تأكيد الجهة والإجراء مرة أخيرة قبل البدء",
    "تسجيل خطة الإفاقة والخروج والمتابعة بعد الإجراء",
]
ROLE_LABELS = {
    OWNER: "مالك النظام",
    "ADMIN": "مدير النظام",
    "DOCTOR": "طبيب",
    "NURSE": "تمريض",
    "RECEPTION": "استقبال",
    "ER_STAFF": "فريق الطوارئ",
    "PROCEDURE_COORDINATOR": "منسق العمليات والمناظير",
    "ANESTHESIA": "تخدير",
    "BILLING": "حسابات",
    "AUDITOR_VIEWER": "مدقق / مشاهدة",
    "VIEWER": "مشاهد",
    "ADMISSIONS_CLERK": "موظف الدخول والخروج",
    "LAB_TECHNICIAN": "فني معمل",
    "LAB_REVIEWER": "مراجع نتائج المعمل",
    "RADIOLOGY_TECHNICIAN": "فني أشعة",
    "PHARMACIST": "صيدلي",
    "OR_NURSE": "تمريض العمليات",
    "MEDICAL_RECORDS": "السجلات الطبية",
    "QUALITY_OFFICER": "مسؤول الجودة وسلامة المرضى",
    "BLOOD_BANK": "فني بنك الدم",
}

ALL_KINDS = {
    "patients", "encounters", "appointments", "waiting", "procedures",
    "rooms", "beds", "triage", "packages", "invoices", "lookups",
    "attachments", "prescriptions", "lab_results", "imaging", "stones", "doctors", "devices", "specimens", "sterilization", "maintenance", "inventory", "inventory_movements", "complaints", "training",
    "admissions", "lab_orders", "imaging_orders", "nursing_notes", "nursing_observations", "medication_administrations",
    "surgical_safety", "consents", "referrals", "care_tasks", "clinical_templates",
    "problem_list", "allergies", "formulary", "drug_interactions", "blood_requests", "insurance_claims", "quality_events",
}
PERMISSION_KINDS = ALL_KINDS | {"users", "roles", "settings", "backups", "audit", "messages", "announcements", "customization", "storage", "system"}
PERMISSION_ACTIONS = {
    "view", "create", "update", "archive", "report", "print", "sign", "break_glass",
    "verify", "approve", "cancel", "assign", "transfer", "discharge", "export", "import",
    "download", "restore", "override", "reopen", "administer", "dispense", "order", "result", "merge",
    "receive", "reject", "schedule", "manage", "submit", "close",
}
EGYPTIAN_GOVERNORATE_CODES = {
    "01": "القاهرة", "02": "الإسكندرية", "03": "بورسعيد", "04": "السويس",
    "11": "دمياط", "12": "الدقهلية", "13": "الشرقية", "14": "القليوبية",
    "15": "كفر الشيخ", "16": "الغربية", "17": "المنوفية", "18": "البحيرة",
    "19": "الإسماعيلية", "21": "الجيزة", "22": "بني سويف", "23": "الفيوم",
    "24": "المنيا", "25": "أسيوط", "26": "سوهاج", "27": "قنا",
    "28": "أسوان", "29": "الأقصر", "31": "البحر الأحمر", "32": "الوادي الجديد",
    "33": "مطروح", "34": "شمال سيناء", "35": "جنوب سيناء", "88": "خارج الجمهورية",
}
PATIENT_NATIONALITIES = {"مصري", "أجنبي"}
FOREIGN_DOCUMENT_TYPES = {"جواز سفر", "إقامة", "وثيقة أخرى"}
PRINTABLE_KINDS = {
    "patients", "encounters", "appointments", "waiting", "procedures",
    "triage", "invoices", "devices", "specimens", "sterilization", "maintenance", "inventory", "inventory_movements", "complaints", "training",
    "admissions", "lab_orders", "imaging_orders", "nursing_notes", "nursing_observations", "medication_administrations", "surgical_safety", "consents", "referrals", "care_tasks", "prescriptions",
    "problem_list", "allergies", "formulary", "drug_interactions", "blood_requests", "insurance_claims", "quality_events",
}
LOOKUP_CATEGORIES = {
    "gender", "blood_group", "appointment_type", "appointment_status", "encounter_type", "encounter_status",
    "waiting_priority", "waiting_status", "procedure_category", "procedure_status", "side", "triage_level",
    "triage_status", "room_type", "room_status", "bed_status", "active_status", "invoice_status",
    "lab_type", "imaging_type", "stone_location", "stone_type", "device_type", "device_status",
    "specimen_type", "specimen_status", "legacy",
}
CLINICAL_KINDS = {
    "encounters", "procedures", "triage", "prescriptions", "lab_results",
    "imaging", "stones", "attachments", "devices", "specimens", "admissions", "lab_orders", "imaging_orders", "nursing_notes", "nursing_observations",
    "medication_administrations", "surgical_safety", "consents", "referrals", "care_tasks", "problem_list", "allergies", "blood_requests", "quality_events",
}
PATIENT_LINKED_KINDS = {
    "encounters", "appointments", "waiting", "procedures", "triage", "prescriptions", "lab_results", "imaging", "stones", "attachments", "devices", "specimens",
    "admissions", "lab_orders", "imaging_orders", "nursing_notes", "nursing_observations", "medication_administrations", "surgical_safety", "consents", "referrals", "care_tasks",
    "problem_list", "allergies", "blood_requests", "insurance_claims", "quality_events",
}
PATIENT_REQUIRED_KINDS = {
    "admissions", "lab_orders", "imaging_orders", "nursing_notes", "nursing_observations", "medication_administrations", "prescriptions", "surgical_safety", "consents", "referrals", "problem_list", "allergies", "blood_requests", "insurance_claims", "quality_events",
}
CLINICAL_FIELDS = {
    "allergies", "chronic_diseases", "medical_history", "surgical_history",
    "family_history", "complaints", "examination", "diagnosis", "plan",
    "findings", "complications", "pre_diag", "post_diag", "discharge_summary",
    "clinical_notes", "prescriptions", "lab_results", "imaging", "asa_score",
    "anesthesia_assessment", "operative_note", "stone_details", "side",
    "consent_status", "fasting_status", "anticoagulants_reviewed", "renal_function_reviewed",
    "antibiotic_plan", "post_op_plan", "discharge_instructions", "followup_at", "discharge_status",
}
SIGNABLE_KINDS = {"encounters", "procedures", "triage", "prescriptions", "lab_results", "imaging", "stones", "devices", "specimens", "admissions", "lab_orders", "imaging_orders", "nursing_notes", "nursing_observations", "medication_administrations", "surgical_safety", "consents", "referrals", "care_tasks", "problem_list", "allergies", "blood_requests", "quality_events"}
EMERGENCY_ACCESS_KINDS = {"patients", "encounters", "procedures", "triage", "admissions", "nursing_notes", "nursing_observations"}
NURSE_UPDATE_FIELDS = {"status", "vitals", "triage_level", "notes", "bed_status", "nursing_notes", "nursing_observations", "observed_at", "recorded_by", "temperature", "pulse", "respiratory_rate", "systolic", "diastolic", "spo2", "pain_score", "consciousness", "oxygen_support", "note", "removed_at", "preparation_checklist"}
PATIENT_PUBLIC_FIELDS = {
    "file_code", "name_ar", "name_en", "nationality", "nationality_country", "national_id",
    "identity_document_type", "identity_document_no", "gender", "dob", "phone", "address",
    "emergency_contact", "blood_group", "status",
    "contact_preference", "communication_consent", "consent_at",
}
RECEPTION_FIELD_SCOPE = {
    "patients": PATIENT_PUBLIC_FIELDS,
    "appointments": {"patient_id", "patient_name", "type", "scheduled_at", "doctor", "room", "duration_min", "status", "cancel_reason"},
    "waiting": {"patient_id", "patient_name", "encounter_type", "procedure_type", "priority", "requested_at", "expected_days", "status", "priority_change_reason", "cancel_reason"},
    "encounters": {"patient_id", "patient_name", "encounter_type", "visit_type", "admitted_at", "status", "attending_doctor", "referral_source"},
}
PATIENT_CLINICAL_ROLES = {OWNER, "ADMIN", "DOCTOR", "NURSE", "ER_STAFF", "PROCEDURE_COORDINATOR", "ANESTHESIA"}
ROLE_FIELD_SCOPES = {
    "ADMISSIONS_CLERK": {"patients": PATIENT_PUBLIC_FIELDS},
    "LAB_TECHNICIAN": {"patients": PATIENT_PUBLIC_FIELDS},
    "LAB_REVIEWER": {"patients": PATIENT_PUBLIC_FIELDS},
    "RADIOLOGY_TECHNICIAN": {"patients": PATIENT_PUBLIC_FIELDS},
    "PHARMACIST": {"patients": PATIENT_PUBLIC_FIELDS},
    "OR_NURSE": {"patients": PATIENT_PUBLIC_FIELDS},
    "MEDICAL_RECORDS": {"patients": PATIENT_PUBLIC_FIELDS},
    "QUALITY_OFFICER": {"patients": PATIENT_PUBLIC_FIELDS},
}
BILLING_ENCOUNTER_FIELDS = {
    "patient_id", "patient_name", "encounter_type", "visit_type", "admitted_at",
    "discharged_at", "attending_doctor", "status", "referral_source",
}

ROLE_PERMISSIONS: dict[str, dict[str, set[str]]] = {
    OWNER: {"*": {"*"}},
    "ADMIN": {"*": {"*"}},
    "DOCTOR": {
        "patients": {"view", "create", "update", "archive", "report", "print", "break_glass"},
        "encounters": {"view", "create", "update", "archive", "print", "sign", "break_glass"},
        "appointments": {"view", "create", "update", "archive", "print"},
        "waiting": {"view", "create", "update", "archive", "print"},
        "procedures": {"view", "create", "update", "archive", "print", "sign", "break_glass"},
        "triage": {"view", "create", "update", "print", "sign", "break_glass"},
        "prescriptions": {"view", "create", "update", "sign"},
        "lab_results": {"view", "create", "update", "sign"},
        "imaging": {"view", "create", "update", "sign"},
        "stones": {"view", "create", "update", "sign"},
        "devices": {"view", "create", "update", "print", "sign"}, "specimens": {"view", "create", "update", "print", "sign"},
        "attachments": {"view", "create"},
        "rooms": {"view"}, "beds": {"view"}, "lookups": {"view"}, "doctors": {"view"},
    },
    "NURSE": {
        "patients": {"view", "update"}, "encounters": {"view", "update"},
        "appointments": {"view"}, "waiting": {"view"},
        "procedures": {"view", "update"}, "triage": {"view", "create", "update"},
        "devices": {"view", "update"}, "specimens": {"view", "update"},
        "rooms": {"view"}, "beds": {"view", "update"},
        "attachments": {"view", "create"}, "lookups": {"view"}, "doctors": {"view"},
    },
    "RECEPTION": {
        "patients": {"view", "create", "update"},
        "appointments": {"view", "create", "update", "archive", "print"},
        "waiting": {"view", "create", "update", "archive", "print"},
        "encounters": {"view", "create"}, "complaints": {"view", "create"}, "rooms": {"view"},
        "beds": {"view"}, "lookups": {"view"}, "doctors": {"view"},
    },
    "ER_STAFF": {
        "patients": {"view", "create", "update", "break_glass"},
        "encounters": {"view", "create", "update", "print", "sign", "break_glass"},
        "triage": {"view", "create", "update", "print", "sign", "break_glass"},
        "rooms": {"view"}, "beds": {"view", "update"}, "lookups": {"view"}, "doctors": {"view"},
    },
    "PROCEDURE_COORDINATOR": {
        "patients": {"view"}, "appointments": {"view", "create", "update", "archive", "print"},
        "waiting": {"view", "create", "update", "archive", "print"},
        "procedures": {"view", "create", "update", "archive", "print"},
        "rooms": {"view", "update"}, "beds": {"view"}, "sterilization": {"view", "create", "update", "print"}, "maintenance": {"view", "create", "update", "print"}, "inventory": {"view", "create", "update", "print"}, "inventory_movements": {"view", "create", "print"}, "lookups": {"view"}, "doctors": {"view"},
    },
    "ANESTHESIA": {
        "patients": {"view"}, "encounters": {"view", "update", "print", "sign"},
        "procedures": {"view", "update", "print", "sign"}, "triage": {"view"},
        "attachments": {"view"}, "lookups": {"view"}, "doctors": {"view"}, "maintenance": {"view"},
    },
    "BILLING": {
        "patients": {"view"}, "encounters": {"view"},
        "packages": {"view", "create", "update"},
        "invoices": {"view", "create", "update", "print"}, "complaints": {"view", "create", "update"}, "lookups": {"view"},
    },
    "AUDITOR_VIEWER": {"patients": {"view", "report"}, "audit": {"view", "export"}},
    "VIEWER": {"patients": {"view"}, "appointments": {"view"}, "waiting": {"view"}, "rooms": {"view"}, "doctors": {"view"}},
}

# Additional role profiles keep the generic record engine small while giving each
# operational team a least-privilege starting point. Owners and administrators
# retain the wildcard policy above; these profiles are intentionally editable via
# custom roles when a facility has a different separation of duties.
ROLE_PERMISSION_EXPANSIONS = {
    "DOCTOR": {
        "admissions": {"view", "create", "update", "transfer", "discharge", "sign", "break_glass"},
        "lab_orders": {"view", "create", "order", "sign"}, "imaging_orders": {"view", "create", "order", "sign"},
        "nursing_notes": {"view"}, "nursing_observations": {"view", "report", "sign"}, "medication_administrations": {"view"},
        "surgical_safety": {"view", "create", "update", "sign"}, "consents": {"view", "create", "update", "sign"},
        "referrals": {"view", "create", "update", "sign"}, "care_tasks": {"view", "create", "update", "assign"},
        "clinical_templates": {"view"}, "problem_list": {"view", "create", "update", "sign", "print"}, "allergies": {"view", "create", "update", "verify", "sign", "print"},
        "formulary": {"view"}, "drug_interactions": {"view"}, "blood_requests": {"view", "create", "update", "approve", "sign", "print"}, "insurance_claims": {"view"}, "quality_events": {"view", "create", "update", "report"},
    },
    "NURSE": {
        "admissions": {"view", "update", "transfer", "discharge"}, "lab_orders": {"view", "receive", "reject"},
        "imaging_orders": {"view"}, "nursing_notes": {"view", "create", "update", "sign"}, "nursing_observations": {"view", "create", "update", "sign", "report"},
        "medication_administrations": {"view", "create", "update", "administer", "sign"},
        "surgical_safety": {"view", "create", "update", "sign"}, "consents": {"view"},
        "care_tasks": {"view", "create", "update", "assign"}, "problem_list": {"view"}, "allergies": {"view", "create", "update", "verify"}, "blood_requests": {"view", "create", "update"},
    },
    "RECEPTION": {"admissions": {"view", "create", "update", "schedule", "transfer"}, "consents": {"view", "create"}, "care_tasks": {"view", "create"}},
    "ER_STAFF": {"admissions": {"view", "create", "update", "transfer", "discharge", "break_glass"}, "lab_orders": {"view", "receive", "reject"}, "imaging_orders": {"view"}, "nursing_observations": {"view", "create", "update", "sign", "break_glass"}, "care_tasks": {"view", "create", "update"}},
    "PROCEDURE_COORDINATOR": {"admissions": {"view", "update", "transfer"}, "lab_orders": {"view", "order"}, "imaging_orders": {"view", "order"}, "surgical_safety": {"view", "create", "update"}, "consents": {"view", "create"}, "care_tasks": {"view", "create", "update", "assign"}},
    "ANESTHESIA": {"admissions": {"view"}, "lab_orders": {"view"}, "imaging_orders": {"view"}, "surgical_safety": {"view", "update", "sign"}, "consents": {"view", "sign"}},
    "BILLING": {"admissions": {"view", "report"}, "care_tasks": {"view"}, "insurance_claims": {"view", "create", "update", "submit", "report", "print"}},
    "ADMISSIONS_CLERK": {"patients": {"view", "create", "update"}, "admissions": {"view", "create", "update", "schedule", "transfer", "discharge", "print"}, "appointments": {"view", "create", "update", "archive", "print"}, "waiting": {"view", "create", "update", "archive", "print"}, "consents": {"view", "create"}, "care_tasks": {"view", "create"}},
    "LAB_TECHNICIAN": {"patients": {"view"}, "encounters": {"view"}, "lab_orders": {"view", "update", "receive", "reject", "result", "print"}, "lab_results": {"view", "create", "update", "print"}, "specimens": {"view", "update", "receive", "reject"}},
    "LAB_REVIEWER": {"patients": {"view"}, "lab_orders": {"view", "verify", "approve", "sign", "print"}, "lab_results": {"view", "update", "sign", "approve", "print"}, "specimens": {"view", "update", "verify"}, "blood_requests": {"view", "verify"}},
    "RADIOLOGY_TECHNICIAN": {"patients": {"view"}, "imaging_orders": {"view", "update", "receive", "reject", "result", "print"}, "imaging": {"view", "create", "update", "print"}},
    "PHARMACIST": {"patients": {"view"}, "prescriptions": {"view", "verify", "dispense", "print"}, "medication_administrations": {"view", "create", "update", "administer", "sign"}, "inventory": {"view", "update"}, "inventory_movements": {"view", "create", "print"}, "formulary": {"view", "create", "update", "archive", "print"}, "drug_interactions": {"view", "create", "update", "archive", "print"}},
    "OR_NURSE": {"patients": {"view"}, "admissions": {"view", "update", "transfer"}, "procedures": {"view", "update", "print"}, "surgical_safety": {"view", "create", "update", "sign"}, "consents": {"view", "create"}, "nursing_notes": {"view", "create", "update", "sign"}, "nursing_observations": {"view", "create", "update", "sign", "report"}, "medication_administrations": {"view", "create", "update", "administer"}},
    "MEDICAL_RECORDS": {"patients": {"view", "update", "archive", "merge", "print", "export"}, "encounters": {"view", "update", "archive", "print", "export"}, "admissions": {"view", "update", "archive", "print", "export"}, "attachments": {"view", "download"}, "problem_list": {"view", "create", "update", "archive", "print", "export"}, "allergies": {"view", "create", "update", "archive", "print", "export"}, "insurance_claims": {"view", "report", "export"}},
    "QUALITY_OFFICER": {"patients": {"view", "report"}, "encounters": {"view", "report"}, "procedures": {"view", "report"}, "lab_results": {"view", "report"}, "imaging": {"view", "report"}, "complaints": {"view", "create", "update", "report"}, "care_tasks": {"view", "create", "update", "assign", "report"}, "quality_events": {"view", "create", "update", "report", "verify", "approve", "print"}},
    "BLOOD_BANK": {"patients": {"view"}, "blood_requests": {"view", "create", "update", "receive", "verify", "approve", "dispense", "print"}, "specimens": {"view", "update", "receive", "verify"}},
}
for _role, _rules in ROLE_PERMISSION_EXPANSIONS.items():
    ROLE_PERMISSIONS.setdefault(_role, {}).update(_rules)


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def ensure_dirs() -> None:
    for folder in (DATA_DIR, UPLOAD_DIR, BACKUP_DIR):
        folder.mkdir(parents=True, exist_ok=True)


def _tls_host_names() -> tuple[list[str], list[ipaddress.IPv4Address | ipaddress.IPv6Address]]:
    dns_names = {"localhost"}
    ip_addresses = {ipaddress.ip_address("127.0.0.1")}
    candidates = [socket.gethostname(), socket.getfqdn()]
    candidates.extend(os.environ.get("UROCARE_TLS_NAMES", "").split(","))
    for candidate in candidates:
        name = candidate.strip().rstrip(".")
        if not name:
            continue
        try:
            ip_addresses.add(ipaddress.ip_address(name))
            continue
        except ValueError:
            pass
        try:
            ascii_name = name.encode("idna").decode("ascii").lower()
        except UnicodeError:
            continue
        labels = ascii_name.split(".")
        if len(ascii_name) <= 253 and all(
            label and len(label) <= 63 and label[0] != "-" and label[-1] != "-"
            and all(character.isalnum() or character == "-" for character in label)
            for label in labels
        ):
            dns_names.add(ascii_name)
        try:
            for result in socket.getaddrinfo(name, None, family=socket.AF_INET, type=socket.SOCK_STREAM):
                ip_addresses.add(ipaddress.ip_address(result[4][0]))
        except OSError:
            pass
    return sorted(dns_names), sorted(ip_addresses, key=str)


def _write_private_file(path: Path, payload: bytes) -> None:
    temp = path.with_name(path.name + "." + secrets.token_hex(6) + ".tmp")
    temp.write_bytes(payload)
    try:
        os.chmod(temp, 0o600)
    except OSError:
        pass
    os.replace(temp, path)


def ensure_tls_certificates() -> tuple[Path, Path, Path]:
    """Create a persistent local trust CA and a fresh server certificate for this host."""
    if x509 is None or serialization is None or rsa is None:
        raise RuntimeError("يتطلب تشغيل HTTPS حزمة cryptography المضمّنة في البرنامج")
    tls_dir = DATA_DIR / "tls"
    tls_dir.mkdir(parents=True, exist_ok=True)
    ca_cert_path = tls_dir / "urocare-root-ca.crt"
    ca_key_path = tls_dir / "urocare-root-ca.key"
    server_cert_path = tls_dir / "server.crt"
    server_key_path = tls_dir / "server.key"

    if ca_cert_path.exists() != ca_key_path.exists():
        raise RuntimeError("ملف شهادة UroCare أو مفتاحها مفقود؛ أوقف التشغيل واحفظ مجلد tls قبل الإصلاح")
    if ca_cert_path.exists():
        try:
            ca_cert = x509.load_pem_x509_certificate(ca_cert_path.read_bytes())
            ca_key = serialization.load_pem_private_key(ca_key_path.read_bytes(), password=None)
            constraints = ca_cert.extensions.get_extension_for_class(x509.BasicConstraints).value
            if not constraints.ca or ca_key.public_key().public_numbers() != ca_cert.public_key().public_numbers():
                raise ValueError("الشهادة ومفتاح CA غير متطابقين")
        except Exception as exc:
            raise RuntimeError("تعذر التحقق من شهادة الثقة المحلية؛ تم إيقاف HTTPS دون استبدالها") from exc
    else:
        ca_key = rsa.generate_private_key(public_exponent=65537, key_size=3072)
        ca_name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "UroCare Local Trust CA")])
        ca_now = datetime.now(timezone.utc).replace(tzinfo=None)
        ca_cert = (
            x509.CertificateBuilder()
            .subject_name(ca_name).issuer_name(ca_name).public_key(ca_key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(ca_now - timedelta(minutes=5))
            .not_valid_after(ca_now + timedelta(days=3650))
            .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
            .add_extension(x509.KeyUsage(digital_signature=True, content_commitment=False,
                key_encipherment=False, data_encipherment=False, key_agreement=False,
                key_cert_sign=True, crl_sign=True, encipher_only=None, decipher_only=None), critical=True)
            .add_extension(x509.SubjectKeyIdentifier.from_public_key(ca_key.public_key()), critical=False)
            .sign(ca_key, hashes.SHA256())
        )
        _write_private_file(ca_key_path, ca_key.private_bytes(
            serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
        _write_private_file(ca_cert_path, ca_cert.public_bytes(serialization.Encoding.PEM))

    dns_names, ip_addresses = _tls_host_names()
    server_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    server_name = next((name for name in dns_names if name != "localhost"), "localhost")
    sans = [x509.DNSName(name) for name in dns_names]
    sans.extend(x509.IPAddress(address) for address in ip_addresses)
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    server_name_obj = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, server_name)])
    server_cert = (
        x509.CertificateBuilder()
        .subject_name(server_name_obj).issuer_name(ca_cert.subject).public_key(server_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - timedelta(minutes=5))
        .not_valid_after(now + timedelta(days=397))
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(x509.SubjectAlternativeName(sans), critical=False)
        .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
        .add_extension(x509.KeyUsage(digital_signature=True, content_commitment=False,
            key_encipherment=True, data_encipherment=False, key_agreement=False,
            key_cert_sign=False, crl_sign=False, encipher_only=None, decipher_only=None), critical=True)
        .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_key.public_key()), critical=False)
        .sign(ca_key, hashes.SHA256())
    )
    _write_private_file(server_key_path, server_key.private_bytes(
        serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    _write_private_file(server_cert_path, server_cert.public_bytes(serialization.Encoding.PEM))
    return server_cert_path, server_key_path, ca_cert_path


def create_tls_context() -> tuple[ssl.SSLContext, Path]:
    cert_path, key_path, ca_path = ensure_tls_certificates()
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(certfile=str(cert_path), keyfile=str(key_path))
    return context, ca_path


@contextmanager
def connection():
    ensure_dirs()
    with DB_LOCK:
        conn = sqlite3.connect(DB_PATH, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=30000")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()


def init_db() -> None:
    ensure_dirs()
    with connection() as db:
        db.execute("PRAGMA journal_mode=WAL")
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
          id TEXT PRIMARY KEY, username TEXT NOT NULL UNIQUE, display_name TEXT NOT NULL,
          role TEXT NOT NULL, password_hash TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL, last_login_at TEXT, totp_secret TEXT, totp_pending TEXT,
          recovery_codes TEXT, department TEXT NOT NULL DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS sessions (
          token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, csrf TEXT NOT NULL,
          expires_at INTEGER NOT NULL, created_at TEXT NOT NULL,
          FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS messages (
          id TEXT PRIMARY KEY, sender_id TEXT NOT NULL, receiver_id TEXT NOT NULL,
          body TEXT NOT NULL, created_at TEXT NOT NULL, read_at TEXT,
          FOREIGN KEY(sender_id) REFERENCES users(id) ON DELETE RESTRICT,
          FOREIGN KEY(receiver_id) REFERENCES users(id) ON DELETE RESTRICT
        );
        CREATE INDEX IF NOT EXISTS idx_messages_receiver ON messages(receiver_id, read_at, created_at);
        CREATE INDEX IF NOT EXISTS idx_messages_sender ON messages(sender_id, created_at);
        CREATE TABLE IF NOT EXISTS announcements (
          id TEXT PRIMARY KEY, created_by TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL,
          event_type TEXT NOT NULL, starts_at TEXT NOT NULL, audience_type TEXT NOT NULL,
          audience_value TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1,
          FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE RESTRICT
        );
        CREATE INDEX IF NOT EXISTS idx_announcements_audience_date ON announcements(active,audience_type,audience_value,starts_at);
        CREATE TABLE IF NOT EXISTS records (
          id TEXT PRIMARY KEY, kind TEXT NOT NULL, code TEXT, title TEXT, status TEXT,
          priority TEXT, payload_json TEXT NOT NULL, created_by TEXT NOT NULL,
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 1
        );
        CREATE INDEX IF NOT EXISTS idx_records_kind ON records(kind);
        CREATE INDEX IF NOT EXISTS idx_records_code ON records(code);
        CREATE INDEX IF NOT EXISTS idx_records_status ON records(status);
        CREATE TABLE IF NOT EXISTS audit_log (
          id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT, username TEXT,
          action TEXT NOT NULL, entity TEXT, entity_id TEXT, summary TEXT,
          created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS settings (
          key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS custom_roles (
          code TEXT PRIMARY KEY, name_ar TEXT NOT NULL, name_en TEXT NOT NULL,
          permissions_json TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1,
          created_by TEXT NOT NULL, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS emergency_access (
          id TEXT PRIMARY KEY, user_id TEXT NOT NULL, entity_kind TEXT NOT NULL,
          entity_id TEXT NOT NULL, reason TEXT NOT NULL, expires_at INTEGER NOT NULL,
          created_at TEXT NOT NULL, revoked_at TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_emergency_access_lookup ON emergency_access(user_id,entity_kind,entity_id,expires_at);
        CREATE TABLE IF NOT EXISTS system_alerts (
          id TEXT PRIMARY KEY, code TEXT NOT NULL, severity TEXT NOT NULL,
          message TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
          resolved_at TEXT, resolved_by TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_system_alerts_open ON system_alerts(resolved_at,updated_at);
        """)
        record_columns = {row["name"] for row in db.execute("PRAGMA table_info(records)")}
        if "revision" not in record_columns:
            db.execute("ALTER TABLE records ADD COLUMN revision INTEGER NOT NULL DEFAULT 1")
        user_columns = {row["name"] for row in db.execute("PRAGMA table_info(users)")}
        if "recovery_codes" not in user_columns:
            db.execute("ALTER TABLE users ADD COLUMN recovery_codes TEXT")
        if "department" not in user_columns:
            db.execute("ALTER TABLE users ADD COLUMN department TEXT NOT NULL DEFAULT ''")
        db.execute("INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('timezone','Africa/Cairo',?)", (now_utc(),))
        db.execute("INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('language','ar',?)", (now_utc(),))
        db.execute("INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('facility_type','hospital',?)", (now_utc(),))
        db.execute("INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('facility_country','مصر',?)", (now_utc(),))
        db.execute("INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('facility_governorate','المنوفية',?)", (now_utc(),))
        db.execute("INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('publisher_title','المهندس',?)", (now_utc(),))
        db.execute("INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('publisher_name','محمود بسيوني عبد الله بسيوني',?)", (now_utc(),))
        db.execute("INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('publisher_phone','01009889854',?)", (now_utc(),))
        db.execute("INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('brand_banner_data','',?)", (now_utc(),))
        db.execute("INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('brand_banner_mime','',?)", (now_utc(),))
        db.execute("INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('brand_logo_data','',?)", (now_utc(),))
        db.execute("INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('brand_logo_mime','',?)", (now_utc(),))
        db.execute("INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('backup_interval_hours','4',?)", (now_utc(),))
        db.execute("INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('backup_retention_days','30',?)", (now_utc(),))
        db.execute("INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('session_idle_minutes','30',?)", (now_utc(),))
        db.execute("INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('procedure_preparation_checklist',?,?)",
                   (json.dumps(PREPARATION_CHECKLIST_DEFAULTS, ensure_ascii=False), now_utc()))
        checklist_row = db.execute("SELECT value FROM settings WHERE key='procedure_preparation_checklist'").fetchone()
        try:
            saved_checklist = json.loads(checklist_row["value"] or "[]") if checklist_row else []
        except (TypeError, json.JSONDecodeError):
            saved_checklist = []
        if not isinstance(saved_checklist, list):
            saved_checklist = []
        merged_checklist = list(dict.fromkeys([str(item).strip() for item in saved_checklist if str(item).strip()] + PREPARATION_CHECKLIST_DEFAULTS))[:30]
        if merged_checklist != saved_checklist:
            db.execute("UPDATE settings SET value=?,updated_at=? WHERE key='procedure_preparation_checklist'",
                       (json.dumps(merged_checklist, ensure_ascii=False), now_utc()))
        db.execute("INSERT OR IGNORE INTO settings(key,value,updated_at) VALUES('theme','emerald',?)", (now_utc(),))


def password_hash(password: str) -> str:
    salt = secrets.token_bytes(16)
    derived = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2**14, r=8, p=1, dklen=32)
    return "scrypt$" + base64.urlsafe_b64encode(salt + derived).decode("ascii")


def password_ok(password: str, saved: str) -> bool:
    try:
        scheme, encoded = saved.split("$", 1)
        raw = base64.urlsafe_b64decode(encoded.encode("ascii"))
        salt, expected = raw[:16], raw[16:]
        if scheme != "scrypt":
            return False
        actual = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2**14, r=8, p=1, dklen=len(expected))
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False


def login_failure(ip: str, username: str, now: float) -> None:
    """Keep short-lived IP and account buckets for brute-force protection."""
    recent_ip = [stamp for stamp in LOGIN_ATTEMPTS.get(ip, []) if now - stamp < 600]
    recent_ip.append(now)
    LOGIN_ATTEMPTS[ip] = recent_ip
    account_key = username[:160].lower()
    recent_account = [stamp for stamp in LOGIN_ACCOUNT_ATTEMPTS.get(account_key, []) if now - stamp < 600]
    recent_account.append(now)
    LOGIN_ACCOUNT_ATTEMPTS[account_key] = recent_account


def login_rate_limited(ip: str, username: str, now: float) -> bool:
    recent_ip = [stamp for stamp in LOGIN_ATTEMPTS.get(ip, []) if now - stamp < 600]
    recent_account = [stamp for stamp in LOGIN_ACCOUNT_ATTEMPTS.get(username[:160].lower(), []) if now - stamp < 600]
    LOGIN_ATTEMPTS[ip] = recent_ip
    LOGIN_ACCOUNT_ATTEMPTS[username[:160].lower()] = recent_account
    return len(recent_ip) >= 8 or len(recent_account) >= 5


def normalize_recovery_code(code: object) -> str:
    return "".join(ch for ch in str(code or "").upper() if ch.isalnum())


def generate_recovery_codes(count: int = 8) -> tuple[list[str], list[str]]:
    plain = []
    hashed = []
    for _ in range(count):
        code = secrets.token_hex(5).upper()
        plain.append(f"{code[:5]}-{code[5:]}")
        hashed.append(password_hash(code))
    return plain, hashed


def consume_recovery_code(user_id: str, code: object) -> bool:
    normalized = normalize_recovery_code(code)
    if len(normalized) != 10:
        return False
    with connection() as db:
        db.execute("BEGIN IMMEDIATE")
        row = db.execute("SELECT recovery_codes FROM users WHERE id=?", (user_id,)).fetchone()
        try:
            saved = json.loads(row["recovery_codes"] or "[]") if row else []
        except (TypeError, json.JSONDecodeError):
            saved = []
        if not isinstance(saved, list):
            saved = []
        for index, saved_hash in enumerate(saved):
            if password_ok(normalized, str(saved_hash)):
                saved.pop(index)
                db.execute("UPDATE users SET recovery_codes=? WHERE id=?", (json.dumps(saved), user_id))
                return True
    return False


def audit(user: sqlite3.Row | dict | None, action: str, entity: str = "system", entity_id: str = "", summary: str = "") -> None:
    if user:
        uid = user["id"]
        uname = user["username"]
    else:
        uid, uname = None, "system"
    clean_summary = summary[:500]
    with connection() as db:
        db.execute("INSERT INTO audit_log(user_id,username,action,entity,entity_id,summary,created_at) VALUES(?,?,?,?,?,?,?)",
                   (uid, uname, action, entity, entity_id, clean_summary, now_utc()))


def audit_sensitive_read(user: dict, kind: str, record_id: str = "", count: int = 0) -> None:
    if kind != "patients" and kind not in CLINICAL_KINDS:
        return
    if record_id:
        audit(user, "record_view", kind, record_id, "فتح سجل حساس")
        return
    now = time.monotonic()
    key = (str(user["id"]), kind)
    if now - SENSITIVE_READ_LAST.get(key, 0) < 60:
        return
    if len(SENSITIVE_READ_LAST) > 5000:
        stale_before = now - 600
        for stale_key, last_seen in list(SENSITIVE_READ_LAST.items()):
            if last_seen < stale_before:
                SENSITIVE_READ_LAST.pop(stale_key, None)
    audit(user, "record_list_view", kind, "", f"عرض قائمة سجلات حساسة ({max(0, int(count))} سجل)")
    SENSITIVE_READ_LAST[key] = now


def query_audit_log(query: dict) -> dict:
    """Return a bounded, filterable audit view without exposing patient payloads."""
    def first(name: str) -> str:
        values = query.get(name, [""])
        return str(values[0] if values else "").strip()

    try:
        limit = min(500, max(1, int(first("limit") or "200")))
    except ValueError as exc:
        raise ValueError("حد سجل التدقيق غير صالح") from exc
    search = first("q")[:160].lower()
    action = first("action")[:100]
    entity = first("entity")[:100]
    date_from = first("from")
    date_to = first("to")
    for value, label in ((date_from, "تاريخ البداية"), (date_to, "تاريخ النهاية")):
        if value:
            try:
                datetime.strptime(value, "%Y-%m-%d")
            except ValueError as exc:
                raise ValueError(f"{label} غير صالح") from exc
    if date_from and date_to and date_from > date_to:
        raise ValueError("تاريخ البداية يجب ألا يتجاوز تاريخ النهاية")

    clauses, args = [], []
    if search:
        pattern = f"%{search}%"
        clauses.append("(lower(coalesce(username,'')) LIKE ? OR lower(action) LIKE ? OR lower(coalesce(entity,'')) LIKE ? OR lower(coalesce(summary,'')) LIKE ?)")
        args.extend([pattern] * 4)
    if action:
        clauses.append("action=?")
        args.append(action)
    if entity:
        clauses.append("entity=?")
        args.append(entity)
    if date_from:
        clauses.append("substr(created_at,1,10)>=?")
        args.append(date_from)
    if date_to:
        clauses.append("substr(created_at,1,10)<=?")
        args.append(date_to)
    where = " WHERE " + " AND ".join(clauses) if clauses else ""
    with connection() as db:
        total = db.execute(f"SELECT COUNT(*) FROM audit_log{where}", args).fetchone()[0]
        rows = db.execute(
            f"SELECT id,username,action,entity,entity_id,summary,created_at FROM audit_log{where} ORDER BY id DESC LIMIT ?",
            (*args, limit),
        ).fetchall()
    return {"items": [dict(row) for row in rows], "total": int(total), "limit": limit}


def audit_csv_payload(query: dict, user: dict) -> bytes:
    result = query_audit_log(query)
    audit(user, "audit_export", "audit", "", f"تصدير سجل التدقيق ({len(result['items'])} سجل)")
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(["created_at", "username", "action", "entity", "entity_id", "summary"])
    for item in result["items"]:
        writer.writerow([item.get("created_at", ""), item.get("username", ""), item.get("action", ""),
                         item.get("entity", ""), item.get("entity_id", ""), item.get("summary", "")])
    return ("\ufeff" + output.getvalue()).encode("utf-8")


def setup_done() -> bool:
    with connection() as db:
        return db.execute("SELECT COUNT(*) FROM users WHERE role=?", (OWNER,)).fetchone()[0] == 2


def owner_count() -> int:
    with connection() as db:
        return db.execute("SELECT COUNT(*) FROM users WHERE role=?", (OWNER,)).fetchone()[0]


def upsert_system_alert(code: str, severity: str, message: str) -> dict:
    """Create or refresh one open operational alert without duplicating it on every worker tick."""
    code = str(code).strip()[:80]
    severity = str(severity).strip().lower()
    message = str(message).strip()[:500]
    if not code or severity not in SYSTEM_ALERT_SEVERITIES or not message:
        raise ValueError("بيانات تنبيه النظام غير صالحة")
    stamp = now_utc()
    with connection() as db:
        row = db.execute(
            "SELECT id FROM system_alerts WHERE code=? AND resolved_at IS NULL ORDER BY updated_at DESC LIMIT 1",
            (code,),
        ).fetchone()
        if row:
            db.execute("UPDATE system_alerts SET severity=?,message=?,updated_at=? WHERE id=?",
                       (severity, message, stamp, row["id"]))
            alert_id = row["id"]
        else:
            alert_id = str(uuid.uuid4())
            db.execute(
                "INSERT INTO system_alerts(id,code,severity,message,created_at,updated_at) VALUES(?,?,?,?,?,?)",
                (alert_id, code, severity, message, stamp, stamp),
            )
    return {"id": alert_id, "code": code, "severity": severity, "message": message,
            "created_at": stamp, "updated_at": stamp}


def resolve_system_alert(code: str, user: sqlite3.Row | dict | None = None) -> int:
    stamp = now_utc()
    resolver = str(user.get("id", "")) if user else "system"
    with connection() as db:
        result = db.execute(
            "UPDATE system_alerts SET resolved_at=?,resolved_by=?,updated_at=? WHERE code=? AND resolved_at IS NULL",
            (stamp, resolver, stamp, str(code).strip()[:80]),
        )
    return result.rowcount


def list_system_alerts(limit: int = 50) -> list[dict]:
    limit = min(200, max(1, int(limit)))
    with connection() as db:
        rows = db.execute(
            "SELECT id,code,severity,message,created_at,updated_at FROM system_alerts "
            "WHERE resolved_at IS NULL ORDER BY CASE severity WHEN 'critical' THEN 0 ELSE 1 END,updated_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
    return [dict(row) for row in rows]


def refresh_storage_alert(disk=None) -> None:
    """Raise a visible owner alert when the data volume is close to full."""
    try:
        disk = disk or shutil.disk_usage(DATA_DIR)
        if not disk.total:
            return
        free_percent = (disk.free / disk.total) * 100
        if free_percent <= 5:
            upsert_system_alert("low_storage", "critical", f"المساحة المتاحة حرجة جدًا: {free_percent:.1f}% فقط")
        elif free_percent <= 15:
            upsert_system_alert("low_storage", "warning", f"المساحة المتاحة منخفضة: {free_percent:.1f}% فقط")
        else:
            resolve_system_alert("low_storage")
    except (OSError, ValueError, TypeError, sqlite3.Error):
        # A storage probe must never prevent the application from opening.
        return


def refresh_clinical_followup_alerts() -> dict[str, int]:
    """Keep owner-facing reminders in sync with clinical follow-up and stock risks."""
    today = facility_today()
    try:
        with connection() as db:
            devices_due = db.execute(
                "SELECT COUNT(*) FROM records WHERE kind='devices' "
                "AND status NOT IN ('archived','تمت الإزالة','مفقود') "
                "AND date(json_extract(payload_json,'$.removal_due_at'))<=date(?) "
                "AND json_extract(payload_json,'$.removal_due_at')<>''",
                (today,),
            ).fetchone()[0]
            specimens_pending = db.execute(
                "SELECT COUNT(*) FROM records WHERE kind='specimens' "
                "AND status IN ('أُرسلت','النتيجة معلقة','sent','pending_result')"
            ).fetchone()[0]
            inventory_low = db.execute(
                "SELECT COUNT(*) FROM records WHERE kind='inventory' AND status NOT IN ('archived','موقوف') "
                "AND CAST(COALESCE(json_extract(payload_json,'$.quantity'),'0') AS REAL) <= "
                "CAST(COALESCE(json_extract(payload_json,'$.reorder_level'),'0') AS REAL)"
            ).fetchone()[0]
            inventory_expiring = db.execute(
                "SELECT COUNT(*) FROM records WHERE kind='inventory' AND status NOT IN ('archived','موقوف') "
                "AND date(json_extract(payload_json,'$.expiry_at')) BETWEEN date(?) AND date(?, '+30 day') "
                "AND json_extract(payload_json,'$.expiry_at')<>''", (today, today)
            ).fetchone()[0]
            training_expired = db.execute(
                "SELECT COUNT(*) FROM records WHERE kind='training' AND status NOT IN ('موقوف','archived') "
                "AND date(json_extract(payload_json,'$.expires_at')) < date(?) AND json_extract(payload_json,'$.expires_at')<>''", (today,)
            ).fetchone()[0]
            training_expiring = db.execute(
                "SELECT COUNT(*) FROM records WHERE kind='training' AND status NOT IN ('موقوف','archived') "
                "AND date(json_extract(payload_json,'$.expires_at')) BETWEEN date(?) AND date(?, '+30 day')", (today, today)
            ).fetchone()[0]
        if devices_due:
            upsert_system_alert("devices_due", "warning", f"يوجد {devices_due} متابعة دعامة أو قسطرة مستحقة")
        else:
            resolve_system_alert("devices_due")
        if specimens_pending:
            upsert_system_alert("specimens_pending", "warning", f"يوجد {specimens_pending} عينة تنتظر نتيجة أو مراجعة")
        else:
            resolve_system_alert("specimens_pending")
        if inventory_low:
            upsert_system_alert("inventory_low", "warning", f"يوجد {inventory_low} صنفًا عند حد إعادة الطلب أو أقل")
        else:
            resolve_system_alert("inventory_low")
        if inventory_expiring:
            upsert_system_alert("inventory_expiring", "warning", f"يوجد {inventory_expiring} صنفًا تنتهي صلاحيته خلال 30 يومًا")
        else:
            resolve_system_alert("inventory_expiring")
        if training_expired:
            upsert_system_alert("training_expired", "critical", f"يوجد {training_expired} اعتماد تدريبي منتهي")
        else:
            resolve_system_alert("training_expired")
        if training_expiring:
            upsert_system_alert("training_expiring", "warning", f"يوجد {training_expiring} اعتمادًا تدريبيًا ينتهي خلال 30 يومًا")
        else:
            resolve_system_alert("training_expiring")
        return {"devices_due": int(devices_due), "specimens_pending": int(specimens_pending), "inventory_low": int(inventory_low), "inventory_expiring": int(inventory_expiring), "training_expired": int(training_expired), "training_expiring": int(training_expiring)}
    except (OSError, ValueError, TypeError, sqlite3.Error):
        return {
            "devices_due": 0,
            "specimens_pending": 0,
            "inventory_low": 0,
            "inventory_expiring": 0,
            "training_expired": 0,
            "training_expiring": 0,
        }


def default_backup_key() -> bytes:
    if Fernet is None:
        raise RuntimeError("ميزة النسخ المشفر تحتاج حزمة cryptography المضمّنة في التثبيت")
    ensure_dirs()
    if not KEY_PATH.exists():
        key = Fernet.generate_key()
        temp = KEY_PATH.with_suffix(".tmp")
        temp.write_bytes(key)
        try:
            os.chmod(temp, 0o600)
        except OSError:
            pass
        os.replace(temp, KEY_PATH)
    return KEY_PATH.read_bytes().strip()


def _prune_old_backups() -> list[str]:
    """Apply the configured retention policy, always preserving the two newest backups."""
    with connection() as db:
        row = db.execute("SELECT value FROM settings WHERE key='backup_retention_days'").fetchone()
    retention_days = max(0, int(row[0])) if row else 30
    if retention_days == 0:
        return []
    files = list(BACKUP_DIR.glob("*.zip")) + list(BACKUP_DIR.glob("*.ucb"))
    files.sort(key=lambda item: item.stat().st_mtime, reverse=True)
    cutoff = time.time() - retention_days * 24 * 60 * 60
    removed = []
    for item in files[2:]:
        try:
            if item.stat().st_mtime < cutoff:
                item.unlink()
                removed.append(item.name)
        except OSError:
            continue
    return removed


def _create_backup_payload(label: str = "manual") -> dict:
    if Fernet is None:
        raise RuntimeError("حزمة التشفير غير مثبتة")
    ensure_dirs()
    with BACKUP_LOCK, DB_LOCK:
        stamp = facility_now().strftime("%Y-%m-%d_%H-%M-%S")
        base = f"UroCare_Backup_{stamp}"
        label_suffix = {"automatic": "AUTO", "pre_restore": "PRE_RESTORE", "pre_update": "PRE_UPDATE"}.get(label, "MANUAL")
        base += f"_{label_suffix}"
        target = BACKUP_DIR / f"{base}.zip"
        suffix = 1
        while target.exists():
            target = BACKUP_DIR / f"{base}_{suffix}.zip"
            suffix += 1
        work = Path(tempfile.mkdtemp(prefix="urocare_backup_", dir=DATA_DIR))
        try:
            db_copy = work / "urocare.sqlite3"
            with sqlite3.connect(DB_PATH, timeout=30) as source, sqlite3.connect(db_copy) as dest:
                source.backup(dest)
                check = dest.execute("PRAGMA integrity_check").fetchone()[0]
                if check != "ok":
                    raise RuntimeError("فشل التحقق من قاعدة البيانات أثناء النسخ")
            manifest = {
                "app": "UroCare Suite", "format": 1, "created_at": now_utc(),
                "kind": label, "database": "urocare.sqlite3",
            }
            archive_bytes = io.BytesIO()
            with zipfile.ZipFile(archive_bytes, "w", zipfile.ZIP_DEFLATED) as zf:
                zf.write(db_copy, "urocare.sqlite3")
                zf.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False))
                if UPLOAD_DIR.exists():
                    for path in UPLOAD_DIR.rglob("*"):
                        if path.is_file():
                            zf.write(path, "uploads/" + path.relative_to(UPLOAD_DIR).as_posix())
            raw = archive_bytes.getvalue()
            digest = hashlib.sha256(raw).hexdigest()
            encrypted = Fernet(default_backup_key()).encrypt(raw)
            temp_out = target.with_suffix(".tmp")
            encrypted_payload = b"UROCARE1" + bytes.fromhex(digest) + encrypted
            # The ZIP is a standard, portable container. Its member remains encrypted;
            # the data inside it was compressed before encryption above.
            with zipfile.ZipFile(temp_out, "w", compression=zipfile.ZIP_DEFLATED) as zf:
                zf.writestr(f"{base}.ucb", encrypted_payload)
            os.replace(temp_out, target)
            try:
                os.chmod(target, 0o600)
            except OSError:
                pass
            try:
                removed_backups = _prune_old_backups()
                if removed_backups:
                    audit(None, "backup_retention_cleanup", "backup", str(len(removed_backups)),
                          f"تم حذف {len(removed_backups)} نسخة تجاوزت مدة الاحتفاظ")
            except Exception:
                # A retention failure must never turn a successfully written backup into a failed backup.
                removed_backups = []
            return {
                "name": target.name, "path": str(target), "size": target.stat().st_size,
                "created_at": now_utc(), "kind": label, "sha256": digest,
                "retention_removed": len(removed_backups),
            }
        finally:
            shutil.rmtree(work, ignore_errors=True)


def _create_backup_internal(label: str = "manual") -> dict:
    try:
        info = _create_backup_payload(label)
        try:
            resolve_system_alert("backup_failure")
        except sqlite3.Error:
            # A notification bookkeeping problem must not turn a valid backup into a failure.
            pass
        return info
    except Exception as exc:
        try:
            upsert_system_alert("backup_failure", "critical", f"فشل إنشاء النسخة الاحتياطية ({label}): {exc}")
        except sqlite3.Error:
            pass
        raise


def backup_worker() -> None:
    while True:
        try:
            if setup_done():
                interval = 4
                with connection() as db:
                    row = db.execute("SELECT value FROM settings WHERE key='backup_interval_hours'").fetchone()
                    if row:
                        interval = max(1, int(row[0]))
                files = list(BACKUP_DIR.glob("*.zip")) + list(BACKUP_DIR.glob("*.ucb"))
                latest = max((item.stat().st_mtime for item in files), default=0)
                stale = not files or (time.time() - latest) >= interval * 3600
                if stale:
                    try:
                        info = _create_backup_internal("automatic")
                        audit(None, "backup_auto", "backup", info["name"], "تم إنشاء نسخة تلقائية")
                    except Exception as exc:
                        audit(None, "backup_auto_failed", "backup", "", str(exc))
        except Exception:
            pass
        time.sleep(30)


def get_settings() -> dict[str, str]:
    with connection() as db:
        return {row["key"]: row["value"] for row in db.execute("SELECT key,value FROM settings")}


def facility_now() -> datetime:
    """Return server time in the configured facility timezone, never a client timezone."""
    try:
        zone_name = get_settings().get("timezone", "Africa/Cairo")
    except (sqlite3.Error, OSError):
        zone_name = "Africa/Cairo"
    try:
        zone = ZoneInfo(zone_name)
    except (ZoneInfoNotFoundError, TypeError, ValueError):
        zone = timezone.utc
    return datetime.now(timezone.utc).astimezone(zone)


def facility_today() -> str:
    return facility_now().date().isoformat()


CUSTOMIZATION_SETTINGS = {
    "system_name", "hospital_name", "department_name", "facility_type", "facility_country", "facility_governorate",
    "publisher_title", "publisher_name", "publisher_phone",
    "brand_banner_data", "brand_banner_mime", "brand_logo_data", "brand_logo_mime", "timezone", "language",
    "theme", "backup_interval_hours", "backup_retention_days", "session_idle_minutes",
    "module_labels", "procedure_preparation_checklist",
}
CUSTOMIZATION_MODULES = set(ALL_KINDS) | {"dashboard", "reports", "users", "audit", "backups", "settings"}
THEMES = {"emerald", "ocean", "forest", "violet", "rose", "sand", "slate", "indigo", "coral", "midnight"}
FACILITY_TYPES = {"hospital", "clinic", "medical_center", "other"}
BRAND_BANNER_MAX_BYTES = 1_500_000
BRAND_BANNER_MIME_SIGNATURES = {
    "image/png": lambda data: data.startswith(b"\x89PNG\r\n\x1a\n"),
    "image/jpeg": lambda data: data.startswith(b"\xff\xd8\xff"),
    "image/webp": lambda data: len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP",
}


def decode_brand_banner(data: object, mime: object) -> bytes:
    if data == "" and mime == "":
        return b""
    if not isinstance(data, str) or not isinstance(mime, str) or mime not in BRAND_BANNER_MIME_SIGNATURES:
        raise ValueError("صيغة البانر غير مدعومة؛ استخدم PNG أو JPEG أو WebP")
    if len(data) > ((BRAND_BANNER_MAX_BYTES + 2) // 3) * 4:
        raise ValueError("حجم البانر أكبر من 1.5 ميجابايت")
    try:
        decoded = base64.b64decode(data, validate=True)
    except (ValueError, binascii.Error) as exc:
        raise ValueError("بيانات صورة البانر غير صالحة") from exc
    if not decoded or len(decoded) > BRAND_BANNER_MAX_BYTES:
        raise ValueError("حجم البانر فارغ أو أكبر من 1.5 ميجابايت")
    if not BRAND_BANNER_MIME_SIGNATURES[mime](decoded):
        raise ValueError("محتوى الملف لا يطابق صيغة صورة البانر المختارة")
    return decoded


def normalize_announcement_datetime(value: object, timezone_name: object) -> str:
    if not isinstance(value, str) or len(value) > 32:
        raise ValueError("تاريخ ووقت المناسبة غير صالحين")
    try:
        local_time = datetime.fromisoformat(value)
        if local_time.tzinfo is not None:
            raise ValueError
        zone = ZoneInfo(str(timezone_name or "Africa/Cairo"))
    except (ValueError, TypeError, ZoneInfoNotFoundError):
        raise ValueError("أدخل تاريخًا ووقتًا صحيحين للمنشأة")
    return local_time.replace(tzinfo=zone).astimezone(timezone.utc).isoformat(timespec="seconds")


def visible_announcements(user: dict, upcoming_only: bool = False) -> dict:
    settings = get_settings()
    cutoff = now_utc() if upcoming_only else (datetime.now(timezone.utc) - timedelta(days=30)).isoformat(timespec="seconds")
    department = str(user.get("department") or "").strip()
    with connection() as db:
        rows = db.execute("""
            SELECT a.*, creator.display_name AS creator_name, target.display_name AS target_name
            FROM announcements a
            JOIN users creator ON creator.id=a.created_by
            LEFT JOIN users target ON a.audience_type='user' AND target.id=a.audience_value
            WHERE a.active=1 AND a.starts_at>=?
              AND (a.audience_type='all'
                   OR (a.audience_type='user' AND a.audience_value=?)
                   OR (a.audience_type='department' AND lower(a.audience_value)=lower(?))
                   OR a.created_by=?)
            ORDER BY a.starts_at LIMIT 200
        """, (cutoff, user["id"], department, user["id"])).fetchall()
    items = []
    for row in rows:
        item = dict(row)
        item["audience_name"] = item.get("target_name") or item.get("audience_value") or "جميع المستخدمين"
        items.append(item)
    if user.get("role") in (OWNER, "ADMIN"):
        with connection() as db:
            users = db.execute("SELECT id,username,display_name,role,department FROM users WHERE active=1 ORDER BY department,display_name").fetchall()
            departments = db.execute("SELECT DISTINCT trim(department) AS name FROM users WHERE active=1 AND trim(department)<>'' ORDER BY name COLLATE NOCASE").fetchall()
        return {"items": items, "users": [dict(row) for row in users], "departments": [row["name"] for row in departments]}
    return {"items": items, "users": [], "departments": []}


def normalize_customization_settings(settings: dict) -> dict[str, str | int]:
    clean = {}
    ranges = {"backup_interval_hours": (1, 24), "backup_retention_days": (0, 3650), "session_idle_minutes": (5, 720)}
    for key, value in settings.items():
        if key not in CUSTOMIZATION_SETTINGS: continue
        if key in ranges:
            try: value = int(value)
            except (TypeError, ValueError): raise ValueError(f"قيمة {key} غير صالحة")
            low, high = ranges[key]
            if not low <= value <= high: raise ValueError(f"قيمة {key} يجب أن تكون بين {low} و{high}")
        elif key == "timezone":
            try: ZoneInfo(str(value))
            except (ZoneInfoNotFoundError, ValueError, TypeError): raise ValueError("المنطقة الزمنية في ملف التخصيص غير صالحة")
            value = str(value)
        elif key == "theme":
            if not isinstance(value, str) or value not in THEMES: raise ValueError("الثيم الموجود في ملف التخصيص غير صالح")
            value = str(value)
        elif key == "language":
            if not isinstance(value, str) or value not in {"ar", "en"}: raise ValueError("اللغة الموجودة في ملف التخصيص غير صالحة")
            value = str(value)
        elif key == "facility_type":
            if not isinstance(value, str) or value not in FACILITY_TYPES: raise ValueError("نوع المنشأة غير صالح")
            value = str(value)
        elif key == "brand_banner_data":
            if value is None: value = ""
            if not isinstance(value, str): raise ValueError("بيانات صورة البانر غير صالحة")
        elif key == "brand_banner_mime":
            if value is None: value = ""
            if not isinstance(value, str): raise ValueError("نوع صورة البانر غير صالح")
        elif key in {"system_name", "hospital_name", "department_name", "facility_country", "facility_governorate", "publisher_title", "publisher_name"}:
            value = str(value).strip()
            if len(value) > 160: raise ValueError(f"قيمة {key} طويلة جدًا")
        elif key == "publisher_phone":
            value = str(value).strip().replace(" ", "").replace("-", "")
            if value and (not value.isdigit() or len(value) != 11 or not value.startswith("01")):
                raise ValueError("رقم هاتف الناشر يجب أن يكون رقمًا مصريًا من 11 رقمًا ويبدأ بـ 01")
        elif key == "module_labels":
            if isinstance(value, str):
                try: value = json.loads(value)
                except json.JSONDecodeError: raise ValueError("أسماء القوائم في ملف التخصيص غير صالحة")
            if not isinstance(value, dict) or len(value) > len(CUSTOMIZATION_MODULES):
                raise ValueError("أسماء القوائم في ملف التخصيص غير صالحة")
            labels = {}
            for module, label in value.items():
                if module not in CUSTOMIZATION_MODULES: raise ValueError("يتضمن ملف التخصيص اسم قائمة غير معروف")
                if isinstance(label, str):
                    if len(label.strip()) > 80: raise ValueError("اسم القائمة طويل جدًا")
                    labels[module] = label.strip()
                elif isinstance(label, dict) and set(label).issubset({"ar", "en"}):
                    labels[module] = {}
                    for language, text in label.items():
                        if not isinstance(text, str) or len(text.strip()) > 80: raise ValueError("اسم القائمة غير صالح")
                        labels[module][language] = text.strip()
                else: raise ValueError("صيغة اسم القائمة غير صالحة")
            value = json.dumps(labels, ensure_ascii=False)
        elif key == "procedure_preparation_checklist":
            if isinstance(value, str):
                try:
                    parsed = json.loads(value)
                    value = parsed if isinstance(parsed, list) else value.splitlines()
                except json.JSONDecodeError:
                    value = value.splitlines()
            if not isinstance(value, list) or not 1 <= len(value) <= 30:
                raise ValueError("قائمة تحضير الإجراء يجب أن تحتوي من عنصر إلى 30 عنصرًا")
            items, seen = [], set()
            for item in value:
                if not isinstance(item, str) or not item.strip() or len(item.strip()) > 160:
                    raise ValueError("يوجد عنصر فارغ أو طويل في قائمة تحضير الإجراء")
                clean_item = item.strip()
                if clean_item.casefold() not in seen:
                    items.append(clean_item)
                    seen.add(clean_item.casefold())
            value = json.dumps(items, ensure_ascii=False)
        clean[key] = value
    for asset in ("brand_banner", "brand_logo"):
        data_key, mime_key = f"{asset}_data", f"{asset}_mime"
        if data_key in settings or mime_key in settings:
            image_data = clean.get(data_key, "")
            image_mime = clean.get(mime_key, "")
            if bool(image_data) != bool(image_mime):
                raise ValueError("بيانات الصورة ونوعها يجب أن يوجدا معًا")
            if image_data:
                decode_brand_banner(image_data, image_mime)
    return clean


def customization_payload() -> dict:
    settings = {key: value for key, value in get_settings().items() if key in CUSTOMIZATION_SETTINGS}
    with connection() as db:
        roles = [dict(row) for row in db.execute(
            "SELECT code,name_ar,name_en,permissions_json,active FROM custom_roles ORDER BY code"
        ).fetchall()]
        lookups = [dict(row) for row in db.execute(
            "SELECT id,payload_json,status FROM records WHERE kind='lookups' ORDER BY created_at"
        ).fetchall()]
    return {
        "format": "urocare-customization",
        "version": 1,
        "exported_at": now_utc(),
        "settings": settings,
        "roles": [{
            "code": row["code"], "name_ar": row["name_ar"], "name_en": row["name_en"],
            "permissions": json.loads(row["permissions_json"]), "active": bool(row["active"]),
        } for row in roles],
        "lookups": [{"id": row["id"], "data": json.loads(row["payload_json"]), "active": row["status"] != "archived"} for row in lookups],
    }


def generate_totp(secret: str, counter: int) -> str:
    key = base64.b32decode(secret.upper() + "=" * ((8 - len(secret) % 8) % 8))
    digest = hmac.new(key, struct.pack(">Q", counter), hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    value = struct.unpack(">I", digest[offset:offset + 4])[0] & 0x7FFFFFFF
    return f"{value % 1000000:06d}"


def verify_totp(secret: str | None, code: str | None) -> bool:
    if not secret or not code or len(code) != 6 or not code.isdigit():
        return False
    step = int(time.time() // 30)
    return any(hmac.compare_digest(generate_totp(secret, step + delta), code) for delta in (-1, 0, 1))


def make_session(user_id: str) -> tuple[str, str]:
    token = secrets.token_urlsafe(40)
    csrf = secrets.token_urlsafe(24)
    with connection() as db:
        row = db.execute("SELECT value FROM settings WHERE key='session_idle_minutes'").fetchone()
        try: idle_minutes = min(720, max(5, int(row[0]))) if row else 30
        except (TypeError, ValueError): idle_minutes = 30
        db.execute("INSERT INTO sessions(token_hash,user_id,csrf,expires_at,created_at) VALUES(?,?,?,?,?)",
                   (hashlib.sha256(token.encode()).hexdigest(), user_id, csrf, int(time.time()) + idle_minutes * 60, now_utc()))
    return token, csrf


def get_user_for_token(token: str | None) -> tuple[dict | None, str | None]:
    if not token:
        return None, None
    token_hash = hashlib.sha256(token.encode()).hexdigest()
    with connection() as db:
        row = db.execute("""SELECT u.*,s.csrf,s.expires_at FROM sessions s
                           JOIN users u ON u.id=s.user_id WHERE s.token_hash=?""", (token_hash,)).fetchone()
        if not row or row["expires_at"] < int(time.time()) or not row["active"]:
            db.execute("DELETE FROM sessions WHERE token_hash=?", (token_hash,))
            return None, None
        idle_row = db.execute("SELECT value FROM settings WHERE key='session_idle_minutes'").fetchone()
        try: idle_minutes = min(720, max(5, int(idle_row[0]))) if idle_row else 30
        except (TypeError, ValueError): idle_minutes = 30
        expires_at = int(time.time()) + idle_minutes * 60
        db.execute("UPDATE sessions SET expires_at=? WHERE token_hash=?", (expires_at, token_hash))
        result = dict(row)
        result["expires_at"] = expires_at
        return result, row["csrf"]


def allowed(user: dict, kind: str, action: str) -> bool:
    role = user["role"]
    rules = ROLE_PERMISSIONS.get(role)
    if rules is None:
        with connection() as db:
            row = db.execute("SELECT permissions_json,active FROM custom_roles WHERE code=?", (role,)).fetchone()
        if not row or not row["active"]:
            return False
        try: rules = json.loads(row["permissions_json"])
        except Exception: return False
    if "*" in rules and ("*" in rules["*"] or action in rules["*"]):
        return True
    return action in rules.get(kind, set())


def permission_change_summary(before: dict | None, after: dict | None) -> str:
    """Create a compact, non-sensitive audit summary for role permission changes."""
    def normalized(value: dict | None) -> dict[str, set[str]]:
        if not isinstance(value, dict):
            return {}
        return {str(kind): {str(action) for action in (granted or [])} for kind, granted in value.items()}

    previous, current = normalized(before), normalized(after)
    added = sorted(f"{kind}:{action}" for kind in set(current) | set(previous) for action in current.get(kind, set()) - previous.get(kind, set()))
    removed = sorted(f"{kind}:{action}" for kind in set(current) | set(previous) for action in previous.get(kind, set()) - current.get(kind, set()))
    parts = [f"إضافة {len(added)} صلاحية" if added else "", f"إزالة {len(removed)} صلاحية" if removed else ""]
    details = ", ".join(item for item in parts if item)
    if added:
        details += f"؛ المضافة: {', '.join(added[:12])}"
    if removed:
        details += f"؛ المحذوفة: {', '.join(removed[:12])}"
    return details or "لا تغيير في الصلاحيات"


def record_transition_actions(kind: str, data: dict, previous: dict | None = None) -> set[str]:
    """Return workflow actions required by a record's requested state.

    Generic records remain backwards compatible with the original create/update
    permissions, while new clinical workflows can enforce separation between
    ordering, execution, review, approval, and discharge.
    """
    status = str(data.get("status", "")).strip()
    old_status = str((previous or {}).get("status", "")).strip()
    if previous is not None and status == old_status:
        return set()
    if kind == "admissions":
        return {"approve"} if status == "مقبول" else {"transfer"} if status == "محول" else {"discharge"} if status in {"خرج", "خروج ضد النصيحة"} else set()
    if kind == "lab_orders":
        return {"receive"} if status == "مستلمة" else {"reject"} if status == "مرفوضة" else {"result"} if status in {"قيد التنفيذ", "نتيجة أولية"} else {"verify"} if status == "مراجعة" else {"approve", "sign"} if status == "معتمدة" else set()
    if kind == "imaging_orders":
        return {"receive"} if status == "تم التنفيذ" else {"result"} if status == "مسودة تقرير" else {"verify"} if status == "مراجعة" else {"approve", "sign"} if status == "معتمد" else set()
    if kind in {"nursing_notes", "nursing_observations"}:
        return {"sign"} if status in {"موقعة", "مغلقة"} else set()
    if kind == "medication_administrations":
        return {"administer"} if status == "أُعطي" else set()
    if kind == "prescriptions":
        return {"verify"} if status == "مراجعة" else {"dispense"} if status == "مصروفة" else {"cancel"} if status in {"موقوفة", "ملغاة"} else set()
    if kind == "surgical_safety":
        return {"sign"} if status == "مكتملة" else set()
    if kind == "consents":
        return {"sign"} if status == "موقعة" else set()
    if kind == "referrals":
        return {"sign"} if status == "تمت" else set()
    if kind == "care_tasks":
        return {"sign"} if status == "مكتملة" else set()
    if kind == "problem_list":
        return {"sign"} if status in {"نشطة", "محلولة", "غير نشطة"} else set()
    if kind == "allergies":
        return {"verify"} if status == "متحقق منها" else set()
    if kind == "blood_requests":
        return {"dispense"} if status == "تم الصرف" else {"approve"} if status == "معتمدة" else {"verify"} if status == "تم التوافق" else set()
    if kind == "insurance_claims":
        return {"close"} if status == "مسددة" else {"submit"} if status == "مقدمة" else {"approve"} if status == "معتمدة" else set()
    if kind == "quality_events":
        return {"verify"} if status == "قيد المراجعة" else {"approve", "close"} if status == "مغلقة" else set()
    return set()


def stamp_workflow_fields(kind: str, data: dict, user: dict, previous: dict | None = None) -> None:
    """Stamp the authenticated actor and server time for workflow transitions.

    The form may display these fields for transparency, but the server is the
    authority. This prevents a user from typing another person's name or a
    client clock time into a clinical transition.
    """
    actions = record_transition_actions(kind, data, previous)
    if not actions:
        return
    actor = str(user.get("display_name") or user.get("username") or user.get("id") or "")[:160]
    stamp = now_utc()

    def set_stamp(action: str, actor_field: str, time_field: str) -> None:
        if action in actions:
            data[actor_field] = actor
            data[time_field] = stamp

    if kind == "admissions":
        set_stamp("approve", "approved_by", "approved_at")
        set_stamp("transfer", "transferred_by", "transferred_at")
        if "discharge" in actions:
            data["discharged_by"], data["discharge_at"] = actor, data.get("discharge_at") or stamp
    elif kind == "lab_orders":
        set_stamp("receive", "received_by", "received_at")
        set_stamp("reject", "rejected_by", "rejected_at")
        set_stamp("result", "result_by", "result_at")
        set_stamp("verify", "reviewed_by", "reviewed_at")
        set_stamp("approve", "approved_by", "approved_at")
        set_stamp("sign", "signed_by", "signed_at")
    elif kind == "imaging_orders":
        set_stamp("receive", "performed_by", "performed_at")
        set_stamp("result", "reported_by", "reported_at")
        set_stamp("verify", "reviewed_by", "reviewed_at")
        set_stamp("approve", "approved_by", "approved_at")
        set_stamp("sign", "signed_by", "signed_at")
    elif kind in {"nursing_notes", "nursing_observations"}:
        set_stamp("sign", "signed_by", "signed_at")
    elif kind == "medication_administrations":
        set_stamp("administer", "administered_by", "administered_at")
    elif kind == "prescriptions":
        set_stamp("verify", "verified_by", "verified_at")
        set_stamp("dispense", "dispensed_by", "dispensed_at")
        set_stamp("cancel", "cancelled_by", "cancelled_at")
    elif kind == "surgical_safety":
        set_stamp("sign", "completed_by", "completed_at")
    elif kind == "consents":
        set_stamp("sign", "signed_by", "signed_at")
    elif kind in {"referrals", "care_tasks"}:
        set_stamp("sign", "completed_by", "completed_at")
    elif kind == "problem_list":
        set_stamp("sign", "reviewed_by", "reviewed_at")
    elif kind == "allergies":
        set_stamp("verify", "verified_by", "reviewed_at")
    elif kind == "blood_requests":
        set_stamp("verify", "crossmatched_by", "crossmatched_at")
        set_stamp("approve", "approved_by", "approved_at")
        set_stamp("dispense", "issued_by", "issued_at")
    elif kind == "insurance_claims":
        set_stamp("submit", "submitted_by", "submitted_at")
        set_stamp("approve", "approved_by", "approved_at")
        set_stamp("close", "paid_by", "paid_at")
    elif kind == "quality_events":
        set_stamp("verify", "reviewed_by", "reviewed_at")
        set_stamp("approve", "approved_by", "approved_at")
        set_stamp("close", "closed_by", "closed_at")


def _normalized_medication_terms(data: dict) -> list[str]:
    raw = data.get("medication") if data.get("medication") is not None else data.get("medications", "")
    terms = []
    for value in str(raw or "").replace("\r", "\n").replace(",", "\n").split("\n"):
        term = value.strip().casefold()
        if term:
            terms.append(term)
    return terms


def validate_medication_safety(kind: str, data: dict) -> None:
    """Check structured allergies and interaction rules before medication use."""
    if kind not in {"prescriptions", "medication_administrations"}:
        return
    patient_id = str(data.get("patient_id", "")).strip()
    terms = _normalized_medication_terms(data)
    if not patient_id or not terms:
        return
    with connection() as db:
        allergies = db.execute(
            "SELECT json_extract(payload_json,'$.allergen') AS allergen FROM records "
            "WHERE kind='allergies' AND json_extract(payload_json,'$.patient_id')=? "
            "AND json_extract(payload_json,'$.status')='متحقق منها' AND status<>'archived'",
            (patient_id,),
        ).fetchall()
        interactions = db.execute(
            "SELECT json_extract(payload_json,'$.medication_a') AS medication_a, "
            "json_extract(payload_json,'$.medication_b') AS medication_b, "
            "json_extract(payload_json,'$.severity') AS severity FROM records "
            "WHERE kind='drug_interactions' AND json_extract(payload_json,'$.status')='نشط' AND status<>'archived'",
        ).fetchall()
    matched_allergens = [str(row["allergen"] or "").strip() for row in allergies if str(row["allergen"] or "").strip().casefold() in " ".join(terms)]
    if matched_allergens:
        if data.get("allergy_checked") != "توجد حساسية" or not str(data.get("allergy_override_reason", "")).strip():
            raise ValueError("يوجد مسبب حساسية مسجل للمريض؛ راجع الحساسية وسجل سبب التجاوز قبل الحفظ")
    for row in interactions:
        first = str(row["medication_a"] or "").strip().casefold()
        second = str(row["medication_b"] or "").strip().casefold()
        if first and second and any(first in term for term in terms) and any(second in term for term in terms):
            if data.get("interaction_reviewed") not in {"تمت المراجعة", "يوجد تداخل"} or (data.get("interaction_reviewed") == "يوجد تداخل" and not str(data.get("interaction_override_reason", "")).strip()):
                raise ValueError(f"يوجد تداخل دوائي مسجل ({row['severity'] or 'غير محدد'}); راجع التداخل وسجل التوصية قبل الحفظ")


def has_emergency_access(user: dict, kind: str, record_id: str) -> bool:
    with connection() as db:
        row = db.execute(
            "SELECT 1 FROM emergency_access WHERE user_id=? AND entity_kind=? AND entity_id=? AND revoked_at IS NULL AND expires_at>? ORDER BY expires_at DESC LIMIT 1",
            (str(user.get("id", "")), kind, record_id, int(time.time())),
        ).fetchone()
    return bool(row)


def role_labels() -> dict[str, str]:
    labels = dict(ROLE_LABELS)
    with connection() as db:
        for row in db.execute("SELECT code,name_ar FROM custom_roles WHERE active=1"):
            labels[row["code"]] = row["name_ar"]
    return labels


def valid_role(role: str) -> bool:
    if role in ROLE_LABELS: return True
    with connection() as db:
        return bool(db.execute("SELECT 1 FROM custom_roles WHERE code=? AND active=1", (role,)).fetchone())


def safe_record_fields(kind: str, user: dict) -> set[str] | None:
    """Return visible payload fields, None for full access, or an empty set for no access."""
    role = user["role"]
    scoped = ROLE_FIELD_SCOPES.get(role, {})
    if kind in scoped:
        return scoped[kind]
    if role == "RECEPTION":
        if kind in RECEPTION_FIELD_SCOPE:
            return RECEPTION_FIELD_SCOPE[kind]
        if kind in CLINICAL_KINDS:
            return set()
    if kind == "patients":
        if role in PATIENT_CLINICAL_ROLES:
            return None
        if role not in ROLE_PERMISSIONS and any(allowed(user, item, "view") for item in CLINICAL_KINDS):
            return None
        return PATIENT_PUBLIC_FIELDS
    if role in {"RECEPTION", "VIEWER", "AUDITOR_VIEWER"} and kind in CLINICAL_KINDS:
        return set()
    if role == "BILLING" and kind in CLINICAL_KINDS:
        return BILLING_ENCOUNTER_FIELDS if kind == "encounters" else set()
    return None


def reception_record_data(kind: str, data: dict) -> dict:
    """Restrict receptionist-created or edited records to registration/scheduling fields."""
    fields = RECEPTION_FIELD_SCOPE.get(kind)
    if fields is None:
        raise PermissionError("الاستقبال لا يملك صلاحية تعديل هذا النوع من البيانات")
    return {key: value for key, value in data.items() if key in fields}


def safe_record(row: sqlite3.Row, user: dict, emergency: bool = False) -> dict:
    data = json.loads(row["payload_json"])
    fields = None if emergency else safe_record_fields(row["kind"], user)
    if fields is not None:
        if not fields:
            return {}
        data = {key: value for key, value in data.items() if key in fields}
    return {
        "id": row["id"], "kind": row["kind"], "code": row["code"],
        "title": row["title"], "status": row["status"], "priority": row["priority"],
        "data": data, "created_at": row["created_at"], "updated_at": row["updated_at"],
        "revision": row["revision"],
    }


def dashboard_followup_worklist(user: dict, today: str | None = None) -> list[dict]:
    """Return a small, permission-filtered list of dated follow-ups for the dashboard."""
    today = today or facility_today()
    specs = (
        ("devices", "$.removal_due_at", "status NOT IN ('archived','تمت الإزالة','مفقود')", "date(json_extract(payload_json,'$.removal_due_at'))<=date(?)", (today,), True),
        ("procedures", "$.followup_at", "status NOT IN ('archived','ملغي','مؤجل','cancelled','deferred','أعيدت جدولته')", "date(json_extract(payload_json,'$.followup_at'))<=date(?)", (today,), True),
        ("specimens", "$.result_due_at", "status IN ('أُرسلت','النتيجة معلقة','sent','pending_result')", "1=1", (), False),
    )
    worklist = []
    with connection() as db:
        for kind, date_field, status_filter, date_filter, args, require_date in specs:
            if not allowed(user, kind, "view"):
                continue
            date_presence = f" AND json_extract(payload_json,'{date_field}')<>''" if require_date else ""
            rows = db.execute(
                "SELECT * FROM records WHERE kind=? AND " + status_filter + " AND " + date_filter +
                date_presence + " "
                f"ORDER BY CASE WHEN date(json_extract(payload_json,'{date_field}'))<=date(?) THEN 0 ELSE 1 END, "
                f"CASE WHEN json_extract(payload_json,'{date_field}')='' THEN 1 ELSE 0 END, "
                f"date(json_extract(payload_json,'{date_field}')), updated_at DESC LIMIT 8",
                (kind, *args, today),
            ).fetchall()
            for row in rows:
                record = safe_record(row, user)
                data = record.get("data", {}) if record else {}
                due_at = str(data.get(date_field.rsplit(".", 1)[-1], "") or "")
                if require_date and not due_at:
                    continue
                detail_field = {"devices": "device_type", "procedures": "procedure_type", "specimens": "specimen_type"}[kind]
                default_detail = {"devices": "دعامة أو قسطرة", "procedures": "متابعة إجراء", "specimens": "عينة"}[kind]
                worklist.append({
                    "kind": kind,
                    "patient_name": str(data.get("patient_name") or "مريض")[:120],
                    "detail": str(data.get(detail_field) or default_detail)[:120],
                    "due_at": due_at[:40],
                    "status": str(data.get("status") or record.get("status") or "")[:80],
                    "overdue": bool(due_at and due_at[:10] <= today),
                    "date_missing": not bool(due_at),
                })
    worklist.sort(key=lambda item: (not item["overdue"], item["date_missing"], item["due_at"]))
    return worklist[:20]


PATIENT_JOURNEY_KINDS = (
    "appointments", "waiting", "encounters", "triage", "procedures", "beds",
    "lab_results", "imaging", "stones", "prescriptions", "devices", "specimens",
    "attachments", "invoices", "complaints", "admissions", "lab_orders", "imaging_orders",
    "nursing_notes", "nursing_observations", "medication_administrations", "surgical_safety", "consents", "referrals", "care_tasks",
    "problem_list", "allergies", "blood_requests", "insurance_claims", "quality_events",
)
PATIENT_JOURNEY_DATES = {
    "appointments": ("scheduled_at",), "waiting": ("requested_at",),
    "encounters": ("admitted_at", "discharged_at"), "triage": ("created_at",),
    "procedures": ("scheduled_at", "followup_at"), "beds": (),
    "lab_results": ("scheduled_at",), "imaging": ("scheduled_at",),
    "stones": ("scheduled_at",), "prescriptions": (),
    "devices": ("placed_at", "removal_due_at", "removed_at"),
    "specimens": ("collected_at", "result_due_at", "reviewed_at"),
    "attachments": (), "invoices": ("submitted_at",),
    "complaints": ("submitted_at", "resolved_at"), "admissions": ("requested_at", "admission_at", "discharge_at"),
    "lab_orders": ("ordered_at", "collected_at", "result_at", "reviewed_at"),
    "imaging_orders": ("ordered_at", "scheduled_at", "performed_at", "reported_at"),
    "nursing_notes": ("created_at", "signed_at"), "nursing_observations": ("observed_at", "signed_at"), "medication_administrations": ("scheduled_at", "administered_at"),
    "surgical_safety": ("completed_at",), "consents": ("created_at", "signed_at"),
    "referrals": ("referred_at", "completed_at"), "care_tasks": ("due_at", "completed_at"),
    "problem_list": ("onset_at", "resolved_at", "reviewed_at"), "allergies": ("identified_at", "reviewed_at"),
    "blood_requests": ("requested_at", "crossmatched_at", "issued_at"), "insurance_claims": ("submitted_at", "approved_at", "paid_at"),
    "quality_events": ("event_at", "reviewed_at", "closed_at"),
}
PATIENT_JOURNEY_CAPTIONS = {
    "appointments": ("type", "doctor", "room"),
    "waiting": ("procedure_type", "priority"),
    "encounters": ("encounter_type", "visit_type", "attending_doctor"),
    "triage": ("triage_level",), "procedures": ("category", "procedure_type", "room"),
    "beds": ("room", "bed_code", "bed_status"),
    "lab_results": ("lab_type",), "imaging": ("type",),
    "stones": ("location", "side"), "prescriptions": (),
    "devices": ("device_type", "side"), "specimens": ("specimen_type",),
    "attachments": (), "invoices": ("package", "claim_status"),
    "complaints": (), "admissions": ("admission_type", "room", "bed_code", "status"),
    "lab_orders": ("test_name", "priority", "status", "result"), "imaging_orders": ("imaging_type", "priority", "status", "report"),
    "nursing_notes": ("note_type", "author", "status"), "nursing_observations": ("temperature", "pulse", "spo2", "status", "recorded_by"), "medication_administrations": ("medication", "dose", "status"),
    "surgical_safety": ("phase", "status"), "consents": ("consent_type", "decision", "status"),
    "referrals": ("destination", "reason", "status"), "care_tasks": ("task", "assigned_to", "status"),
    "problem_list": ("problem", "code", "status"), "allergies": ("allergen", "severity", "status"),
    "blood_requests": ("component", "blood_group", "units", "status"), "insurance_claims": ("payer", "claim_no", "status"),
    "quality_events": ("event_type", "severity", "status"),
}


def patient_journey(patient_id: str, user: dict) -> dict | None:
    """Build a minimal, permission-filtered timeline from existing patient-linked records."""
    if not allowed(user, "patients", "view"):
        raise PermissionError("ليست لديك صلاحية عرض ملف المريض")
    patient_id = str(patient_id or "").strip()
    if not patient_id or len(patient_id) > 160:
        return None
    placeholders = ",".join("?" for _ in PATIENT_JOURNEY_KINDS)
    with connection() as db:
        patient_row = db.execute(
            "SELECT * FROM records WHERE id=? AND kind='patients'", (patient_id,)
        ).fetchone()
        if not patient_row:
            return None
        rows = db.execute(
            f"SELECT * FROM records WHERE kind IN ({placeholders}) "
            "AND json_valid(payload_json) "
            "AND json_extract(payload_json, '$.patient_id')=? "
            "ORDER BY updated_at DESC LIMIT 1000",
            (*PATIENT_JOURNEY_KINDS, patient_id),
        ).fetchall()

    patient_record = safe_record(patient_row, user)
    patient_data = patient_record.get("data", {})
    public_patient = {
        key: patient_data[key]
        for key in ("name_ar", "name_en", "file_code")
        if patient_data.get(key)
    }
    timeline = []
    visible_counts: dict[str, int] = {}
    for row in rows:
        kind = row["kind"]
        if not allowed(user, kind, "view"):
            continue
        record = safe_record(row, user)
        if not record:
            continue
        data = record["data"]
        if data.get("patient_id") != patient_id:
            continue
        occurred_at = next(
            (str(data[field]) for field in PATIENT_JOURNEY_DATES[kind]
             if data.get(field)),
            record["created_at"],
        )
        caption_parts = []
        for field in PATIENT_JOURNEY_CAPTIONS[kind]:
            value = data.get(field)
            if isinstance(value, (str, int, float)) and str(value).strip():
                caption_parts.append(str(value).strip()[:100])
        status = data.get("status") or record.get("status") or ""
        timeline.append({
            "kind": kind,
            "occurred_at": occurred_at,
            "updated_at": record["updated_at"],
            "status": str(status)[:80],
            "caption": " · ".join(caption_parts),
        })
        visible_counts[kind] = visible_counts.get(kind, 0) + 1

    timeline.sort(key=lambda event: (event["occurred_at"], event["updated_at"]), reverse=True)
    audit_sensitive_read(user, "patients", patient_id)
    for kind, count in visible_counts.items():
        audit_sensitive_read(user, kind, count=count)
    return {"patient": public_patient, "timeline": timeline, "total": len(timeline)}


FHIR_PATIENT_KINDS = {
    "encounters", "appointments", "procedures", "lab_orders", "imaging_orders",
    "prescriptions", "medication_administrations", "problem_list", "allergies",
    "admissions", "referrals", "insurance_claims", "quality_events",
}


def _fhir_id(value: str) -> str:
    """Return a safe, stable FHIR id without exposing arbitrary path characters."""
    cleaned = "".join(char for char in str(value or "") if char.isalnum() or char in "-.")
    return (cleaned or str(uuid.uuid4())).lower()[:64]


def _fhir_text(value) -> dict | None:
    text = str(value or "").strip()
    return {"text": text[:1000]} if text else None


def _fhir_reference(resource_type: str, value: str, display: str = "") -> dict:
    result = {"reference": f"{resource_type}/{_fhir_id(value)}"}
    if display:
        result["display"] = str(display)[:200]
    return result


def _fhir_resource(kind: str, record_id: str, data: dict, patient_resource_id: str) -> dict | None:
    """Map local-first records to a conservative FHIR R4-compatible resource."""
    resource_id = _fhir_id(record_id)
    patient_ref = _fhir_reference("Patient", patient_resource_id, data.get("patient_name", ""))
    status = str(data.get("status") or "unknown").strip()
    if kind == "problem_list":
        status_map = {"نشطة": "active", "محلولة": "resolved", "غير نشطة": "inactive"}
        resource = {"resourceType": "Condition", "id": resource_id,
                    "clinicalStatus": {"coding": [{"system": "http://terminology.hl7.org/CodeSystem/condition-clinical", "code": status_map.get(status, "unknown")}]},
                    "subject": patient_ref, "code": {"text": str(data.get("problem", ""))[:500]}}
        if data.get("code"):
            resource["code"]["coding"] = [{"system": str(data.get("code_system") or "urn:urocare:local"), "code": str(data["code"])[:100]}]
        if data.get("onset_at"): resource["onsetDateTime"] = str(data["onset_at"])
        if data.get("resolved_at"): resource["abatementDateTime"] = str(data["resolved_at"])
        return resource
    if kind == "allergies":
        status_map = {"متحقق منها": "confirmed", "مشتبه بها": "unconfirmed", "غير نشطة": "inactive", "منفية": "refuted"}
        resource = {"resourceType": "AllergyIntolerance", "id": resource_id,
                    "clinicalStatus": {"coding": [{"system": "http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical", "code": "inactive" if status == "غير نشطة" else "active"}]},
                    "verificationStatus": {"coding": [{"system": "http://terminology.hl7.org/CodeSystem/allergyintolerance-verification", "code": status_map.get(status, "unconfirmed")}]},
                    "patient": patient_ref, "code": {"text": str(data.get("allergen", ""))[:300]},
                    "reaction": [{"manifestation": [{"text": str(data.get("reaction", ""))[:300]}], "severity": str(data.get("severity", "")).lower() or "moderate"}]}
        if data.get("identified_at"): resource["recordedDate"] = str(data["identified_at"])
        return resource
    if kind in {"encounters", "admissions"}:
        status_map = {"خرج": "finished", "ملغي": "cancelled", "مقبول": "planned", "منوم": "in-progress", "محول": "in-progress"}
        return {"resourceType": "Encounter", "id": resource_id, "status": status_map.get(status, "unknown"),
                "class": {"code": "IMP" if kind == "admissions" else "AMB", "display": "Inpatient" if kind == "admissions" else "Ambulatory"},
                "subject": patient_ref, "period": {key: str(data[key]) for key in ("admission_at", "discharge_at", "admitted_at", "discharged_at") if data.get(key)},
                "reasonCode": [{"text": str(data.get("admission_type") or data.get("encounter_type") or "")[:300]}]}
    if kind == "appointments":
        status_map = {"محجوز": "booked", "مؤكد": "booked", "حضر": "fulfilled", "لم يحضر": "noshow", "ملغي": "cancelled"}
        return {"resourceType": "Appointment", "id": resource_id, "status": status_map.get(status, "proposed"),
                "subject": patient_ref, "start": str(data.get("scheduled_at", "")),
                "description": str(data.get("type") or data.get("procedure_type") or "")[:300]}
    if kind == "procedures":
        status_map = {"مكتمل": "completed", "ملغي": "not-done", "بدأ": "in-progress", "مؤجل": "stopped"}
        return {"resourceType": "Procedure", "id": resource_id, "status": status_map.get(status, "unknown"),
                "subject": patient_ref, "code": {"text": str(data.get("procedure_type") or "")[:500]},
                "performedDateTime": str(data.get("scheduled_at") or data.get("performed_at") or ""),
                "note": [{"text": str(data.get("findings") or data.get("operative_note") or "")[:1000]}] if (data.get("findings") or data.get("operative_note")) else []}
    if kind in {"lab_orders", "imaging_orders"}:
        report = data.get("report") or data.get("result") or ""
        return {"resourceType": "DiagnosticReport", "id": resource_id, "status": "final" if status in {"معتمدة", "معتمد"} else "preliminary",
                "subject": patient_ref, "code": {"text": str(data.get("test_name") or data.get("imaging_type") or "")[:500]},
                "effectiveDateTime": str(data.get("result_at") or data.get("reported_at") or data.get("performed_at") or ""),
                "conclusion": str(report)[:2000]}
    if kind == "prescriptions":
        status_map = {"مسودة": "draft", "مكتوبة": "active", "مراجعة": "active", "مصروفة": "active", "موقوفة": "on-hold", "ملغاة": "cancelled"}
        dosage = " · ".join(str(data.get(key, "")).strip() for key in ("dose", "route", "frequency", "duration") if data.get(key))
        return {"resourceType": "MedicationRequest", "id": resource_id, "status": status_map.get(status, "unknown"), "intent": "order",
                "subject": patient_ref, "medicationCodeableConcept": {"text": str(data.get("medications", ""))[:1000]},
                "dosageInstruction": [{"text": dosage[:1000]}] if dosage else []}
    if kind == "medication_administrations":
        status_map = {"أُعطي": "completed", "مرفوض": "stopped", "لم يُعط": "not-done", "ملغى": "entered-in-error", "مجدول": "in-progress"}
        return {"resourceType": "MedicationAdministration", "id": resource_id, "status": status_map.get(status, "unknown"),
                "subject": patient_ref, "medicationCodeableConcept": {"text": str(data.get("medication", ""))[:500]},
                "effectiveDateTime": str(data.get("administered_at") or data.get("scheduled_at") or "")}
    if kind == "insurance_claims":
        return {"resourceType": "Claim", "id": resource_id, "status": "active" if status not in {"مسددة", "ملغاة", "مرفوضة"} else ("cancelled" if status == "ملغاة" else "active"),
                "use": "claim", "patient": patient_ref, "insurer": {"display": str(data.get("payer", ""))[:300]},
                "total": {"value": float(data.get("amount", 0) or 0), "currency": "EGP"}}
    if kind == "quality_events":
        return {"resourceType": "AdverseEvent", "id": resource_id, "actuality": "actual", "subject": patient_ref,
                "event": {"text": str(data.get("event_type", ""))[:300]}, "description": str(data.get("description", ""))[:2000],
                "recordedDate": str(data.get("event_at") or "")}
    if kind == "referrals":
        return {"resourceType": "ServiceRequest", "id": resource_id, "status": "completed" if status == "تمت" else "active", "intent": "order",
                "subject": patient_ref, "code": {"text": str(data.get("reason", ""))[:500]}, "performer": [{"display": str(data.get("destination", ""))[:300]}]}
    return None


def fhir_patient_bundle(patient_id: str, user: dict) -> dict:
    """Export a permission-filtered patient bundle for offline exchange.

    This is an export boundary, not a live HL7/DICOM/PACS connector. External
    systems still need their endpoint, authentication, mapping, and acceptance
    rules configured by the facility.
    """
    if not allowed(user, "patients", "export"):
        raise PermissionError("ليست لديك صلاحية تصدير ملف المريض بصيغة FHIR")
    with connection() as db:
        patient = db.execute("SELECT * FROM records WHERE id=? AND kind='patients'", (str(patient_id),)).fetchone()
        if not patient:
            raise ValueError("ملف المريض غير موجود")
        rows = db.execute("SELECT * FROM records WHERE json_extract(payload_json,'$.patient_id')=? AND kind IN (" + ",".join("?" for _ in FHIR_PATIENT_KINDS) + ") ORDER BY created_at", (str(patient_id), *sorted(FHIR_PATIENT_KINDS))).fetchall()
    patient_data = json.loads(patient["payload_json"])
    patient_resource_id = _fhir_id(patient["id"])
    gender_map = {"ذكر": "male", "أنثى": "female"}
    patient_resource = {"resourceType": "Patient", "id": patient_resource_id,
                        "identifier": [], "name": [{"text": str(patient_data.get("name_ar") or patient_data.get("name_en") or "")[:300]}],
                        "gender": gender_map.get(patient_data.get("gender"), "unknown")}
    if patient_data.get("national_id"):
        patient_resource["identifier"].append({"system": "urn:eg:emr:national-id", "value": str(patient_data["national_id"])})
    if patient_data.get("identity_document_no"):
        patient_resource["identifier"].append({"system": "urn:urocare:identity-document", "value": str(patient_data["identity_document_no"])})
    if patient_data.get("dob"): patient_resource["birthDate"] = str(patient_data["dob"])
    if patient_data.get("phone"): patient_resource["telecom"] = [{"system": "phone", "value": str(patient_data["phone"])}]
    entries = [{"fullUrl": f"urn:uuid:{patient_resource_id}", "resource": patient_resource}]
    for row in rows:
        kind = row["kind"]
        if not allowed(user, kind, "export") and user["role"] not in {OWNER, "ADMIN"}:
            continue
        resource = _fhir_resource(kind, row["id"], json.loads(row["payload_json"]), patient_resource_id)
        if resource:
            entries.append({"fullUrl": f"urn:uuid:{resource['id']}", "resource": resource})
    audit(user, "fhir_export", "patients", str(patient_id), f"تصدير حزمة FHIR للمريض ({len(entries)} موردًا)")
    return {"resourceType": "Bundle", "id": str(uuid.uuid4()), "type": "collection", "timestamp": now_utc(),
            "meta": {"tag": [{"system": "urn:urocare", "code": "offline-export", "display": "UroCare offline export"}]},
            "entry": entries}


PRINT_FIELDS = {
    "patients": ("file_code", "name_ar", "name_en", "nationality", "nationality_country", "national_id", "identity_document_type", "identity_document_no", "gender", "dob", "phone", "address", "emergency_contact", "blood_group", "contact_preference", "communication_consent", "consent_at", "allergies", "chronic_diseases", "insurance", "medical_history", "surgical_history", "family_history", "notes"),
    "appointments": ("patient_name", "type", "scheduled_at", "doctor", "room", "duration_min", "status", "cancel_reason", "notes"),
    "waiting": ("patient_name", "encounter_type", "procedure_type", "priority", "requested_at", "expected_days", "actual_days", "status", "cancel_reason", "notes"),
    "procedures": ("patient_name", "category", "procedure_type", "scheduled_at", "surgeon", "assistant", "anesthesia", "room", "duration_min", "side", "pre_diag", "consent_status", "fasting_status", "anticoagulants_reviewed", "asa_score", "anesthesia_assessment", "renal_function_reviewed", "antibiotic_plan", "post_diag", "findings", "operative_note", "complications", "post_op_plan", "discharge_status", "discharge_instructions", "followup_at", "preparation_checklist", "status", "signed_by", "signed_at", "notes"),
    "encounters": ("patient_name", "encounter_type", "visit_type", "admitted_at", "discharged_at", "attending_doctor", "referral_source", "triage_level", "status", "diagnosis", "plan", "discharge_summary", "signed_by", "signed_at"),
    "triage": ("patient_name", "triage_level", "vitals", "complaints", "status", "notes", "created_at"),
    "invoices": ("patient_name", "encounter_id", "package", "insurance_company", "policy_no", "claim_no", "claim_status", "amount", "approved_amount", "paid", "status", "submitted_at", "notes"),
    "devices": ("patient_name", "device_type", "side", "placed_at", "removal_due_at", "removed_at", "placed_by", "responsible_doctor", "status", "notes"),
    "specimens": ("patient_name", "specimen_type", "collected_at", "sent_to_lab", "tracking_no", "result_due_at", "status", "result", "reviewed_by", "reviewed_at", "notes"),
    "sterilization": ("item_name", "batch_no", "cycle_at", "method", "operator", "biological_indicator", "release_status", "expiry_at", "notes"),
    "maintenance": ("asset_name", "asset_code", "maintenance_type", "performed_at", "next_due_at", "performed_by", "vendor", "status", "notes"),
    "inventory": ("item_name", "item_code", "category", "unit", "quantity", "reorder_level", "expiry_at", "location", "supplier", "status", "notes"),
    "inventory_movements": ("item_name", "item_code", "movement_type", "quantity", "balance_before", "balance_after", "movement_at", "performed_by", "reason", "reference_no", "notes"),
    "complaints": ("patient_name", "patient_id", "submitted_at", "channel", "subject", "description", "priority", "assigned_to", "resolution", "resolved_at", "satisfaction_rating", "feedback_type", "status"),
    "training": ("user_name", "username", "module_name", "trainer", "training_at", "expires_at", "assessment_score", "status", "notes"),
    "prescriptions": ("patient_name", "medications", "dose", "route", "frequency", "duration", "indication", "allergy_checked", "allergy_override_reason", "interaction_reviewed", "interaction_override_reason", "status", "dispensed_by", "dispensed_at", "reason", "signed_by", "signed_at", "notes"),
    "admissions": ("patient_name", "admission_type", "status", "requested_at", "admission_at", "admitting_doctor", "room", "bed_code", "transfer_from", "transfer_to", "discharge_at", "discharged_by", "discharge_summary", "discharge_instructions", "signed_by", "signed_at", "notes"),
    "lab_orders": ("patient_name", "test_name", "priority", "ordered_by", "ordered_at", "specimen_type", "collected_at", "status", "rejection_reason", "result", "result_unit", "reference_range", "critical_value", "reviewed_by", "reviewed_at", "signed_by", "signed_at", "notes"),
    "imaging_orders": ("patient_name", "imaging_type", "priority", "ordered_by", "ordered_at", "scheduled_at", "status", "performed_at", "report", "reported_by", "reported_at", "signed_by", "signed_at", "notes"),
    "nursing_notes": ("patient_name", "note_type", "note", "vitals", "author", "status", "signed_by", "signed_at", "notes"),
    "nursing_observations": ("patient_name", "observed_at", "temperature", "pulse", "respiratory_rate", "systolic", "diastolic", "spo2", "pain_score", "consciousness", "oxygen_support", "note", "recorded_by", "status", "signed_by", "signed_at", "notes"),
    "medication_administrations": ("patient_name", "medication", "dose", "route", "scheduled_at", "status", "administered_at", "administered_by", "reason", "allergy_checked", "allergy_override_reason", "interaction_reviewed", "interaction_override_reason", "notes"),
    "surgical_safety": ("patient_name", "procedure_id", "phase", "status", "identity_confirmed", "site_confirmed", "consent_confirmed", "team_confirmed", "allergies_reviewed", "antibiotic_time", "specimen_labeling_confirmed", "completed_by", "completed_at", "exception_reason", "notes"),
    "consents": ("patient_name", "consent_type", "procedure_id", "decision", "status", "signed_by", "signed_at", "witness", "refusal_reason", "document_id", "notes"),
    "referrals": ("patient_name", "destination", "reason", "referred_by", "referred_at", "priority", "status", "outcome", "completed_at", "notes"),
    "care_tasks": ("patient_name", "task", "assigned_to", "due_at", "priority", "status", "completed_by", "completed_at", "notes"),
    "problem_list": ("patient_name", "problem", "code_system", "code", "onset_at", "status", "resolved_at", "recorded_by", "reviewed_at", "notes"),
    "allergies": ("patient_name", "allergen", "reaction", "severity", "identified_at", "status", "verified_by", "reviewed_at", "notes"),
    "formulary": ("generic_name", "brand_name", "strength", "route", "form", "code", "high_alert", "active", "contraindications", "notes"),
    "drug_interactions": ("medication_a", "medication_b", "severity", "mechanism", "recommendation", "active", "reviewed_by", "reviewed_at", "notes"),
    "blood_requests": ("patient_name", "component", "blood_group", "units", "requested_by", "requested_at", "status", "crossmatch_result", "crossmatched_at", "issued_at", "notes"),
    "insurance_claims": ("patient_name", "payer", "policy_no", "claim_no", "invoice_id", "submitted_at", "status", "amount", "approved_amount", "rejected_reason", "paid_at", "notes"),
    "quality_events": ("patient_name", "event_type", "severity", "event_at", "description", "immediate_action", "corrective_action", "reported_by", "status", "reviewed_by", "closed_at", "notes"),
}
PRINT_LABELS = {
    "file_code": ("رقم الملف", "File number"), "name_ar": ("الاسم بالعربية", "Arabic name"),
    "name_en": ("الاسم بالإنجليزية", "English name"), "national_id": ("الرقم القومي", "National ID"),
    "nationality": ("الجنسية", "Nationality"), "nationality_country": ("الدولة / الجنسية", "Country / nationality"),
    "identity_document_type": ("نوع وثيقة الهوية", "Identity document type"), "identity_document_no": ("رقم وثيقة الهوية", "Identity document number"),
    "gender": ("النوع", "Gender"), "dob": ("تاريخ الميلاد", "Date of birth"), "phone": ("الهاتف", "Phone"),
    "address": ("العنوان", "Address"), "emergency_contact": ("جهة اتصال للطوارئ", "Emergency contact"),
    "contact_preference": ("طريقة التواصل المفضلة", "Preferred contact method"),
    "communication_consent": ("الموافقة على الرسائل", "Communication consent"),
    "consent_at": ("تاريخ الموافقة", "Consent date"),
    "blood_group": ("فصيلة الدم", "Blood group"), "allergies": ("الحساسية", "Allergies"),
    "chronic_diseases": ("الأمراض المزمنة", "Chronic conditions"), "insurance": ("التأمين", "Insurance"),
    "medical_history": ("التاريخ المرضي", "Medical history"), "surgical_history": ("التاريخ الجراحي", "Surgical history"),
    "family_history": ("التاريخ العائلي", "Family history"), "notes": ("ملاحظات", "Notes"),
    "patient_name": ("المريض", "Patient"), "type": ("نوع الحجز", "Appointment type"),
    "scheduled_at": ("موعد الحجز", "Scheduled at"), "doctor": ("الطبيب", "Doctor"), "room": ("الغرفة", "Room"),
    "duration_min": ("المدة بالدقائق", "Duration (minutes)"), "status": ("الحالة", "Status"),
    "cancel_reason": ("سبب الإلغاء أو التأجيل", "Cancellation or delay reason"),
    "encounter_type": ("نوع الدخول", "Encounter type"), "procedure_type": ("الإجراء", "Procedure"),
    "priority": ("الأولوية", "Priority"), "requested_at": ("تاريخ الطلب", "Request date"),
    "expected_days": ("مدة الانتظار المتوقعة بالأيام", "Expected wait (days)"),
    "actual_days": ("مدة الانتظار الحالية بالأيام", "Current wait (days)"), "category": ("التصنيف", "Category"),
    "surgeon": ("الجراح", "Surgeon"), "assistant": ("مساعد الجراح", "Assistant"),
    "anesthesia": ("التخدير", "Anesthesia"), "side": ("الجهة", "Side"),
    "pre_diag": ("التشخيص قبل الإجراء", "Pre-procedure diagnosis"),
    "post_diag": ("التشخيص بعد الإجراء", "Post-procedure diagnosis"), "findings": ("النتائج", "Findings"),
    "complications": ("المضاعفات", "Complications"), "consent_status": ("حالة الموافقة المستنيرة", "Consent status"), "fasting_status": ("حالة الصيام والتحضير", "Fasting / preparation status"), "anticoagulants_reviewed": ("مراجعة أدوية السيولة", "Anticoagulants reviewed"), "asa_score": ("تصنيف خطورة التخدير ASA", "ASA anesthesia risk"), "anesthesia_assessment": ("تقييم التخدير", "Anesthesia assessment"), "renal_function_reviewed": ("مراجعة وظائف الكلى", "Renal function reviewed"), "antibiotic_plan": ("خطة المضاد الحيوي الوقائي", "Prophylactic antibiotic plan"), "operative_note": ("مذكرة الإجراء", "Operative note"), "post_op_plan": ("خطة ما بعد الإجراء", "Post-procedure plan"), "discharge_status": ("حالة الخروج", "Discharge status"), "discharge_instructions": ("تعليمات الخروج", "Discharge instructions"), "followup_at": ("موعد المتابعة", "Follow-up date"), "preparation_checklist": ("قائمة تحضير الإجراء", "Procedure preparation checklist"), "signed_by": ("اعتمد بواسطة", "Signed by"), "signed_at": ("وقت الاعتماد", "Signed at"), "visit_type": ("نوع الزيارة", "Visit type"),
    "admitted_at": ("تاريخ الدخول", "Admission date"), "discharged_at": ("تاريخ الخروج", "Discharge date"),
    "attending_doctor": ("الطبيب المعالج", "Attending doctor"), "referral_source": ("مصدر التحويل", "Referral source"),
    "triage_level": ("مستوى الفرز", "Triage level"), "diagnosis": ("التشخيص", "Diagnosis"),
    "plan": ("الخطة العلاجية", "Care plan"), "discharge_summary": ("ملخص الخروج", "Discharge summary"),
    "vitals": ("العلامات الحيوية", "Vital signs"), "complaints": ("الشكوى", "Presenting complaint"),
    "created_at": ("تاريخ التسجيل", "Created at"), "observed_at": ("وقت القياس", "Observation time"), "temperature": ("الحرارة", "Temperature"), "pulse": ("النبض", "Pulse"), "respiratory_rate": ("معدل التنفس", "Respiratory rate"), "systolic": ("الضغط الانقباضي", "Systolic pressure"), "diastolic": ("الضغط الانبساطي", "Diastolic pressure"), "spo2": ("تشبع الأكسجين", "Oxygen saturation"), "pain_score": ("درجة الألم", "Pain score"), "consciousness": ("درجة الوعي", "Consciousness"), "oxygen_support": ("دعم الأكسجين", "Oxygen support"), "recorded_by": ("سجلها", "Recorded by"), "encounter_id": ("رقم الزيارة", "Encounter number"),
    "package": ("الباقة", "Package"), "amount": ("الإجمالي", "Total amount"), "paid": ("المدفوع", "Paid amount"),
    "insurance_company": ("شركة التأمين", "Insurance company"), "policy_no": ("رقم الوثيقة", "Policy number"), "claim_no": ("رقم المطالبة", "Claim number"), "claim_status": ("حالة المطالبة", "Claim status"), "approved_amount": ("المبلغ المعتمد", "Approved amount"), "submitted_at": ("تاريخ تقديم المطالبة", "Claim submitted at"),
    "device_type": ("نوع الدعامة أو القسطرة", "Device type"), "placed_at": ("تاريخ التركيب", "Placement date"),
    "removal_due_at": ("موعد الإزالة أو المراجعة", "Removal / review due"), "removed_at": ("تاريخ الإزالة", "Removal date"),
    "placed_by": ("تم التركيب بواسطة", "Placed by"), "responsible_doctor": ("الطبيب المسؤول", "Responsible doctor"),
    "specimen_type": ("نوع العينة", "Specimen type"), "collected_at": ("تاريخ جمع العينة", "Collected at"),
    "sent_to_lab": ("المعمل المستلم", "Receiving laboratory"), "tracking_no": ("رقم متابعة العينة", "Specimen tracking number"),
    "result_due_at": ("الموعد المتوقع للنتيجة", "Expected result date"), "result": ("النتيجة", "Result"),
    "reviewed_by": ("تمت المراجعة بواسطة", "Reviewed by"), "reviewed_at": ("تاريخ المراجعة", "Reviewed at"),
    "item_name": ("اسم الأداة أو الحمولة", "Item / load name"), "batch_no": ("رقم دفعة التعقيم", "Sterilization batch"), "cycle_at": ("تاريخ دورة التعقيم", "Sterilization cycle"), "method": ("طريقة التعقيم", "Sterilization method"), "operator": ("مسؤول التعقيم", "Sterilization operator"), "biological_indicator": ("مؤشر حيوي", "Biological indicator"), "release_status": ("حالة الإفراج", "Release status"), "expiry_at": ("تاريخ انتهاء الصلاحية", "Expiry date"), "asset_name": ("اسم الأصل أو الجهاز", "Asset name"), "asset_code": ("كود الأصل", "Asset code"), "maintenance_type": ("نوع الصيانة", "Maintenance type"), "performed_at": ("تاريخ التنفيذ", "Performed at"), "next_due_at": ("موعد الصيانة القادمة", "Next due"), "performed_by": ("نفذها", "Performed by"), "vendor": ("المورد أو الشركة", "Vendor"), "item_code": ("كود الصنف", "Item code"), "unit": ("وحدة القياس", "Unit"), "quantity": ("الكمية الحالية", "Current quantity"), "reorder_level": ("حد إعادة الطلب", "Reorder level"), "expiry_at": ("تاريخ الصلاحية", "Expiry date"), "location": ("مكان التخزين", "Storage location"), "supplier": ("المورد", "Supplier"), "submitted_at": ("تاريخ الشكوى", "Submitted at"), "channel": ("قناة الاستلام", "Received through"), "subject": ("موضوع الشكوى", "Subject"), "description": ("تفاصيل الشكوى", "Complaint details"), "assigned_to": ("المسؤول", "Assigned to"), "resolution": ("الإجراء التصحيحي", "Resolution"), "resolved_at": ("تاريخ الحل", "Resolved at"),
}
PRINT_LABELS.update({"movement_type": ("نوع الحركة", "Movement type"), "movement_at": ("تاريخ الحركة", "Movement date"), "reference_no": ("رقم المرجع", "Reference number"), "reason": ("السبب", "Reason"), "balance_before": ("الرصيد قبل الحركة", "Balance before"), "balance_after": ("الرصيد بعد الحركة", "Balance after"), "satisfaction_rating": ("تقييم الرضا", "Satisfaction rating"), "feedback_type": ("نوع الملاحظة", "Feedback type"), "user_name": ("المستخدم", "User"), "username": ("اسم الدخول", "Username"), "module_name": ("الوحدة أو التدريب", "Module / training"), "trainer": ("المدرب", "Trainer"), "training_at": ("تاريخ التدريب", "Training date"), "expires_at": ("تاريخ انتهاء الاعتماد", "Qualification expiry"), "assessment_score": ("درجة التقييم", "Assessment score")})
PRINT_LABELS.update({
    "problem": ("المشكلة أو التشخيص", "Problem or diagnosis"), "code_system": ("نظام الترميز", "Code system"), "code": ("الكود", "Code"), "onset_at": ("تاريخ البداية", "Onset date"), "resolved_at": ("تاريخ الحل", "Resolved date"), "recorded_by": ("سجلها", "Recorded by"),
    "allergen": ("مسبب الحساسية", "Allergen"), "reaction": ("نوع التفاعل", "Reaction"), "severity": ("الشدة", "Severity"), "identified_at": ("تاريخ التعرف", "Identified at"), "verified_by": ("تحقق منها", "Verified by"),
    "generic_name": ("الاسم العلمي", "Generic name"), "brand_name": ("الاسم التجاري", "Brand name"), "strength": ("التركيز", "Strength"), "form": ("الشكل الصيدلي", "Dosage form"), "high_alert": ("دواء عالي الخطورة", "High-alert medication"), "active": ("نشط", "Active"), "contraindications": ("موانع الاستعمال", "Contraindications"),
    "medication_a": ("الدواء الأول", "Medication A"), "medication_b": ("الدواء الثاني", "Medication B"), "mechanism": ("آلية التداخل", "Interaction mechanism"), "recommendation": ("التوصية", "Recommendation"),
    "component": ("مكون الدم", "Blood component"), "blood_group": ("فصيلة الدم", "Blood group"), "units": ("عدد الوحدات", "Units"), "requested_by": ("طالب الدم", "Requested by"), "requested_at": ("وقت الطلب", "Requested at"), "crossmatch_result": ("نتيجة التوافق", "Crossmatch result"), "crossmatched_at": ("وقت التوافق", "Crossmatched at"), "issued_at": ("وقت الصرف", "Issued at"),
    "payer": ("جهة التأمين", "Payer"), "invoice_id": ("رقم الفاتورة", "Invoice ID"), "approved_at": ("وقت الاعتماد", "Approved at"), "rejected_reason": ("سبب الرفض", "Rejection reason"), "paid_at": ("وقت السداد", "Paid at"),
    "event_type": ("نوع حدث الجودة", "Quality event type"), "event_at": ("وقت الحدث", "Event time"), "immediate_action": ("الإجراء الفوري", "Immediate action"), "corrective_action": ("الإجراء التصحيحي", "Corrective action"),
})
PRINT_TITLES = {
    "patients": ("ملخص ملف المريض", "Patient record summary"),
    "appointments": ("ملخص الحجز", "Appointment summary"), "waiting": ("ملخص قائمة الانتظار", "Waiting list summary"),
    "procedures": ("ملخص العملية أو المنظار", "Procedure / endoscopy summary"),
    "encounters": ("ملخص الزيارة", "Encounter summary"), "triage": ("ملخص الفرز والطوارئ", "Triage summary"),
    "invoices": ("ملخص الفاتورة", "Invoice summary"), "devices": ("متابعة دعامة أو قسطرة", "Device follow-up summary"),
    "specimens": ("متابعة العينة", "Specimen follow-up summary"),
    "sterilization": ("سجل التعقيم", "Sterilization record"), "maintenance": ("صيانة الأدوات والأجهزة", "Equipment maintenance"),
    "inventory": ("سجل المخزون", "Inventory record"), "inventory_movements": ("حركة المخزون", "Inventory movement"), "complaints": ("شكوى أو ملاحظة مريض", "Patient complaint"), "training": ("تدريب واعتماد المستخدمين", "User training and qualification"),
    "admissions": ("سجل الدخول والخروج", "Admission and discharge record"), "lab_orders": ("طلب وتحليل معمل", "Laboratory order"), "imaging_orders": ("طلب وتقرير أشعة", "Imaging order"),
    "nursing_notes": ("ملاحظة تمريض", "Nursing note"), "medication_administrations": ("سجل إعطاء دواء", "Medication administration"), "surgical_safety": ("قائمة سلامة العملية", "Surgical safety checklist"),
    "nursing_observations": ("قياسات حيوية وتمريض", "Nursing observations and vital signs"),
    "consents": ("موافقة طبية", "Clinical consent"), "referrals": ("إحالة واستشارة", "Referral"), "care_tasks": ("مهمة متابعة", "Care task"), "prescriptions": ("وصفة طبية", "Prescription"),
    "problem_list": ("قائمة الأمراض والمشكلات", "Problem list"), "allergies": ("سجل الحساسية", "Allergy record"), "formulary": ("دليل الأدوية", "Medication formulary"),
    "drug_interactions": ("تداخلات الأدوية", "Drug interaction"), "blood_requests": ("طلب بنك الدم", "Blood request"), "insurance_claims": ("مطالبة تأمينية", "Insurance claim"), "quality_events": ("حدث جودة وسلامة", "Quality event"),
}


def print_document(kind: str, data: dict, settings: dict, record_code: str, language: str) -> str:
    arabic = language == "ar"
    esc = lambda value: html.escape(str(value), quote=True)
    title = PRINT_TITLES[kind][0 if arabic else 1]
    rows = []
    for key in PRINT_FIELDS[kind]:
        value = data.get(key)
        if value is None or value == "":
            continue
        if isinstance(value, (dict, list)):
            value = "، ".join(str(part) for part in value) if isinstance(value, list) else json.dumps(value, ensure_ascii=False)
        label = PRINT_LABELS.get(key, (key.replace("_", " ").title(), key.replace("_", " ").title()))[0 if arabic else 1]
        rows.append(f'<div class="field"><div class="label">{esc(label)}</div><div class="value">{esc(value)}</div></div>')
    direction = "rtl" if arabic else "ltr"
    hospital = esc(settings.get("hospital_name") or ("اسم المنشأة" if arabic else "Facility name"))
    department = esc(settings.get("department_name") or ("اسم القسم" if arabic else "Department name"))
    code_label = "رقم السجل" if arabic else "Record number"
    print_label = "طباعة" if arabic else "Print"
    generated_label = "تاريخ الطباعة" if arabic else "Printed at"
    try:
        print_timezone = ZoneInfo(str(settings.get("timezone") or "Africa/Cairo"))
    except (ZoneInfoNotFoundError, ValueError, TypeError):
        print_timezone = timezone.utc
    printed_at = esc(datetime.now(print_timezone).strftime("%Y-%m-%d %H:%M:%S"))
    empty = "لا توجد بيانات مسجلة" if arabic else "No recorded details"
    fields_markup = "".join(rows) or f'<div class="field">{esc(empty)}</div>'
    return f'''<!doctype html><html lang="{'ar' if arabic else 'en'}" dir="{direction}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{esc(title)} - {hospital}</title><style>
      *{{box-sizing:border-box}}body{{margin:0;background:#eef2f6;color:#17212b;font:15px/1.6 Arial,"Segoe UI",sans-serif}}main{{max-width:900px;margin:28px auto;background:#fff;padding:38px 44px;border:1px solid #dce3ea;border-radius:14px;box-shadow:0 12px 38px #17212b12}}.top{{display:flex;justify-content:space-between;align-items:flex-start;gap:20px;border-bottom:2px solid #0f766e;padding-bottom:20px;margin-bottom:20px}}h1{{font-size:25px;margin:0 0 5px;color:#123b45}}.muted,.meta{{color:#64748b}}.meta{{font-size:13px;margin-top:10px}}.fields{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}}.field{{border:1px solid #e5eaf0;border-radius:9px;padding:12px;min-height:70px;overflow-wrap:anywhere;white-space:pre-wrap}}.label{{font-size:12px;color:#64748b;margin-bottom:5px}}.value{{font-weight:600}}.actions{{display:flex;gap:8px}}button{{border:0;border-radius:8px;background:#0f766e;color:white;padding:10px 16px;font-weight:700;cursor:pointer}}footer{{border-top:1px solid #e5eaf0;margin-top:24px;padding-top:12px;font-size:12px;color:#64748b}}@media(max-width:650px){{main{{margin:0;padding:22px;border:0;border-radius:0}}.fields{{grid-template-columns:1fr}}.top{{flex-direction:column}}}}@media print{{@page{{margin:15mm}}body{{background:white}}main{{max-width:none;margin:0;padding:0;border:0;border-radius:0;box-shadow:none}}.actions{{display:none}}.field{{break-inside:avoid}}}}
      </style></head><body><main><header class="top"><div><div class="muted">{hospital} · {department}</div><h1>{esc(title)}</h1><div class="meta">{esc(code_label)}: {esc(record_code or "—")}</div></div><div class="actions"><button type="button" onclick="window.print()">⎙ {esc(print_label)}</button></div></header><section class="fields">{fields_markup}</section><footer>{esc(generated_label)}: {printed_at}</footer></main></body></html>'''


def parse_body(handler: BaseHTTPRequestHandler) -> tuple[dict, bytes]:
    length = int(handler.headers.get("Content-Length", "0"))
    if length < 0 or length > MAX_JSON_BYTES * 4:
        raise ValueError("حجم الطلب أكبر من الحد المسموح")
    raw = handler.rfile.read(length) if length else b""
    content_type = handler.headers.get("Content-Type", "")
    if "multipart/form-data" in content_type:
        return {}, raw
    if not raw:
        return {}, raw
    try:
        return json.loads(raw.decode("utf-8")), raw
    except json.JSONDecodeError as exc:
        raise ValueError("صيغة البيانات غير صحيحة") from exc


def storage_info() -> dict:
    ensure_dirs()
    disk = shutil.disk_usage(DATA_DIR)
    refresh_storage_alert(disk)
    def tree_size(path: Path) -> int:
        total = 0
        if path.exists():
            for item in path.rglob("*"):
                try:
                    if item.is_file(): total += item.stat().st_size
                except OSError:
                    continue
        return total
    db_size = DB_PATH.stat().st_size if DB_PATH.exists() else 0
    backup_size = tree_size(BACKUP_DIR)
    upload_size = tree_size(UPLOAD_DIR)
    snapshot_size = sum(tree_size(path) for path in DATA_DIR.parent.glob(f"{DATA_DIR.name}-preinstall-*"))
    failed_install_data_size = sum(tree_size(path) for path in DATA_DIR.parent.glob(f"{DATA_DIR.name}-data-failed-*"))
    used = disk.total - disk.free
    return {
        "total": disk.total, "used": used, "free": disk.free,
        "percent": round((used / disk.total) * 100, 1) if disk.total else 0,
        "database": db_size, "uploads": upload_size, "backups": backup_size,
        "install_snapshots": snapshot_size, "failed_install_data": failed_install_data_size,
        "data_dir": str(DATA_DIR), "backup_dir": str(BACKUP_DIR),
        "install_snapshot_dir": str(DATA_DIR.parent),
    }


def system_diagnostics() -> dict:
    checks = []
    owners = owner_count()
    checks.append({"code": "owner_accounts", "ok": owners == 2, "detail": f"عدد حسابات المالك: {owners} من 2"})
    checks.append({"code": "encryption", "ok": Fernet is not None, "detail": "وحدة التشفير متاحة" if Fernet is not None else "وحدة التشفير غير متاحة"})
    try:
        disk = shutil.disk_usage(DATA_DIR)
        free_percent = (disk.free / disk.total * 100) if disk.total else 0
        with connection() as db:
            active_sessions = db.execute(
                "SELECT COUNT(*) FROM sessions WHERE expires_at > ?", (now_utc(),)
            ).fetchone()[0]
        resource_ok = free_percent > 10
        resource_detail = f"مساحة حرة {free_percent:.1f}%؛ جلسات نشطة {int(active_sessions)}"
        if not resource_ok:
            resource_detail += "؛ يلزم تفريغ مساحة قبل استمرار التشغيل"
        checks.append({"code": "resource_pressure", "ok": resource_ok, "detail": resource_detail})
    except (OSError, sqlite3.Error, TypeError, ValueError) as exc:
        checks.append({"code": "resource_pressure", "ok": False, "detail": f"تعذر قياس ضغط الموارد: {str(exc)[:120]}"})
    try:
        with connection() as db:
            integrity = db.execute("PRAGMA integrity_check").fetchone()[0]
        checks.append({"code": "database", "ok": integrity == "ok", "detail": "قاعدة البيانات سليمة" if integrity == "ok" else str(integrity)})
    except Exception as exc:
        checks.append({"code": "database", "ok": False, "detail": f"تعذر فحص قاعدة البيانات: {str(exc)[:120]}"})
    key_ok = KEY_PATH.is_file() and KEY_PATH.stat().st_size == 44
    checks.append({"code": "backup_key", "ok": key_ok, "detail": "مفتاح النسخ موجود" if key_ok else "مفتاح النسخ مفقود أو غير صالح"})
    checks.append({"code": "data_path", "ok": DATA_DIR.is_dir() and DB_PATH.is_file(), "detail": str(DATA_DIR)})
    checks.append({"code": "uploads_path", "ok": UPLOAD_DIR.is_dir(), "detail": str(UPLOAD_DIR)})
    cert_path = DATA_DIR / "tls" / "server.crt"
    cert_ok, cert_detail = False, "شهادة HTTPS غير موجودة"
    if cert_path.is_file() and x509 is not None:
        try:
            cert = x509.load_pem_x509_certificate(cert_path.read_bytes())
            expires = getattr(cert, "not_valid_after_utc", cert.not_valid_after.replace(tzinfo=timezone.utc))
            cert_ok = expires > datetime.now(timezone.utc)
            cert_detail = f"صالحة حتى {expires.isoformat(timespec='seconds')}"
        except Exception:
            cert_detail = "شهادة HTTPS غير قابلة للقراءة"
    checks.append({"code": "https", "ok": cert_ok, "detail": cert_detail})
    backups = [item for item in BACKUP_DIR.glob("*.zip") if item.is_file()] + [item for item in BACKUP_DIR.glob("*.ucb") if item.is_file()]
    latest = max(backups, key=lambda item: item.stat().st_mtime, default=None)
    checks.append({"code": "backup_recent", "ok": latest is not None, "detail": latest.name if latest else "لم توجد نسخة احتياطية بعد"})
    if latest is not None:
        try:
            verify_backup_file(latest)
            checks.append({"code": "backup_integrity", "ok": True, "detail": f"آخر نسخة سليمة: {latest.name}"})
        except Exception as exc:
            checks.append({"code": "backup_integrity", "ok": False, "detail": f"آخر نسخة غير قابلة للتحقق: {str(exc)[:120]}"})
    else:
        checks.append({"code": "backup_integrity", "ok": False, "detail": "لا توجد نسخة لفحص سلامتها"})
    return {"ok": all(item["ok"] for item in checks), "checks": checks, "checked_at": now_utc()}


def revoke_other_sessions(user_id: str, current_token_hash: str) -> int:
    with connection() as db:
        result = db.execute("DELETE FROM sessions WHERE user_id=? AND token_hash<>?", (user_id, current_token_hash))
        return result.rowcount


def parse_multipart(raw: bytes, content_type: str) -> tuple[str, bytes, dict[str, str]]:
    message = BytesParser(policy=policy.default).parsebytes(
        b"Content-Type: " + content_type.encode("ascii", "ignore") + b"\r\nMIME-Version: 1.0\r\n\r\n" + raw
    )
    if not message.is_multipart():
        raise ValueError("ملف الاستعادة غير صالح")
    upload_name, upload_data, backup_key, fields = "", b"", "", {}
    for part in message.iter_parts():
        name = part.get_param("name", header="content-disposition")
        payload = part.get_payload(decode=True) or b""
        if name == "file":
            upload_name = Path(part.get_filename() or "backup.zip").name
            upload_data = payload
        elif name == "backup_key":
            backup_key = payload.decode("utf-8", "ignore").strip()
        elif name:
            fields[name] = payload.decode("utf-8", "ignore").strip()
    if not upload_data:
        raise ValueError("اختر ملف نسخة احتياطية أولًا")
    return backup_key, upload_data, fields


def parse_attachment_multipart(raw: bytes, content_type: str) -> tuple[dict[str, str], str, bytes, str]:
    message = BytesParser(policy=policy.default).parsebytes(
        b"Content-Type: " + content_type.encode("ascii", "ignore") + b"\r\nMIME-Version: 1.0\r\n\r\n" + raw
    )
    if not message.is_multipart(): raise ValueError("بيانات الملف غير صالحة")
    fields, filename, payload, media_type = {}, "", b"", "application/octet-stream"
    for part in message.iter_parts():
        name = part.get_param("name", header="content-disposition")
        data = part.get_payload(decode=True) or b""
        if name == "file":
            filename = Path((part.get_filename() or "").replace("\\", "/")).name
            payload = data
            media_type = part.get_content_type()
        elif name:
            fields[name] = data.decode("utf-8", "replace").strip()
    if not filename or not payload: raise ValueError("اختر ملفًا غير فارغ")
    if len(payload) > 32 * 1024 * 1024: raise ValueError("الحد الأقصى لحجم المرفق 32 ميجابايت")
    extension = Path(filename).suffix.lower()
    if extension not in {".pdf", ".png", ".jpg", ".jpeg", ".doc", ".docx", ".xls", ".xlsx", ".txt", ".rtf", ".dcm"}:
        raise ValueError("امتداد الملف غير مسموح به")
    return fields, filename[:180], payload, media_type[:100]


def parse_xlsx_rows(payload: bytes) -> list[dict[str, str]]:
    """Read the first worksheet with the standard library; no internet or add-on is required."""
    if len(payload) > 32 * 1024 * 1024:
        raise ValueError("الحد الأقصى لملف Excel هو 32 ميجابايت")
    try:
        archive = zipfile.ZipFile(io.BytesIO(payload))
        names = set(archive.namelist())
        if "xl/worksheets/sheet1.xml" not in names:
            raise ValueError("ملف Excel لا يحتوي ورقة العمل الأولى")
        strings = []
        if "xl/sharedStrings.xml" in names:
            root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
            ns = {"x": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
            for item in root.findall("x:si", ns):
                strings.append("".join(node.text or "" for node in item.iter() if node.tag.endswith("}t") or node.tag == "t"))
        root = ET.fromstring(archive.read("xl/worksheets/sheet1.xml"))
        ns = {"x": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}
        grid = []
        for row in root.findall(".//x:sheetData/x:row", ns):
            values = {}
            for cell in row.findall("x:c", ns):
                letters = "".join(ch for ch in cell.attrib.get("r", "A1") if ch.isalpha())
                col = 0
                for ch in letters.upper(): col = col * 26 + ord(ch) - 64
                value = cell.find("x:v", ns)
                text = value.text if value is not None and value.text is not None else ""
                if cell.attrib.get("t") == "s" and text.isdigit() and int(text) < len(strings): text = strings[int(text)]
                inline = cell.find("x:is/x:t", ns)
                if inline is not None: text = inline.text or ""
                values[col] = text
            grid.append([values.get(i, "") for i in range(1, max(values, default=0) + 1)])
        if not grid: raise ValueError("ملف Excel فارغ")
        headers = [str(value).strip() for value in grid[0]]
        return [dict(zip(headers, row + [""] * max(0, len(headers) - len(row)))) for row in grid[1:]]
    except (KeyError, zipfile.BadZipFile, ET.ParseError) as exc:
        raise ValueError("ملف Excel غير صالح أو تالف") from exc


def _preparation_template() -> list[str]:
    raw = get_settings().get("procedure_preparation_checklist", "")
    try:
        items = json.loads(raw)
        if isinstance(items, list) and items:
            return [str(item).strip() for item in items if str(item).strip()][:30]
    except (json.JSONDecodeError, TypeError):
        pass
    return PREPARATION_CHECKLIST_DEFAULTS.copy()


def normalize_procedure_checklist(data: dict, user: dict, previous: dict | None = None) -> None:
    """Validate checklist edits and stamp completion metadata on the server."""
    previous = previous or {}
    template = _preparation_template()
    old_items = previous.get("preparation_checklist", [])
    if not isinstance(old_items, list):
        old_items = []
    old_by_name = {
        str(entry.get("item", "")).strip(): entry
        for entry in old_items if isinstance(entry, dict) and str(entry.get("item", "")).strip()
    }
    submitted = data.get("preparation_checklist")
    if not isinstance(submitted, list):
        submitted = old_items or [{"item": item, "completed": False} for item in template]
    allowed = set(template) | set(old_by_name)
    normalized, seen = [], set()
    for entry in submitted[:30]:
        if isinstance(entry, str):
            item, completed = entry.strip(), False
        elif isinstance(entry, dict):
            item = str(entry.get("item", "")).strip()
            completed = entry.get("completed") is True
        else:
            raise ValueError("صيغة أحد عناصر قائمة التحضير غير صالحة")
        if not item or len(item) > 160 or item not in allowed:
            raise ValueError("قائمة التحضير تحتوي عنصرًا غير معتمد؛ حدّث الصفحة وحاول مجددًا")
        if item in seen:
            raise ValueError("لا يمكن تكرار عنصر داخل قائمة التحضير")
        seen.add(item)
        old = old_by_name.get(item, {})
        was_completed = old.get("completed") is True
        if completed:
            completed_by = old.get("completed_by") if was_completed else str(user.get("username", ""))[:80]
            completed_at = old.get("completed_at") if was_completed else now_utc()
        else:
            completed_by, completed_at = "", ""
        normalized.append({
            "item": item, "completed": completed,
            "completed_by": completed_by, "completed_at": completed_at,
        })
    for item in template:
        if item not in seen:
            normalized.append({"item": item, "completed": False, "completed_by": "", "completed_at": ""})
    data["preparation_checklist"] = normalized


def validate_procedure_encounter_link(data: dict) -> None:
    """Ensure an optional procedure visit link points to the same patient."""
    encounter_id = str(data.get("encounter_id", "")).strip()
    if not encounter_id:
        data.pop("encounter_id", None)
        return
    patient_id = str(data.get("patient_id", "")).strip()
    if not patient_id:
        raise ValueError("اختر المريض قبل ربط الإجراء بزيارة")
    with connection() as db:
        row = db.execute("SELECT payload_json FROM records WHERE id=? AND kind='encounters'", (encounter_id,)).fetchone()
    if not row:
        raise ValueError("الزيارة المرتبطة بالإجراء غير موجودة")
    encounter = json.loads(row["payload_json"])
    if str(encounter.get("patient_id", "")).strip() != patient_id:
        raise ValueError("لا يمكن ربط الإجراء بزيارة تخص مريضًا آخر")
    data["encounter_id"] = encounter_id


def validate_patient_contact_preferences(data: dict) -> None:
    """Validate the local communication-preference record without sending messages."""
    consent = str(data.get("communication_consent", "غير محدد")).strip() or "غير محدد"
    preference = str(data.get("contact_preference", "")).strip()
    allowed_consent = {"موافق", "غير موافق", "غير محدد", "yes", "no", "unknown"}
    allowed_preferences = {"هاتف", "رسالة نصية", "واتساب", "لا تواصل", "phone", "sms", "whatsapp", "none", ""}
    if consent not in allowed_consent:
        raise ValueError("قيمة الموافقة على الرسائل غير صالحة")
    if preference not in allowed_preferences:
        raise ValueError("طريقة التواصل المحددة غير صالحة")
    if consent in {"موافق", "yes"} and (not preference or preference in {"لا تواصل", "none"} or not str(data.get("consent_at", "")).strip()):
        raise ValueError("عند الموافقة على الرسائل حدد طريقة التواصل وتاريخ الموافقة")


def _normalize_digits(value: object) -> str:
    """Convert Arabic-Indic and Persian digits to ASCII without changing other text."""
    source = "٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹"
    target = "01234567890123456789"
    return str(value or "").translate(str.maketrans(source, target))


def validate_patient_identity(data: dict, *, require_nationality: bool = True) -> None:
    """Validate Egyptian identity structure or a foreign identity document.

    This is an offline consistency check for the number's public structure. It
    cannot prove that a card was issued by the Egyptian Civil Status
    Organization or that the person presenting it is its owner.
    """
    raw_nationality = str(data.get("nationality", "")).strip()
    aliases = {"مصرى": "مصري", "egyptian": "مصري", "egypt": "مصري", "مصري": "مصري",
               "اجنبي": "أجنبي", "أجنبي": "أجنبي", "foreign": "أجنبي"}
    nationality = aliases.get(raw_nationality.casefold(), raw_nationality)
    national_id = _normalize_digits(data.get("national_id", "")).replace(" ", "").replace("-", "")
    document_type = str(data.get("identity_document_type", "")).strip()
    document_no = str(data.get("identity_document_no", "")).strip()

    if not nationality:
        if require_nationality:
            raise ValueError("اختر جنسية المريض: مصري أو أجنبي")
        if not any((national_id, document_type, document_no)):
            return
        raise ValueError("حدد جنسية المريض قبل حفظ بيانات الهوية")
    if nationality not in PATIENT_NATIONALITIES:
        raise ValueError("الجنسية يجب أن تكون مصري أو أجنبي")
    data["nationality"] = nationality

    if nationality == "مصري":
        if not national_id or len(national_id) != 14 or not national_id.isdigit():
            raise ValueError("الرقم القومي المصري يجب أن يكون 14 رقمًا كاملًا")
        if national_id[0] not in {"2", "3"}:
            raise ValueError("الرقم القومي غير صالح: خانة القرن يجب أن تكون 2 أو 3")
        try:
            birth_year = (1900 if national_id[0] == "2" else 2000) + int(national_id[1:3])
            birth_date = date(birth_year, int(national_id[3:5]), int(national_id[5:7]))
        except ValueError:
            raise ValueError("الرقم القومي غير صالح: تاريخ الميلاد المضمن غير صحيح")
        if birth_date > date.today():
            raise ValueError("الرقم القومي غير صالح: تاريخ الميلاد لا يمكن أن يكون في المستقبل")
        governorate_code = national_id[7:9]
        if governorate_code not in EGYPTIAN_GOVERNORATE_CODES:
            raise ValueError("الرقم القومي غير صالح: كود جهة الميلاد غير معروف")
        if national_id[9:13] == "0000":
            raise ValueError("الرقم القومي غير صالح: الرقم التسلسلي غير صحيح")
        gender = str(data.get("gender", "")).strip().casefold()
        if gender in {"ذكر", "male", "m"} and int(national_id[12]) % 2 != 1:
            raise ValueError("الرقم القومي لا يتوافق مع النوع المحدد: الرقم الثالث عشر يدل على أنثى")
        if gender in {"أنثى", "انثى", "female", "f"} and int(national_id[12]) % 2 != 0:
            raise ValueError("الرقم القومي لا يتوافق مع النوع المحدد: الرقم الثالث عشر يدل على ذكر")
        supplied_dob = str(data.get("dob", "")).strip()
        if supplied_dob:
            try:
                entered_date = date.fromisoformat(supplied_dob[:10])
            except ValueError:
                raise ValueError("تاريخ ميلاد المريض غير صحيح")
            if entered_date != birth_date:
                raise ValueError("تاريخ الميلاد لا يطابق التاريخ المضمن في الرقم القومي")
        else:
            data["dob"] = birth_date.isoformat()
        data["national_id"] = national_id
        data["nationality_country"] = str(data.get("nationality_country", "")).strip() or "مصر"
        if document_type or document_no:
            raise ValueError("المصري يستخدم الرقم القومي؛ لا تدخل وثيقة أجنبية في نفس الملف")
        data.pop("identity_document_type", None)
        data.pop("identity_document_no", None)
        return

    if national_id:
        raise ValueError("المريض الأجنبي لا يستخدم خانة الرقم القومي المصري؛ أدخل وثيقة الهوية الأجنبية")
    if document_type not in FOREIGN_DOCUMENT_TYPES:
        raise ValueError("اختر نوع وثيقة هوية صحيحة للمريض الأجنبي")
    if not 3 <= len(document_no) <= 40 or any(ch in "\r\n\t" for ch in document_no) or any(not (ch.isalnum() or ch in "-_/ .") for ch in document_no):
        raise ValueError("رقم وثيقة هوية الأجنبي يجب أن يكون من 3 إلى 40 حرفًا أو رقمًا")
    if not str(data.get("nationality_country", "")).strip():
        raise ValueError("اكتب دولة أو جنسية المريض الأجنبي")
    data["national_id"] = ""
    data["identity_document_type"] = document_type
    data["identity_document_no"] = document_no


def _match_value(value: object) -> str:
    return "".join(ch for ch in str(value or "").casefold() if ch.isalnum() or "\u0600" <= ch <= "\u06ff")


def patient_duplicate_candidates(data: dict, exclude_id: str | None = None) -> list[dict]:
    """Find likely duplicate patients using non-clinical identity fields only."""
    name = _match_value(data.get("name_ar") or data.get("name_en"))
    national_id = _match_value(data.get("national_id"))
    phone = _match_value(data.get("phone"))
    dob = str(data.get("dob", "")).strip()
    if not any((name, national_id, phone)):
        return []
    candidates = []
    with connection() as db:
        rows = db.execute("SELECT * FROM records WHERE kind='patients' AND status<>'archived'").fetchall()
    for row in rows:
        if exclude_id and row["id"] == exclude_id:
            continue
        saved = json.loads(row["payload_json"])
        reasons, score = [], 0
        if national_id and national_id == _match_value(saved.get("national_id")):
            reasons.append("الرقم القومي متطابق"); score = max(score, 100)
        if phone and phone == _match_value(saved.get("phone")):
            reasons.append("الهاتف متطابق"); score = max(score, 70)
        saved_name = _match_value(saved.get("name_ar") or saved.get("name_en"))
        if name and name == saved_name:
            if dob and dob == str(saved.get("dob", "")).strip():
                reasons.append("الاسم وتاريخ الميلاد متطابقان"); score = max(score, 85)
            else:
                reasons.append("الاسم متطابق"); score = max(score, 45)
        if score:
            candidates.append({"row": row, "score": score, "reason": "، ".join(reasons)})
    return sorted(candidates, key=lambda item: (-item["score"], item["row"]["created_at"]))[:20]


def merge_patient_records(source_id: str, target_id: str, user: dict) -> tuple[int, str]:
    """Move all records linked by patient_id and archive the source patient."""
    if not source_id or not target_id or source_id == target_id:
        raise ValueError("اختر ملفين مختلفين للدمج")
    stamp = now_utc()
    moved = 0
    with connection() as db:
        source = db.execute("SELECT * FROM records WHERE id=? AND kind='patients'", (source_id,)).fetchone()
        target = db.execute("SELECT * FROM records WHERE id=? AND kind='patients'", (target_id,)).fetchone()
        if not source or not target:
            raise ValueError("ملف المريض المصدر أو الهدف غير موجود")
        source_data = json.loads(source["payload_json"])
        target_data = json.loads(target["payload_json"])
        if source_data.get("merged_into"):
            raise ValueError("ملف المريض المصدر مدموج بالفعل في ملف آخر")
        if target_data.get("merged_into"):
            raise ValueError("لا يمكن الدمج داخل ملف مدموج؛ اختر ملفًا نشطًا")
        target_name = target_data.get("name_ar") or target_data.get("name_en") or ""
        for row in db.execute("SELECT id,payload_json FROM records WHERE kind<>'patients'").fetchall():
            data = json.loads(row["payload_json"])
            if str(data.get("patient_id", "")) != source_id:
                continue
            data["patient_id"] = target_id
            if "patient_name" in data:
                data["patient_name"] = target_name
            db.execute("UPDATE records SET payload_json=?,updated_at=?,revision=revision+1 WHERE id=?",
                       (json.dumps(data, ensure_ascii=False), stamp, row["id"]))
            moved += 1
        source_data.update({"status": "archived", "merged_into": target_id, "merged_at": stamp,
                            "merged_by": str(user.get("id", ""))})
        db.execute("UPDATE records SET status='archived',payload_json=?,updated_at=?,revision=revision+1 WHERE id=?",
                   (json.dumps(source_data, ensure_ascii=False), stamp, source_id))
    return moved, stamp


def validate_signed_record_update(kind: str, old_data: dict, new_data: dict) -> None:
    """Keep signed clinical content immutable; corrections use the addendum endpoint."""
    if kind not in SIGNABLE_KINDS:
        return
    signature_keys = {"signed_at", "signed_by", "signed_by_id"}
    if not old_data.get("signed_at"):
        if any(new_data.get(key) for key in signature_keys) or new_data.get("addenda"):
            raise ValueError("اعتماد السجل يتم من زر التوقيع فقط")
        return
    if any(new_data.get(key) != old_data.get(key) for key in signature_keys):
        raise ValueError("لا يمكن تغيير بيانات اعتماد السجل")
    if new_data.get("addenda", []) != old_data.get("addenda", []):
        raise ValueError("الملحقات لا تُعدّل؛ أضف ملحقًا جديدًا")
    changed_clinical = {
        key for key in set(old_data) | set(new_data)
        if key in CLINICAL_FIELDS and old_data.get(key) != new_data.get(key)
    }
    if changed_clinical:
        raise ValueError("السجل معتمد؛ أضف ملحقًا بدل تعديل المحتوى السريري")


def make_record_addendum(data: dict, user: dict, text: str, reason: str) -> dict:
    if not data.get("signed_at"):
        raise ValueError("اعتمد السجل أولًا قبل إضافة ملحق")
    text, reason = str(text).strip(), str(reason).strip()
    if not text or len(text) > 5000 or not reason or len(reason) > 500:
        raise ValueError("أدخل نص الملحق وسبب التعديل ضمن الحدود المسموحة")
    current = data.get("addenda", [])
    if not isinstance(current, list) or len(current) >= 100:
        raise ValueError("لا يمكن إضافة ملحقات أخرى لهذا السجل")
    return {
        "id": str(uuid.uuid4()), "text": text, "reason": reason,
        "created_at": now_utc(), "created_by": str(user.get("id", "")),
        "created_by_name": str(user.get("display_name") or user.get("username") or "")[:160],
    }


class RecordConflictError(Exception):
    pass


class Handler(BaseHTTPRequestHandler):
    server_version = "UroCare/1.0"
    sys_version = ""

    def log_message(self, fmt, *args):
        # Keep HTTP logs free of query strings and patient information.
        print(f"[{self.log_date_time_string()}] {self.address_string()} {args[0] if args else ''}")

    def _send(self, status: int, payload, content_type="application/json; charset=utf-8", headers=None):
        if isinstance(payload, (dict, list)):
            data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        elif isinstance(payload, str):
            data = payload.encode("utf-8")
        else:
            data = payload
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "same-origin")
        self.send_header("Cache-Control", "no-store" if self.path.startswith("/api/") else "no-cache")
        security_headers = {
            "Strict-Transport-Security": "max-age=31536000",
            "Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'",
        }
        if headers:
            security_headers.update(headers)
        for key, value in security_headers.items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(data)

    def _error(self, status: int, message: str):
        self._send(status, {"error": message})

    def _cookies(self) -> SimpleCookie:
        cookie = SimpleCookie()
        cookie.load(self.headers.get("Cookie", ""))
        return cookie

    def _session(self):
        cookie = self._cookies()
        token = cookie.get("urocare_session")
        return get_user_for_token(token.value if token else None)

    def _require(self, kind: str | None = None, action: str | None = None, csrf=True):
        user, csrf_token = self._session()
        if not user:
            raise PermissionError("سجّل الدخول أولًا")
        if csrf and self.command in ("POST", "PATCH", "PUT", "DELETE"):
            supplied = self.headers.get("X-CSRF-Token", "")
            if not supplied or not hmac.compare_digest(supplied, csrf_token or ""):
                raise PermissionError("انتهت صلاحية الجلسة؛ حدّث الصفحة وسجّل الدخول مجددًا")
        if kind and action and not allowed(user, kind, action):
            raise PermissionError("ليست لديك صلاحية لتنفيذ هذا الإجراء")
        return user, csrf_token

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        if path == "/" or path == "/index.html":
            try:
                data = (APP_DIR / "static" / "index.html").read_bytes()
                self._send(200, data, "text/html; charset=utf-8")
            except OSError:
                self._error(500, "واجهة البرنامج غير موجودة")
            return
        if path.startswith("/static/"):
            candidate = (APP_DIR / path.lstrip("/")).resolve()
            static_root = (APP_DIR / "static").resolve()
            if static_root not in candidate.parents or not candidate.is_file():
                self._error(404, "الملف غير موجود")
                return
            self._send(200, candidate.read_bytes(), mimetypes.guess_type(candidate.name)[0] or "application/octet-stream")
            return
        if not path.startswith("/api/"):
            self._error(404, "المسار غير موجود")
            return
        try:
            self._get_api(path, urllib.parse.parse_qs(parsed.query))
        except PermissionError as exc:
            self._error(401 if "سجّل الدخول" in str(exc) or "انتهت صلاحية" in str(exc) else 403, str(exc))
        except Exception as exc:
            self._error(500, str(exc) if os.environ.get("UROCARE_DEBUG") else "حدث خطأ داخلي")

    def do_POST(self): self._handle_mutation("POST")
    def do_PATCH(self): self._handle_mutation("PATCH")
    def do_PUT(self): self._handle_mutation("PUT")

    def do_DELETE(self):
        self._error(405, "الحذف النهائي غير متاح؛ استخدم الأرشفة لحفظ سجل التغييرات")

    def _handle_mutation(self, method: str):
        path = urllib.parse.urlparse(self.path).path
        try:
            body, raw = parse_body(self)
            self._mutate_api(method, path, body, raw)
        except PermissionError as exc:
            self._error(401 if "سجّل الدخول" in str(exc) or "انتهت صلاحية" in str(exc) else 403, str(exc))
        except ValueError as exc:
            self._error(400, str(exc))
        except RecordConflictError as exc:
            self._error(409, str(exc))
        except Exception as exc:
            self._error(500, str(exc) if os.environ.get("UROCARE_DEBUG") else "حدث خطأ داخلي")

    def _get_api(self, path: str, query: dict):
        if path == "/api/setup/status":
            settings = get_settings()
            self._send(200, {
                "required": owner_count() != 2,
                "branding": {key: settings.get(key, "") for key in ("system_name", "hospital_name", "department_name", "facility_type", "brand_banner_mime", "brand_logo_mime")},
            })
            return
        if path in ("/api/branding/banner", "/api/branding/logo"):
            asset = path.rsplit("/", 1)[-1]
            settings = get_settings()
            data = settings.get(f"brand_{asset}_data", "")
            mime = settings.get(f"brand_{asset}_mime", "")
            if not data or not mime:
                self._error(404, "لا توجد صورة هوية")
                return
            image_data = decode_brand_banner(data, mime)
            self._send(200, image_data, mime, {"Content-Disposition": f"inline; filename=facility-{asset}"})
            return
        if path == "/api/health":
            settings = get_settings()
            self._send(200, {"ok": True, "setup": owner_count() == 2,
                             "server_time": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
                             "timezone": settings.get("timezone", "Africa/Cairo"), "version": "1.0.0"})
            return
        user, csrf = self._require(csrf=False)
        if path == "/api/me":
            self._send(200, self._public_user(user, csrf))
        elif path == "/api/dashboard":
            self._send(200, self._dashboard(user))
        elif path == "/api/operating-board":
            self._require("procedures", "view")
            self._send(200, self._operating_board(user, query))
        elif path.startswith("/api/patients/") and path.endswith("/journey"):
            patient_id = urllib.parse.unquote(path[len("/api/patients/"):-len("/journey")].strip("/"))
            result = patient_journey(patient_id, user)
            if result is None:
                self._error(404, "ملف المريض غير موجود")
            else:
                self._send(200, result)
        elif path == "/api/fhir/export":
            patient_id = str(query.get("patient_id", [""])[0]).strip()
            if not patient_id:
                raise ValueError("يجب تحديد ملف المريض للتصدير")
            bundle = fhir_patient_bundle(patient_id, user)
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            self._send(200, json.dumps(bundle, ensure_ascii=False, indent=2).encode("utf-8"), "application/fhir+json; charset=utf-8",
                       {"Content-Disposition": f'attachment; filename="UroCare_FHIR_{_fhir_id(patient_id)}_{stamp}.json"'})
        elif path == "/api/alerts":
            if user["role"] not in (OWNER, "ADMIN"):
                raise PermissionError("تنبيهات النظام متاحة للمالك والمدير فقط")
            refresh_storage_alert()
            refresh_clinical_followup_alerts()
            self._send(200, {"alerts": list_system_alerts()})
        elif path == "/api/patient-duplicates":
            if not allowed(user, "patients", "view"):
                raise PermissionError("ليست لديك صلاحية فحص ملفات المرضى")
            data = {key: values[0] for key, values in query.items() if values}
            candidates = []
            for item in patient_duplicate_candidates(data, data.get("exclude_id")):
                record = safe_record(item["row"], user)
                if record:
                    candidates.append({"record": record, "score": item["score"], "reason": item["reason"]})
            self._send(200, {"items": candidates})
        elif path == "/api/records":
            kind = query.get("kind", [""])[0]
            if kind == "clinical_templates": self._require_owner(user)
            if kind not in ALL_KINDS or not allowed(user, kind, "view"):
                raise PermissionError("ليست لديك صلاحية عرض هذه البيانات")
            if kind == "attachments" and not allowed(user, "patients", "view"):
                raise PermissionError("يلزم توفر صلاحية عرض ملفات المرضى")
            result = self._records(kind, query, user)
            audit_sensitive_read(user, kind, count=result["total"])
            self._send(200, result)
        elif path.startswith("/api/records/") and path.endswith("/print") and path.count("/") == 4:
            parts = path.split("/")
            record_id = parts[3]
            with connection() as db:
                row = db.execute("SELECT * FROM records WHERE id=?", (record_id,)).fetchone()
            if not row or row["kind"] not in PRINTABLE_KINDS:
                self._error(404, "السجل غير موجود أو لا يدعم الطباعة"); return
            kind = row["kind"]
            if not allowed(user, kind, "view") or not allowed(user, kind, "print"):
                raise PermissionError("يلزم توفر صلاحية العرض والطباعة لهذه الوحدة")
            item = safe_record(row, user)
            if not item:
                self._error(404, "السجل غير موجود"); return
            data = item["data"]
            if kind == "waiting":
                try:
                    requested = str(data.get("requested_at", ""))[:10]
                    data["actual_days"] = max(0, (datetime.now().date() - datetime.fromisoformat(requested).date()).days)
                except (TypeError, ValueError):
                    data["actual_days"] = 0
            language = query.get("lang", ["ar"])[0]
            if language not in {"ar", "en"}: language = "ar"
            document = print_document(kind, data, get_settings(), row["code"], language)
            audit(user, "record_print", kind, record_id, "فتح صفحة طباعة ملخص السجل")
            self._send(200, document, "text/html; charset=utf-8", {
                "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
                "Referrer-Policy": "no-referrer",
                "Content-Disposition": "inline",
            })
        elif path.startswith("/api/records/") and path.count("/") == 3:
            record_id = path.rsplit("/", 1)[-1]
            with connection() as db:
                row = db.execute("SELECT * FROM records WHERE id=?", (record_id,)).fetchone()
            if not row: self._error(404, "السجل غير موجود"); return
            emergency = not allowed(user, row["kind"], "view") and has_emergency_access(user, row["kind"], record_id)
            if not allowed(user, row["kind"], "view") and not emergency:
                raise PermissionError("ليست لديك صلاحية عرض هذا السجل")
            if row["kind"] == "attachments" and not allowed(user, "patients", "view"):
                raise PermissionError("يلزم توفر صلاحية عرض ملفات المرضى")
            item = safe_record(row, user, emergency=emergency)
            if not item: self._error(404, "السجل غير موجود"); return
            audit_sensitive_read(user, row["kind"], record_id)
            if emergency:
                audit(user, "emergency_access_use", row["kind"], record_id, "استخدام وصول طوارئ مؤقت")
            self._send(200, item)
        elif path.startswith("/api/attachments/download/"):
            if not allowed(user, "attachments", "view") or not allowed(user, "patients", "view") or not (allowed(user, "attachments", "download") or user["role"] in {OWNER, "ADMIN"}):
                raise PermissionError("ليست لديك صلاحية تنزيل المرفقات")
            attachment_id = path.rsplit("/", 1)[-1]
            with connection() as db:
                row = db.execute("SELECT * FROM records WHERE id=? AND kind='attachments'", (attachment_id,)).fetchone()
            if not row: self._error(404, "المرفق غير موجود"); return
            data = json.loads(row["payload_json"])
            target = (UPLOAD_DIR / str(data.get("stored_name", ""))).resolve()
            if UPLOAD_DIR.resolve() not in target.parents or not target.is_file():
                self._error(404, "ملف المرفق غير موجود"); return
            filename = urllib.parse.quote(str(data.get("file_name", "attachment")), safe="")
            audit(user, "attachment_download", "attachments", attachment_id, "تنزيل مرفق طبي")
            self._send(200, target.read_bytes(), "application/octet-stream", {"Content-Disposition": f"attachment; filename=attachment; filename*=UTF-8''{filename}"})
        elif path == "/api/users":
            if not allowed(user, "users", "view") and not allowed(user, "users", "manage"):
                raise PermissionError("إدارة المستخدمين متاحة للمالك والمدير فقط")
            with connection() as db:
                if user["role"] == OWNER:
                    rows = db.execute("SELECT id,username,display_name,role,department,active,created_at,last_login_at,totp_secret FROM users ORDER BY role,display_name").fetchall()
                else:
                    rows = db.execute("SELECT id,username,display_name,role,department,active,created_at,last_login_at,totp_secret FROM users WHERE role<>? ORDER BY role,display_name", (OWNER,)).fetchall()
            labels = role_labels()
            users = [dict(row) | {"role_label": labels.get(row["role"], ROLE_LABELS.get(row["role"], row["role"])), "mfa_enabled": bool(row["totp_secret"])} for row in rows]
            roles = [{"code": key, "name": value} for key, value in ROLE_LABELS.items() if key != OWNER]
            with connection() as db:
                roles.extend({"code": row["code"], "name": row["name_ar"]} for row in db.execute("SELECT code,name_ar FROM custom_roles WHERE active=1 ORDER BY name_ar"))
            self._send(200, {"users": users, "roles": roles})
        elif path == "/api/message-recipients":
            with connection() as db:
                rows = db.execute("SELECT id,username,display_name,role,department FROM users WHERE active=1 AND id<>? ORDER BY display_name", (user["id"],)).fetchall()
            self._send(200, {"users": [dict(row) for row in rows]})
        elif path == "/api/announcements":
            upcoming_only = query.get("upcoming", [""])[0] == "1"
            self._send(200, visible_announcements(user, upcoming_only))
        elif path == "/api/messages":
            with connection() as db:
                rows = db.execute("""
                    SELECT m.*, s.username sender_username, s.display_name sender_name,
                           r.username receiver_username, r.display_name receiver_name
                    FROM messages m JOIN users s ON s.id=m.sender_id JOIN users r ON r.id=m.receiver_id
                    WHERE m.sender_id=? OR m.receiver_id=? ORDER BY m.created_at DESC LIMIT 200
                """, (user["id"], user["id"])).fetchall()
                unread = db.execute("SELECT COUNT(*) FROM messages WHERE receiver_id=? AND read_at IS NULL", (user["id"],)).fetchone()[0]
            items = []
            for row in rows:
                item = dict(row)
                item["mine"] = item["sender_id"] == user["id"]
                items.append(item)
            self._send(200, {"messages": items, "unread": unread})
        elif path == "/api/roles":
            if not allowed(user, "roles", "view") and not allowed(user, "roles", "manage"):
                raise PermissionError("إدارة الأدوار متاحة للمالك والمدير فقط")
            with connection() as db:
                rows = db.execute("SELECT code,name_ar,name_en,permissions_json,active,created_at FROM custom_roles ORDER BY created_at").fetchall()
            self._send(200, {"roles": [{"code": r["code"], "name_ar": r["name_ar"], "name_en": r["name_en"],
                                          "permissions": json.loads(r["permissions_json"]), "active": bool(r["active"]),
                                          "created_at": r["created_at"]} for r in rows]})
        elif path == "/api/settings":
            settings = get_settings()
            settings.pop("license_secret", None)
            settings.pop("brand_banner_data", None)
            settings.pop("brand_logo_data", None)
            if user["role"] != OWNER:
                settings.pop("publisher_phone", None)
            self._send(200, settings)
        elif path == "/api/customization":
            self._require_owner(user)
            self._send(200, customization_payload())
        elif path == "/api/customization/bundled":
            self._require_owner(user)
            bundled_path = APP_DIR / "urocare-customization.json"
            if not bundled_path.is_file():
                self._send(200, {"available": False})
                return
            if bundled_path.stat().st_size > 4 * 1024 * 1024:
                raise ValueError("ملف التخصيص المضمّن أكبر من الحد المسموح")
            try:
                bundled = json.loads(bundled_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                raise ValueError("تعذرت قراءة ملف التخصيص المضمّن")
            if not isinstance(bundled, dict) or bundled.get("format") != "urocare-customization":
                raise ValueError("ملف التخصيص المضمّن غير صالح")
            self._send(200, {"available": True, "payload": bundled})
        elif path == "/api/customization/export":
            self._require_owner(user)
            payload = json.dumps(customization_payload(), ensure_ascii=False, indent=2).encode("utf-8")
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            audit(user, "customization_export", "settings", "", "تصدير ملف تخصيص")
            self._send(200, payload, "application/json; charset=utf-8",
                       {"Content-Disposition": f'attachment; filename="UroCare_Customization_{stamp}.json"'})
        elif path == "/api/storage":
            self._require_owner(user)
            info = storage_info()
            with connection() as db:
                row = db.execute("SELECT created_at,entity_id FROM audit_log WHERE action IN ('backup_auto','backup_manual') ORDER BY id DESC LIMIT 1").fetchone()
            info["last_backup"] = {"at": row["created_at"], "name": row["entity_id"]} if row else None
            self._send(200, info)
        elif path == "/api/system/diagnostics":
            self._require_owner(user)
            result = system_diagnostics()
            audit(user, "system_diagnostics", "system", "", "فحص حالة النظام")
            self._send(200, result)
        elif path == "/api/backups":
            self._require_owner(user)
            refresh_storage_alert()
            refresh_clinical_followup_alerts()
            files = []
            backup_files = list(BACKUP_DIR.glob("*.zip")) + list(BACKUP_DIR.glob("*.ucb"))
            for item in sorted(backup_files, key=lambda f: f.stat().st_mtime, reverse=True):
                stat = item.stat()
                files.append({"name": item.name, "size": stat.st_size, "modified_at": datetime.fromtimestamp(stat.st_mtime).astimezone().isoformat(timespec="seconds")})
            self._send(200, {"backups": files, "alerts": list_system_alerts()})
        elif path == "/api/backups/recovery-kit":
            self._require_owner(user)
            if not list(BACKUP_DIR.glob("*.zip")) and not list(BACKUP_DIR.glob("*.ucb")):
                self._error(409, "أنشئ نسخة احتياطية أولًا قبل تجهيز حزمة الاسترداد")
                return
            kit, kit_name, backup_name = build_recovery_kit()
            audit(user, "recovery_kit_download", "backup", backup_name, "تنزيل حزمة استرداد USB دون مفتاح التشفير")
            self._send(200, kit, "application/zip", {"Content-Disposition": f'attachment; filename="{kit_name}"'})
        elif path.startswith("/api/backups/download/"):
            self._require_owner(user)
            name = Path(urllib.parse.unquote(path.rsplit("/", 1)[-1])).name
            target = BACKUP_DIR / name
            if not target.is_file() or target.suffix.lower() not in {".zip", ".ucb"}:
                self._error(404, "النسخة غير موجودة")
                return
            audit(user, "backup_download", "backup", name, "تنزيل نسخة احتياطية ZIP مشفرة")
            content_type = "application/zip" if target.suffix.lower() == ".zip" else "application/octet-stream"
            self._send(200, target.read_bytes(), content_type, {"Content-Disposition": f'attachment; filename="{name}"'})
        elif path == "/api/backups/key":
            self._require_owner(user)
            key = default_backup_key()
            audit(user, "backup_key_download", "backup", "", "تنزيل مفتاح الاستعادة")
            self._send(200, key, "text/plain; charset=utf-8", {"Content-Disposition": 'attachment; filename="UroCare_Backup_Recovery_Key.txt"'})
        elif path == "/api/audit/export":
            if not allowed(user, "audit", "export"):
                raise PermissionError("ليست لديك صلاحية تصدير سجل التدقيق")
            payload = audit_csv_payload(query, user)
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            self._send(200, payload, "text/csv; charset=utf-8",
                       {"Content-Disposition": f'attachment; filename="UroCare_Audit_{stamp}.csv"'})
        elif path == "/api/audit":
            if not allowed(user, "audit", "view"):
                raise PermissionError("ليست لديك صلاحية قراءة سجل التدقيق")
            self._send(200, query_audit_log(query))
        elif path == "/api/reports":
            self._require("patients", "view")
            if user["role"] not in {OWNER, "ADMIN"} and not any(allowed(user, kind, "report") for kind in ALL_KINDS):
                raise PermissionError("ليست لديك صلاحية عرض التقارير")
            audit(user, "report_view", "reports", "", "عرض تقرير تشغيلي")
            self._send(200, self._reports(query))
        elif path == "/api/permissions":
            rules = ROLE_PERMISSIONS.get(user["role"], {})
            if user["role"] not in ROLE_PERMISSIONS:
                with connection() as db:
                    row = db.execute("SELECT permissions_json FROM custom_roles WHERE code=?", (user["role"],)).fetchone()
                rules = json.loads(row[0]) if row else {}
            self._send(200, {"roles": role_labels(), "permissions": {k: sorted(v) if isinstance(v, set) else v for k,v in rules.items()}})
        else:
            self._error(404, "المسار غير موجود")

    def _mutate_api(self, method: str, path: str, body: dict, raw: bytes):
        if path == "/api/setup" and method == "POST":
            if self.client_address[0] not in ("127.0.0.1", "::1"):
                raise PermissionError("الإعداد الأول يجب أن يتم من جهاز السيرفر نفسه")
            with SETUP_LOCK:
                if owner_count() != 0:
                    raise PermissionError("تم تنفيذ الإعداد الأول مسبقًا")
                owners = body.get("owners", [])
                if len(owners) != 2:
                    raise ValueError("يجب إنشاء حسابي المالك الاثنين في الإعداد الأول")
                names = set()
                for item in owners:
                    username = str(item.get("username", "")).strip().lower()
                    display = str(item.get("display_name", "")).strip()
                    password = str(item.get("password", ""))
                    if len(username) < 4 or not username.replace("_", "").replace("-", "").isalnum():
                        raise ValueError("اسم المستخدم يجب أن يكون 4 أحرف أو أكثر ويحتوي حروفًا أو أرقامًا")
                    if len(display) < 2 or len(password) < 12:
                        raise ValueError("أدخل الاسم وكلمة مرور بطول 12 حرفًا على الأقل لكل مالك")
                    if username in names: raise ValueError("يجب أن يكون اسما حسابي المالك مختلفين")
                    names.add(username)
                with connection() as db:
                    for item in owners:
                        db.execute("INSERT INTO users(id,username,display_name,role,password_hash,created_at) VALUES(?,?,?,?,?,?)",
                                   (str(uuid.uuid4()), item["username"].strip().lower(), item["display_name"].strip(), OWNER,
                                    password_hash(item["password"]), now_utc()))
                default_backup_key()
                audit(None, "initial_setup", "system", "", "إنشاء حسابي المالك")
            self._send(201, {"ok": True, "message": "اكتمل الإعداد. سجّل الدخول بحساب المالك."})
            return
        if path == "/api/login" and method == "POST":
            ip = self.client_address[0]
            now = time.time()
            username = str(body.get("username", "")).strip().lower()
            if login_rate_limited(ip, username, now):
                raise PermissionError("محاولات كثيرة. انتظر عشر دقائق ثم حاول مجددًا")
            with connection() as db:
                user = db.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
            if not user or not user["active"] or not password_ok(str(body.get("password", "")), user["password_hash"]):
                login_failure(ip, username, now)
                audit(None, "login_failed", "user", username, "فشل تسجيل الدخول")
                raise PermissionError("اسم المستخدم أو كلمة المرور غير صحيحة")
            recovery_used = False
            if user["totp_secret"] and not verify_totp(user["totp_secret"], str(body.get("totp", ""))):
                if not consume_recovery_code(user["id"], body.get("totp", "")):
                    login_failure(ip, username, now)
                    audit(None, "mfa_failed", "user", username, "فشل رمز التحقق بخطوتين")
                    raise PermissionError("رمز التحقق أو رمز الاسترداد غير صحيح")
                recovery_used = True
            LOGIN_ATTEMPTS.pop(ip, None)
            LOGIN_ACCOUNT_ATTEMPTS.pop(username, None)
            token, csrf = make_session(user["id"])
            with connection() as db:
                db.execute("UPDATE users SET last_login_at=? WHERE id=?", (now_utc(), user["id"]))
            audit(dict(user), "login", "user", user["id"], "تسجيل دخول")
            if recovery_used:
                audit(dict(user), "mfa_recovery_used", "user", user["id"], "استخدام رمز استرداد لمرة واحدة")
            headers = {"Set-Cookie": f"urocare_session={token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age={SESSION_COOKIE_SECONDS}"}
            self._send(200, self._public_user(dict(user), csrf), headers=headers)
            return
        if path == "/api/logout" and method == "POST":
            user, _ = self._require(csrf=True)
            cookie = self._cookies().get("urocare_session")
            if cookie:
                token_hash = hashlib.sha256(cookie.value.encode()).hexdigest()
                with connection() as db: db.execute("DELETE FROM sessions WHERE token_hash=?", (token_hash,))
            audit(user, "logout", "user", user["id"], "تسجيل خروج")
            self._send(200, {"ok": True}, headers={"Set-Cookie": "urocare_session=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0"})
            return
        if path == "/api/account/sessions/revoke" and method == "POST":
            user, _ = self._require(csrf=True)
            cookie = self._cookies().get("urocare_session")
            current_hash = hashlib.sha256(cookie.value.encode()).hexdigest() if cookie else ""
            revoked = revoke_other_sessions(user["id"], current_hash)
            audit(user, "sessions_revoke", "user", user["id"], f"إغلاق {revoked} جلسة أخرى للحساب")
            self._send(200, {"ok": True, "revoked": revoked})
            return

        user, _ = self._require()
        if path in ("/api/branding/banner", "/api/branding/logo") and method == "POST":
            self._require_owner(user)
            asset = path.rsplit("/", 1)[-1]
            data_key, mime_key = f"brand_{asset}_data", f"brand_{asset}_mime"
            if body.get("remove") is True:
                image_data, image_mime = "", ""
            else:
                image_mime = body.get("mime")
                image_data = body.get("data")
                decoded = decode_brand_banner(image_data, image_mime)
                image_data = base64.b64encode(decoded).decode("ascii")
            updated = now_utc()
            with connection() as db:
                db.executemany(
                    "INSERT INTO settings(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at",
                    [(data_key, image_data, updated), (mime_key, image_mime, updated)],
                )
            audit(user, f"branding_{asset}_update", "settings", asset, ("تحديث " if image_data else "إزالة ") + ("بانر" if asset == "banner" else "شعار") + " هوية المنشأة")
            self._send(200, {"ok": True, mime_key: image_mime})
            return
        if path.startswith("/api/alerts/") and path.endswith("/resolve") and method == "POST":
            if user["role"] not in (OWNER, "ADMIN"):
                raise PermissionError("إغلاق تنبيهات النظام متاح للمالك والمدير فقط")
            alert_id = path[len("/api/alerts/"):-len("/resolve")].strip("/")
            if not alert_id or len(alert_id) > 80:
                raise ValueError("معرف التنبيه غير صالح")
            with connection() as db:
                row = db.execute("SELECT code FROM system_alerts WHERE id=? AND resolved_at IS NULL", (alert_id,)).fetchone()
            if not row:
                self._error(404, "التنبيه غير موجود أو تم إغلاقه")
                return
            with connection() as db:
                db.execute("UPDATE system_alerts SET resolved_at=?,resolved_by=?,updated_at=? WHERE id=? AND resolved_at IS NULL",
                           (now_utc(), user["id"], now_utc(), alert_id))
            audit(user, "system_alert_resolved", "system_alert", alert_id, f"إغلاق تنبيه {row['code']}")
            self._send(200, {"ok": True})
            return
        if path == "/api/audit/export" and method == "POST":
            kind = str(body.get("kind", ""))
            count = body.get("count", 0)
            if type(count) is not int or not 0 <= count <= 10000:
                raise ValueError("عدد السجلات المراد تصديرها غير صالح")
            if kind == "reports":
                if not allowed(user, "patients", "view") or (user["role"] not in {OWNER, "ADMIN"} and not any(allowed(user, item, "report") or allowed(user, item, "export") for item in ALL_KINDS)):
                    raise PermissionError("ليست لديك صلاحية تصدير التقارير")
            elif kind not in ALL_KINDS or (user["role"] not in {OWNER, "ADMIN"} and not (allowed(user, kind, "export") or allowed(user, kind, "report"))):
                raise PermissionError("ليست لديك صلاحية تصدير بيانات هذه الوحدة")
            audit(user, "data_export", kind, "", f"تصدير بيانات CSV ({count} سجل)")
            self._send(200, {"ok": True})
            return
        if path == "/api/emergency-access" and method == "POST":
            record_id = str(body.get("record_id", "")).strip()
            reason = str(body.get("reason", "")).strip()
            try:
                duration = int(body.get("duration_minutes", 30))
            except (TypeError, ValueError):
                raise ValueError("مدة وصول الطوارئ غير صالحة")
            if not record_id or len(reason) < 10 or len(reason) > 500:
                raise ValueError("أدخل السجل وسبب وصول الطوارئ بوضوح")
            if not 5 <= duration <= 120:
                raise ValueError("مدة وصول الطوارئ يجب أن تكون بين 5 و120 دقيقة")
            with connection() as db:
                row = db.execute("SELECT id,kind FROM records WHERE id=?", (record_id,)).fetchone()
            if not row or row["kind"] not in EMERGENCY_ACCESS_KINDS:
                raise ValueError("السجل غير صالح لوصول الطوارئ")
            if not allowed(user, row["kind"], "break_glass"):
                raise PermissionError("ليست لديك صلاحية طلب وصول الطوارئ لهذا النوع من السجلات")
            access_id = str(uuid.uuid4())
            created = now_utc()
            expires_at = int(time.time()) + duration * 60
            with connection() as db:
                db.execute("INSERT INTO emergency_access(id,user_id,entity_kind,entity_id,reason,expires_at,created_at) VALUES(?,?,?,?,?,?,?)",
                           (access_id, user["id"], row["kind"], record_id, reason, expires_at, created))
            audit(user, "emergency_access_grant", row["kind"], record_id, f"وصول طوارئ مؤقت لمدة {duration} دقيقة")
            self._send(201, {"ok": True, "id": access_id, "expires_at": expires_at, "created_at": created})
            return
        if path == "/api/patients/merge" and method == "POST":
            self._require_owner(user)
            source_id = str(body.get("source_id", "")).strip()
            target_id = str(body.get("target_id", "")).strip()
            moved, stamp = merge_patient_records(source_id, target_id, user)
            audit(user, "patient_merge", "patients", source_id, f"دمج ملف مريض في ملف آخر ونقل {moved} سجلًا")
            self._send(200, {"ok": True, "source_id": source_id, "target_id": target_id, "moved_records": moved, "archived_at": stamp})
            return
        if path == "/api/attachments" and method == "POST":
            self._require("attachments", "create")
            if not allowed(user, "patients", "view"):
                raise PermissionError("يلزم توفر صلاحية عرض ملف المريض لإضافة مرفق")
            fields, filename, file_data, media_type = parse_attachment_multipart(raw, self.headers.get("Content-Type", ""))
            patient_id = fields.get("patient_id", "")
            with connection() as db:
                patient = db.execute("SELECT * FROM records WHERE id=? AND kind='patients'", (patient_id,)).fetchone()
            if not patient: raise ValueError("اختر ملف مريض صحيحًا")
            patient_data = json.loads(patient["payload_json"])
            attachment_id = str(uuid.uuid4())
            stored_name = attachment_id + Path(filename).suffix.lower()
            ensure_dirs()
            temp_file = UPLOAD_DIR / (stored_name + ".tmp")
            final_file = UPLOAD_DIR / stored_name
            try:
                temp_file.write_bytes(file_data)
                os.replace(temp_file, final_file)
                created = now_utc()
                data = {"patient_id": patient_id, "patient_name": patient_data.get("name_ar") or patient_data.get("name_en", ""),
                        "file_name": filename, "stored_name": stored_name, "media_type": media_type,
                        "size": len(file_data), "description": fields.get("description", "")[:500]}
                with connection() as db:
                    db.execute("INSERT INTO records(id,kind,code,title,status,priority,payload_json,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                               (attachment_id, "attachments", "", filename[:250], "active", "normal", json.dumps(data, ensure_ascii=False), user["id"], created, created))
                audit(user, "attachment_upload", "attachments", attachment_id, f"رفع مرفق لملف {patient_data.get('file_code', '')}")
            except Exception:
                temp_file.unlink(missing_ok=True)
                final_file.unlink(missing_ok=True)
                raise
            self._send(201, {"ok": True, "id": attachment_id, "data": data, "created_at": created})
            return
        if path == "/api/roles" and method == "POST":
            self._require_owner(user)
            name_ar = str(body.get("name_ar", "")).strip()
            name_en = str(body.get("name_en", "")).strip()
            permissions = body.get("permissions") or {}
            actions = PERMISSION_ACTIONS
            if len(name_ar) < 2 or not isinstance(permissions, dict):
                raise ValueError("أدخل اسم الدور وحدد صلاحياته")
            clean = {}
            for kind, granted in permissions.items():
                if kind not in PERMISSION_KINDS or not isinstance(granted, list) or any(action not in actions for action in granted):
                    raise ValueError("الصلاحيات المحددة غير صالحة")
                if "print" in granted and kind not in PRINTABLE_KINDS:
                    raise ValueError("الطباعة غير متاحة لهذه الوحدة")
                if "sign" in granted and kind not in SIGNABLE_KINDS:
                    raise ValueError("اعتماد السجل غير متاح لهذه الوحدة")
                if "break_glass" in granted and kind not in EMERGENCY_ACCESS_KINDS:
                    raise ValueError("وصول الطوارئ غير متاح لهذه الوحدة")
                if kind == "lookups" and any(action != "view" for action in granted):
                    raise ValueError("إضافة القوائم المرجعية وتعديلها متاحان للمالك فقط")
                clean[kind] = sorted(set(granted))
            if not any(clean.values()): raise ValueError("اختر صلاحية واحدة على الأقل")
            code = "CUSTOM_" + secrets.token_hex(4).upper()
            with connection() as db:
                db.execute("INSERT INTO custom_roles(code,name_ar,name_en,permissions_json,created_by,created_at) VALUES(?,?,?,?,?,?)",
                           (code, name_ar, name_en or name_ar, json.dumps(clean), user["id"], now_utc()))
            audit(user, "role_create", "role", code, f"إنشاء دور {name_ar}؛ {permission_change_summary({}, clean)}")
            self._send(201, {"code": code, "ok": True})
            return
        if path.startswith("/api/roles/") and method == "PATCH":
            self._require_owner(user)
            code = path.rsplit("/", 1)[-1]
            with connection() as db:
                role_row = db.execute("SELECT * FROM custom_roles WHERE code=?", (code,)).fetchone()
            if not role_row: self._error(404, "الدور غير موجود"); return
            fields, values = [], []
            if "name_ar" in body:
                fields.append("name_ar=?"); values.append(str(body["name_ar"]).strip())
            if "name_en" in body:
                fields.append("name_en=?"); values.append(str(body["name_en"]).strip())
            before_permissions = json.loads(role_row["permissions_json"] or "{}")
            after_permissions = before_permissions
            if "permissions" in body:
                permissions = body["permissions"]
                actions = PERMISSION_ACTIONS
                if not isinstance(permissions, dict): raise ValueError("الصلاحيات غير صالحة")
                clean = {}
                for kind, granted in permissions.items():
                    if kind not in PERMISSION_KINDS or not isinstance(granted, list) or any(action not in actions for action in granted):
                        raise ValueError("الصلاحيات المحددة غير صالحة")
                    if "print" in granted and kind not in PRINTABLE_KINDS:
                        raise ValueError("الطباعة غير متاحة لهذه الوحدة")
                    if "sign" in granted and kind not in SIGNABLE_KINDS:
                        raise ValueError("اعتماد السجل غير متاح لهذه الوحدة")
                    if "break_glass" in granted and kind not in EMERGENCY_ACCESS_KINDS:
                        raise ValueError("وصول الطوارئ غير متاح لهذه الوحدة")
                    if kind == "lookups" and any(action != "view" for action in granted):
                        raise ValueError("إضافة القوائم المرجعية وتعديلها متاحان للمالك فقط")
                    clean[kind] = sorted(set(granted))
                after_permissions = clean
                fields.append("permissions_json=?"); values.append(json.dumps(clean))
            if "active" in body:
                if not isinstance(body["active"], bool): raise ValueError("حالة الدور غير صالحة")
                if not body["active"]:
                    with connection() as db:
                        assigned = db.execute("SELECT COUNT(*) FROM users WHERE role=? AND active=1", (code,)).fetchone()[0]
                    if assigned: raise ValueError("انقل المستخدمين لهذا الدور إلى دور آخر قبل تعطيله")
                fields.append("active=?"); values.append(1 if body["active"] else 0)
            if fields:
                values.append(code)
                with connection() as db: db.execute(f"UPDATE custom_roles SET {','.join(fields)} WHERE code=?", values)
                audit(user, "role_update", "role", code, f"تحديث دور وصلاحياته؛ {permission_change_summary(before_permissions, after_permissions)}")
            self._send(200, {"ok": True})
            return
        if path == "/api/records" and method == "POST":
            kind = str(body.get("kind", ""))
            if kind == "attachments": raise ValueError("ارفع الملف من نموذج المرفقات")
            if kind == "lookups": self._require_owner(user)
            if kind == "clinical_templates": self._require_owner(user)
            if kind not in ALL_KINDS or not allowed(user, kind, "create"):
                raise PermissionError("ليست لديك صلاحية إضافة هذا النوع من البيانات")
            data = body.get("data") or {}
            if not isinstance(data, dict): raise ValueError("بيانات السجل غير صحيحة")
            if user["role"] == "RECEPTION":
                data = reception_record_data(kind, data)
            self._require_record_workflow(user, kind, data)
            self._create_record(user, kind, data)
            return
        if path == "/api/patients/import-xlsx" and method == "POST":
            self._require_owner(user)
            _, filename, payload, _ = parse_attachment_multipart(raw, self.headers.get("Content-Type", ""))
            if Path(filename).suffix.lower() != ".xlsx":
                raise ValueError("اختر ملف Excel بصيغة XLSX")
            rows = parse_xlsx_rows(payload)
            self._mutate_api("POST", "/api/patients/import", {"rows": rows}, b"")
            return
        if path == "/api/patients/import" and method == "POST":
            self._require_owner(user)
            rows = body.get("rows")
            if not isinstance(rows, list) or not rows or len(rows) > 10000:
                raise ValueError("أرسل من 1 إلى 10000 صف صالح للاستيراد")
            allowed_fields = {"file_code", "nationality", "nationality_country", "national_id", "identity_document_type", "identity_document_no", "name_ar", "name_en", "gender", "dob", "phone", "address", "emergency_contact", "blood_group", "contact_preference", "communication_consent", "consent_at", "allergies", "chronic_diseases", "insurance", "medical_history", "surgical_history", "family_history", "notes"}
            created, skipped, errors, seen_ids = 0, 0, [], set()
            with connection() as db:
                existing_ids = {_normalize_digits(row[0]).strip() for row in db.execute("SELECT json_extract(payload_json,'$.national_id') FROM records WHERE kind='patients' AND json_extract(payload_json,'$.national_id')<>''")}
                for index, source in enumerate(rows, 1):
                    if not isinstance(source, dict):
                        errors.append({"row": index, "error": "الصف ليس كائن بيانات"}); continue
                    data = {key: str(value).strip()[:5000] for key, value in source.items() if key in allowed_fields and value is not None and str(value).strip()}
                    if len(str(data.get("name_ar", ""))) < 2:
                        errors.append({"row": index, "error": "الاسم بالعربية مطلوب"}); continue
                    try:
                        validate_patient_identity(data, require_nationality=True)
                    except ValueError as exc:
                        errors.append({"row": index, "error": str(exc)}); continue
                    national_id = _normalize_digits(data.get("national_id", "")).strip()
                    data["national_id"] = national_id
                    if national_id and (national_id in existing_ids or national_id in seen_ids):
                        skipped += 1; errors.append({"row": index, "error": "رقم قومي مكرر"}); continue
                    validate_patient_contact_preferences(data)
                    code = data.get("file_code") or f"UC-{facility_now():%Y%m%d}-{secrets.token_hex(3).upper()}"
                    if db.execute("SELECT 1 FROM records WHERE kind='patients' AND code=?", (code,)).fetchone():
                        errors.append({"row": index, "error": "رقم الملف مستخدم بالفعل"}); continue
                    data["file_code"] = code
                    stamp, rid = now_utc(), str(uuid.uuid4())
                    db.execute("INSERT INTO records(id,kind,code,title,status,priority,payload_json,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)", (rid, "patients", code, data.get("name_ar", "")[:250], "new", "normal", json.dumps(data, ensure_ascii=False), user["id"], stamp, stamp))
                    if national_id: seen_ids.add(national_id)
                    created += 1
            audit(user, "patient_import", "patients", "", f"استيراد مرضى بالجملة: أضيف {created} وتخطى {skipped} ورفض {len(errors)} صفًا")
            self._send(200, {"ok": True, "created": created, "skipped": skipped, "errors": errors[:100]})
            return
        if path.startswith("/api/records/"):
            parts = path.strip("/").split("/")
            record_id = parts[2] if len(parts) > 2 else ""
            action = parts[3] if len(parts) > 3 else ""
            with connection() as db:
                row = db.execute("SELECT * FROM records WHERE id=?", (record_id,)).fetchone()
            if not row: self._error(404, "السجل غير موجود"); return
            if row["kind"] == "clinical_templates": self._require_owner(user)
            if action == "sign" and method == "POST":
                if row["kind"] not in SIGNABLE_KINDS or not allowed(user, row["kind"], "sign"):
                    raise PermissionError("ليست لديك صلاحية اعتماد هذا السجل")
                expected_revision = body.get("revision")
                if type(expected_revision) is not int or expected_revision != row["revision"]:
                    raise RecordConflictError("هذا السجل تم تعديله بعد فتحه. أعد تحميل النسخة الحالية قبل الاعتماد.")
                data = json.loads(row["payload_json"])
                if data.get("signed_at"):
                    raise ValueError("السجل معتمد بالفعل؛ استخدم إضافة ملحق عند الحاجة")
                stamp = now_utc()
                data["signed_at"] = stamp
                data["signed_by"] = str(user.get("display_name") or user.get("username") or "")[:160]
                data["signed_by_id"] = str(user.get("id", ""))
                with connection() as db:
                    result = db.execute("UPDATE records SET payload_json=?,updated_at=?,revision=revision+1 WHERE id=? AND revision=?",
                                        (json.dumps(data, ensure_ascii=False), stamp, row["id"], expected_revision))
                if result.rowcount != 1:
                    raise RecordConflictError("سبقك مستخدم آخر باعتماد هذا السجل")
                audit(user, "record_sign", row["kind"], row["id"], "اعتماد سجل سريري")
                self._send(200, {"ok": True, "signed_at": stamp, "revision": expected_revision + 1})
                return
            if action == "addendum" and method == "POST":
                if row["kind"] not in SIGNABLE_KINDS or not allowed(user, row["kind"], "sign"):
                    raise PermissionError("ليست لديك صلاحية إضافة ملحق سريري")
                expected_revision = body.get("revision")
                if type(expected_revision) is not int or expected_revision != row["revision"]:
                    raise RecordConflictError("هذا السجل تم تعديله بعد فتحه. أعد تحميل النسخة الحالية.")
                data = json.loads(row["payload_json"])
                addendum = make_record_addendum(data, user, body.get("text", ""), body.get("reason", ""))
                data.setdefault("addenda", []).append(addendum)
                stamp = now_utc()
                with connection() as db:
                    result = db.execute("UPDATE records SET payload_json=?,updated_at=?,revision=revision+1 WHERE id=? AND revision=?",
                                        (json.dumps(data, ensure_ascii=False), stamp, row["id"], expected_revision))
                if result.rowcount != 1:
                    raise RecordConflictError("سبقك مستخدم آخر بتعديل هذا السجل")
                audit(user, "record_addendum", row["kind"], row["id"], "إضافة ملحق سريري")
                self._send(200, {"ok": True, "id": addendum["id"], "revision": expected_revision + 1})
                return
            if action == "archive" and method == "POST":
                if row["kind"] == "lookups": self._require_owner(user)
                if not allowed(user, row["kind"], "archive"): raise PermissionError("ليست لديك صلاحية أرشفة هذا السجل")
                data = json.loads(row["payload_json"]); data["status"] = "archived"
                self._update_record(user, row, data, "archive")
                return
            if not action and method in ("PATCH", "PUT"):
                if row["kind"] == "lookups": self._require_owner(user)
                patch = body.get("data") or {}
                if not isinstance(patch, dict): raise ValueError("التعديل غير صحيح")
                expected_revision = body.get("revision")
                if type(expected_revision) is not int or expected_revision != row["revision"]:
                    raise RecordConflictError("هذا السجل تم تعديله بعد فتح النموذج. أعد تحميل النسخة الحالية قبل الحفظ.")
                current = json.loads(row["payload_json"])
                if user["role"] == "RECEPTION":
                    patch = reception_record_data(row["kind"], patch)
                current.update(patch)
                workflow_actions = record_transition_actions(row["kind"], current, json.loads(row["payload_json"]))
                if not allowed(user, row["kind"], "update") and not workflow_actions:
                    raise PermissionError("ليست لديك صلاحية تعديل هذا السجل")
                self._require_record_workflow(user, row["kind"], current, json.loads(row["payload_json"]))
                self._update_record(user, row, current, "update", expected_revision)
                return
        if path == "/api/users" and method == "POST":
            if not allowed(user, "users", "manage"): raise PermissionError("ليست لديك صلاحية إدارة المستخدمين")
            role = str(body.get("role", "VIEWER")).upper()
            if role == OWNER or not valid_role(role): raise ValueError("الدور المحدد غير متاح")
            if user["role"] != OWNER and role in ("ADMIN", "AUDITOR_VIEWER"):
                raise PermissionError("المالك وحده يستطيع منح صلاحيات الإدارة أو التدقيق")
            username = str(body.get("username", "")).strip().lower()
            display = str(body.get("display_name", "")).strip()
            password = str(body.get("password", ""))
            department = str(body.get("department", get_settings().get("department_name", ""))).strip()
            if len(username) < 4 or len(display) < 2 or len(password) < 12:
                raise ValueError("اسم المستخدم 4 أحرف على الأقل وكلمة المرور 12 حرفًا على الأقل")
            if len(department) > 120: raise ValueError("اسم القسم لا يجب أن يتجاوز 120 حرفًا")
            uid = str(uuid.uuid4())
            try:
                with connection() as db:
                    db.execute("INSERT INTO users(id,username,display_name,role,password_hash,created_at,department) VALUES(?,?,?,?,?,?,?)",
                               (uid, username, display, role, password_hash(password), now_utc(), department))
            except sqlite3.IntegrityError:
                raise ValueError("اسم المستخدم مستخدم بالفعل")
            audit(user, "user_create", "user", uid, f"إنشاء مستخدم بدور {role}")
            self._send(201, {"id": uid, "ok": True})
            return
        if path == "/api/announcements" and method == "POST":
            if not allowed(user, "announcements", "create"):
                raise PermissionError("إرسال الإعلانات والمناسبات متاح للمالك والمدير فقط")
            title = str(body.get("title", "")).strip()
            message = str(body.get("body", "")).strip()
            event_type = str(body.get("event_type", "notice")).strip()
            audience_type = str(body.get("audience_type", "")).strip()
            audience_value = str(body.get("audience_value", "")).strip()
            if not 2 <= len(title) <= 160 or not 1 <= len(message) <= 4000:
                raise ValueError("عنوان المناسبة من حرفين إلى 160، والرسالة حتى 4000 حرف")
            if event_type not in ANNOUNCEMENT_TYPES:
                raise ValueError("نوع المناسبة غير صالح")
            if audience_type not in {"all", "user", "department"}:
                raise ValueError("اختر نطاق إرسال صحيحًا")
            starts_at = normalize_announcement_datetime(body.get("starts_at"), get_settings().get("timezone", "Africa/Cairo"))
            with connection() as db:
                recipient_count = 0
                if audience_type == "all":
                    audience_value = ""
                    recipient_count = db.execute("SELECT COUNT(*) FROM users WHERE active=1").fetchone()[0]
                elif audience_type == "user":
                    target = db.execute("SELECT id,active FROM users WHERE id=?", (audience_value,)).fetchone()
                    if not target or not target["active"]: raise ValueError("المستخدم المستلم غير متاح")
                    recipient_count = 1
                else:
                    if not 1 <= len(audience_value) <= 120: raise ValueError("اختر اسم القسم المستهدف")
                    recipient_count = db.execute("SELECT COUNT(*) FROM users WHERE active=1 AND lower(trim(department))=lower(?)", (audience_value,)).fetchone()[0]
                    if recipient_count == 0: raise ValueError("لا يوجد مستخدمون نشطون مسجلون في هذا القسم")
                announcement_id = str(uuid.uuid4())
                created_at = now_utc()
                db.execute("INSERT INTO announcements(id,created_by,title,body,event_type,starts_at,audience_type,audience_value,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
                           (announcement_id, user["id"], title, message, event_type, starts_at, audience_type, audience_value, created_at))
            audit(user, "announcement_create", "announcement", announcement_id,
                  f"إضافة مناسبة/إعلان؛ النطاق {audience_type}؛ عدد المستلمين {recipient_count}")
            self._send(201, {"ok": True, "id": announcement_id, "recipients": recipient_count})
            return
        if path.startswith("/api/announcements/") and path.endswith("/archive") and method == "POST":
            if not allowed(user, "announcements", "archive"):
                raise PermissionError("إدارة الإعلانات متاحة للمالك والمدير فقط")
            announcement_id = path[len("/api/announcements/"):-len("/archive")].strip("/")
            if not announcement_id or len(announcement_id) > 80: raise ValueError("معرف المناسبة غير صالح")
            with connection() as db:
                result = db.execute("UPDATE announcements SET active=0 WHERE id=? AND active=1", (announcement_id,))
            if not result.rowcount: raise ValueError("المناسبة غير موجودة أو سبق إيقافها")
            audit(user, "announcement_archive", "announcement", announcement_id, "إيقاف مناسبة أو إعلان")
            self._send(200, {"ok": True})
            return
        if path == "/api/messages" and method == "POST":
            receiver_id = str(body.get("receiver_id", "")).strip()
            message = str(body.get("body", "")).strip()
            if not receiver_id or len(message) < 1 or len(message) > 4000:
                raise ValueError("اختر مستخدمًا واكتب رسالة من 1 إلى 4000 حرف")
            if receiver_id == user["id"]:
                raise ValueError("لا يمكن إرسال رسالة إلى نفس الحساب")
            with connection() as db:
                receiver = db.execute("SELECT id,active FROM users WHERE id=?", (receiver_id,)).fetchone()
                if not receiver or not receiver["active"]:
                    raise ValueError("المستخدم المستلم غير متاح")
                message_id = str(uuid.uuid4())
                db.execute("INSERT INTO messages(id,sender_id,receiver_id,body,created_at) VALUES(?,?,?,?,?)",
                           (message_id, user["id"], receiver_id, message, now_utc()))
            audit(user, "message_send", "message", message_id, "إرسال مراسلة داخلية")
            self._send(201, {"ok": True, "id": message_id})
            return
        if path == "/api/messages/read-all" and method == "POST":
            with connection() as db:
                result = db.execute("UPDATE messages SET read_at=? WHERE receiver_id=? AND read_at IS NULL", (now_utc(), user["id"]))
            audit(user, "messages_read_all", "message", "", f"تحديد {result.rowcount} مراسلة كمقروءة")
            self._send(200, {"ok": True, "changed": result.rowcount})
            return
        if path.startswith("/api/messages/") and path.endswith("/read") and method == "POST":
            message_id = path[len("/api/messages/"):-len("/read")].strip("/")
            if not message_id or len(message_id) > 80:
                raise ValueError("معرف الرسالة غير صالح")
            with connection() as db:
                result = db.execute("UPDATE messages SET read_at=? WHERE id=? AND receiver_id=? AND read_at IS NULL",
                                    (now_utc(), message_id, user["id"]))
            if result.rowcount:
                audit(user, "message_read", "message", message_id, "قراءة مراسلة داخلية")
            self._send(200, {"ok": True, "changed": result.rowcount})
            return
        if path.startswith("/api/users/") and path.endswith("/copy-permissions") and method == "POST":
            self._require_owner(user)
            source_id = path[len("/api/users/"):-len("/copy-permissions")].strip("/")
            target_id = str(body.get("target_user_id", "")).strip()
            if not source_id or not target_id or source_id == target_id:
                raise ValueError("اختر مصدرًا وهدفًا مختلفين لنسخ الصلاحيات")
            with connection() as db:
                source = db.execute("SELECT id,username,display_name,role,active FROM users WHERE id=?", (source_id,)).fetchone()
                target = db.execute("SELECT id,username,display_name,role,active FROM users WHERE id=?", (target_id,)).fetchone()
                if not source or not target or not source["active"] or not target["active"]:
                    raise ValueError("حساب المصدر أو الهدف غير متاح")
                if source["role"] == OWNER or target["role"] == OWNER:
                    raise PermissionError("لا يمكن نسخ صلاحيات المالك أو تطبيقها على حساب مالك")
                source_rules = ROLE_PERMISSIONS.get(source["role"])
                if source_rules is None:
                    role_row = db.execute("SELECT permissions_json FROM custom_roles WHERE code=? AND active=1", (source["role"],)).fetchone()
                    if not role_row:
                        raise ValueError("دور المصدر غير متاح")
                    source_rules = json.loads(role_row["permissions_json"])
                clean = {kind: sorted(set(actions)) for kind, actions in source_rules.items() if isinstance(actions, (set, list, tuple))}
                code = "CUSTOM_" + secrets.token_hex(4).upper()
                name_ar = str(body.get("name_ar") or f"نسخة صلاحيات {source['display_name']}").strip()[:160]
                db.execute("INSERT INTO custom_roles(code,name_ar,name_en,permissions_json,created_by,created_at) VALUES(?,?,?,?,?,?)",
                           (code, name_ar or "دور منسوخ", name_ar or "Copied role", json.dumps(clean, ensure_ascii=False), user["id"], now_utc()))
                db.execute("UPDATE users SET role=? WHERE id=?", (code, target_id))
            audit(user, "permissions_copy", "user", target_id, f"نسخ صلاحيات {source['username']} إلى {target['username']}")
            self._send(200, {"ok": True, "role": code, "target_user": target["username"]})
            return
        if path.startswith("/api/users/") and method == "PATCH":
            if not allowed(user, "users", "manage"): raise PermissionError("ليست لديك صلاحية إدارة المستخدمين")
            uid = path.rsplit("/", 1)[-1]
            with connection() as db: target = db.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
            if not target: self._error(404, "المستخدم غير موجود"); return
            is_owner_target = target["role"] == OWNER
            if is_owner_target and user["role"] != OWNER: raise PermissionError("حسابي المالك محميان")
            if is_owner_target:
                if "role" in body or body.get("active") is False: raise PermissionError("لا يمكن تعطيل أو خفض صلاحية حساب المالك")
            fields = []
            values = []
            if "active" in body and not is_owner_target:
                fields.append("active=?"); values.append(1 if body["active"] else 0)
            if "role" in body and not is_owner_target:
                role = str(body["role"]).upper()
                if not valid_role(role) or role == OWNER: raise ValueError("الدور غير صالح")
                if user["role"] != OWNER and role in ("ADMIN", "AUDITOR_VIEWER"): raise PermissionError("المالك وحده يستطيع منح هذا الدور")
                fields.append("role=?"); values.append(role)
            if "password" in body:
                password = str(body["password"])
                if len(password) < 12: raise ValueError("كلمة المرور يجب ألا تقل عن 12 حرفًا")
                if is_owner_target:
                    if uid == user["id"]: raise ValueError("لا تغيّر كلمة مرور حسابك من إدارة المستخدمين؛ استخدم حساب المالك الآخر")
                    if not password_ok(str(body.get("current_password", "")), user["password_hash"]):
                        raise PermissionError("أعد إدخال كلمة مرور حساب المالك الحالي للتحقق")
                    if user.get("totp_secret") and not verify_totp(user["totp_secret"], str(body.get("totp", ""))):
                        raise PermissionError("أدخل رمز التحقق الحالي لحساب المالك")
                fields.append("password_hash=?"); values.append(password_hash(password))
                with connection() as db: db.execute("DELETE FROM sessions WHERE user_id=?", (uid,))
            if "display_name" in body and user["role"] == OWNER:
                fields.append("display_name=?"); values.append(str(body["display_name"]).strip())
            if "department" in body:
                if is_owner_target and user["role"] != OWNER: raise PermissionError("تعديل حساب المالك متاح للمالك فقط")
                department = str(body.get("department") or "").strip()
                if len(department) > 120: raise ValueError("اسم القسم لا يجب أن يتجاوز 120 حرفًا")
                fields.append("department=?"); values.append(department)
            if fields:
                values.append(uid)
                with connection() as db: db.execute(f"UPDATE users SET {','.join(fields)} WHERE id=?", values)
                audit(user, "owner_password_reset" if is_owner_target and "password" in body else "user_update", "user", uid,
                      f"إعادة تعيين كلمة مرور حساب المالك {target['username']}" if is_owner_target and "password" in body else "تعديل صلاحيات أو حساب مستخدم")
            self._send(200, {"ok": True})
            return
        if path == "/api/settings" and method in ("PATCH", "PUT"):
            if not allowed(user, "settings", "manage"): raise PermissionError("ليست لديك صلاحية تعديل الإعدادات")
            if user["role"] != OWNER and any(k in body for k in ("timezone", "backup_interval_hours", "backup_retention_days", "session_idle_minutes", "procedure_preparation_checklist")):
                raise PermissionError("هذه الإعدادات للمالك فقط")
            if user["role"] != OWNER and any(k in body for k in ("system_name", "hospital_name", "department_name", "facility_type", "facility_country", "facility_governorate", "publisher_title", "publisher_name", "publisher_phone", "brand_banner_data", "brand_banner_mime", "brand_logo_data", "brand_logo_mime", "module_labels")):
                raise PermissionError("تخصيص هوية البرنامج وأسماء القوائم للمالك فقط")
            body.update(normalize_customization_settings({key: value for key, value in body.items() if key in CUSTOMIZATION_SETTINGS}))
            allowed_settings = CUSTOMIZATION_SETTINGS
            with connection() as db:
                for key, value in body.items():
                    if key not in allowed_settings: continue
                    db.execute("INSERT INTO settings(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at",
                               (key, str(value), now_utc()))
            audit(user, "settings_update", "settings", "", "تحديث إعدادات النظام")
            self._send(200, {"ok": True})
            return
        if path == "/api/customization/import" and method == "POST":
            self._require_owner(user)
            if not isinstance(body, dict) or body.get("format") != "urocare-customization" or body.get("version") != 1:
                raise ValueError("ملف التخصيص غير صالح أو ليس من UroCare")
            settings = body.get("settings") or {}
            roles = body.get("roles") or []
            lookups = body.get("lookups") or []
            if not isinstance(settings, dict) or not isinstance(roles, list) or not isinstance(lookups, list):
                raise ValueError("بنية ملف التخصيص غير صالحة")
            settings = normalize_customization_settings(settings)
            for role in roles:
                if not isinstance(role, dict): raise ValueError("بيانات أحد الأدوار في ملف التخصيص غير صالحة")
                if not str(role.get("code", "")).startswith("CUSTOM_"): raise ValueError("ملف التخصيص يتضمن دورًا محميًا غير صالح")
                if not isinstance(role.get("active", True), bool): raise ValueError("حالة أحد الأدوار في ملف التخصيص غير صالحة")
            seen_lookup_values = set()
            for item in lookups:
                if not isinstance(item, dict) or not isinstance(item.get("data"), dict):
                    raise ValueError("بيانات إحدى القيم المرجعية في ملف التخصيص غير صالحة")
                if not isinstance(item.get("active", True), bool): raise ValueError("حالة إحدى القيم المرجعية غير صالحة")
                lookup_data = item["data"]
                if not str(lookup_data.get("category", "")).strip(): lookup_data["category"] = "legacy"
                lookup_code = str(lookup_data.get("code", "")).strip() or str(lookup_data.get("name_ar", "")).strip()
                lookup_key = (str(lookup_data.get("category", "")), lookup_code)
                if lookup_key in seen_lookup_values: raise ValueError("ملف التخصيص يحتوي قيمة مكررة في القائمة نفسها")
                seen_lookup_values.add(lookup_key)
                self._validate_lookup(lookup_data, str(item.get("id", "")) or None)
            with connection() as db:
                for key, value in settings.items():
                    if key not in CUSTOMIZATION_SETTINGS: continue
                    if key == "module_labels":
                        value = json.dumps(value, ensure_ascii=False) if isinstance(value, dict) else str(value)
                    db.execute("INSERT INTO settings(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at",
                               (key, str(value), now_utc()))
                for role in roles:
                    code = str(role.get("code", ""))
                    permissions = role.get("permissions") or {}
                    if len(code) != 15 or any(character not in "0123456789ABCDEF" for character in code[7:]) or not isinstance(permissions, dict):
                        raise ValueError("بيانات الدور أو كوده في ملف التخصيص غير صالحة")
                    clean = {}
                    for kind, granted in permissions.items():
                        if kind not in PERMISSION_KINDS or not isinstance(granted, list) or not all(action in PERMISSION_ACTIONS for action in granted):
                            raise ValueError("صلاحيات أحد الأدوار في ملف التخصيص غير صالحة")
                        if "print" in granted and kind not in PRINTABLE_KINDS:
                            raise ValueError("الطباعة غير متاحة لإحدى وحدات ملف التخصيص")
                        if "sign" in granted and kind not in SIGNABLE_KINDS:
                            raise ValueError("اعتماد السجل غير متاح لإحدى وحدات ملف التخصيص")
                        if "break_glass" in granted and kind not in EMERGENCY_ACCESS_KINDS:
                            raise ValueError("وصول الطوارئ غير متاح لإحدى وحدات ملف التخصيص")
                        if kind == "lookups": granted = [action for action in granted if action == "view"]
                        clean[kind] = sorted(set(granted))
                    if not clean: continue
                    db.execute("INSERT INTO custom_roles(code,name_ar,name_en,permissions_json,created_by,created_at,active) VALUES(?,?,?,?,?,?,?) ON CONFLICT(code) DO UPDATE SET name_ar=excluded.name_ar,name_en=excluded.name_en,permissions_json=excluded.permissions_json,active=excluded.active",
                               (code, str(role.get("name_ar", code))[:160], str(role.get("name_en", role.get("name_ar", code)))[:160], json.dumps(clean, ensure_ascii=False), user["id"], now_utc(), 1 if role.get("active", True) else 0))
                for item in lookups:
                    data = item["data"]
                    rid = str(item.get("id", ""))
                    existing = db.execute("SELECT id FROM records WHERE id=? AND kind='lookups'", (rid,)).fetchone() if rid else None
                    stamp = now_utc()
                    payload = json.dumps(data, ensure_ascii=False)
                    title = str(data.get("name_ar") or data.get("name_en_lookup") or data.get("list_name") or "قائمة")[:250]
                    status = "active" if item.get("active", True) else "archived"
                    if existing:
                        db.execute("UPDATE records SET code=?,title=?,payload_json=?,status=?,updated_at=?,revision=revision+1 WHERE id=?",
                                   (str(data.get("code", ""))[:100], title, payload, status, stamp, rid))
                    else:
                        new_id = rid if rid and len(rid) <= 80 else str(uuid.uuid4())
                        db.execute("INSERT OR IGNORE INTO records(id,kind,code,title,status,priority,payload_json,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                                   (new_id, "lookups", str(data.get("code", ""))[:100], title, status, "normal", payload, user["id"], stamp, stamp))
            audit(user, "customization_import", "settings", "", "استيراد هوية وأسماء وقوائم مخصصة")
            self._send(200, {"ok": True, "message": "تم استيراد التخصيصات"})
            return
        if path == "/api/backups/create" and method == "POST":
            self._require_owner(user)
            info = _create_backup_internal("manual")
            audit(user, "backup_manual", "backup", info["name"], "إنشاء نسخة يدوية")
            self._send(201, info)
            return
        if path == "/api/maintenance/pre-update" and method == "POST":
            self._require_owner(user)
            info = _create_backup_internal("pre_update")
            audit(user, "backup_pre_update", "backup", info["name"], "إنشاء نسخة أمان قبل تحديث أو إصلاح البرنامج")
            self._send(201, {"ok": True, "backup": info["name"], "created_at": info["created_at"], "size": info["size"]})
            return
        if path == "/api/backups/restore" and method == "POST":
            self._require_owner(user)
            if "multipart/form-data" not in self.headers.get("Content-Type", ""):
                raise ValueError("ارفع ملف النسخة بصيغة ZIP أو UCB قديمة")
            backup_key, encrypted, fields = parse_multipart(raw, self.headers.get("Content-Type", ""))
            if not password_ok(fields.get("current_password", ""), user["password_hash"]):
                raise PermissionError("أعد إدخال كلمة مرور المالك لتأكيد الاستعادة")
            if user.get("totp_secret") and not verify_totp(user["totp_secret"], fields.get("totp", "")):
                raise PermissionError("أدخل رمز التحقق بخطوتين لتأكيد الاستعادة")
            info = restore_backup(encrypted, backup_key or None, user)
            self._send(200, info)
            return
        if path == "/api/backups/verify" and method == "POST":
            self._require_owner(user)
            name = Path(str(body.get("name", ""))).name
            target = BACKUP_DIR / name
            if not target.is_file() or target.suffix.lower() not in {".zip", ".ucb"}:
                self._error(404, "النسخة غير موجودة")
                return
            try:
                info = verify_backup_file(target)
            except Exception as exc:
                audit(user, "backup_verify_failed", "backup", name, f"فشل فحص النسخة: {str(exc)[:160]}")
                raise
            audit(user, "backup_verify", "backup", name, "فحص سلامة نسخة احتياطية دون استعادتها")
            self._send(200, info)
            return
        if path == "/api/backups/verify-upload" and method == "POST":
            self._require_owner(user)
            if "multipart/form-data" not in self.headers.get("Content-Type", ""):
                raise ValueError("ارفع ملف النسخة بصيغة ZIP أو UCB")
            backup_key, encrypted, _fields = parse_multipart(raw, self.headers.get("Content-Type", ""))
            try:
                info = verify_backup_bytes(encrypted, backup_key or None, "ملف خارجي", len(encrypted))
            except Exception as exc:
                audit(user, "backup_verify_upload_failed", "backup", "", f"فشل فحص نسخة USB: {str(exc)[:160]}")
                raise
            audit(user, "backup_verify_upload", "backup", "", "فحص نسخة خارجية من USB دون استعادتها")
            self._send(200, info)
            return
        if path == "/api/account/totp/start" and method == "POST":
            secret = base64.b32encode(secrets.token_bytes(20)).decode("ascii").rstrip("=")
            with connection() as db: db.execute("UPDATE users SET totp_pending=? WHERE id=?", (secret, user["id"]))
            label = urllib.parse.quote(f"UroCare:{user['username']}")
            issuer = urllib.parse.quote("UroCare Suite")
            uri = f"otpauth://totp/{label}?secret={secret}&issuer={issuer}&algorithm=SHA1&digits=6&period=30"
            self._send(200, {"secret": secret, "uri": uri, "message": "أدخل السر يدويًا في تطبيق المصادقة، ثم أكد برمز التحقق."})
            return
        if path == "/api/account/totp/enable" and method == "POST":
            with connection() as db: row = db.execute("SELECT totp_pending FROM users WHERE id=?", (user["id"],)).fetchone()
            if not row or not verify_totp(row["totp_pending"], str(body.get("code", ""))): raise ValueError("رمز التحقق غير صحيح")
            plain_codes, hashed_codes = generate_recovery_codes()
            with connection() as db: db.execute("UPDATE users SET totp_secret=totp_pending,totp_pending=NULL,recovery_codes=? WHERE id=?", (json.dumps(hashed_codes), user["id"]))
            audit(user, "totp_enable", "user", user["id"], "تفعيل التحقق بخطوتين")
            self._send(200, {"ok": True, "recovery_codes": plain_codes, "message": "احفظ رموز الاسترداد خارج السيرفر؛ لن تظهر مرة أخرى."})
            return
        if path == "/api/account/totp/recovery-codes" and method == "POST":
            current_code = str(body.get("code", ""))
            if not verify_totp(user.get("totp_secret"), current_code):
                raise PermissionError("أدخل رمز التحقق الحالي لإصدار رموز استرداد جديدة")
            plain_codes, hashed_codes = generate_recovery_codes()
            with connection() as db: db.execute("UPDATE users SET recovery_codes=? WHERE id=?", (json.dumps(hashed_codes), user["id"]))
            audit(user, "mfa_recovery_regenerated", "user", user["id"], "إعادة إصدار رموز استرداد لمرة واحدة")
            self._send(200, {"ok": True, "recovery_codes": plain_codes, "message": "احفظ الرموز الجديدة؛ الرموز السابقة لم تعد صالحة."})
            return
        raise ValueError("المسار أو الإجراء غير موجود")

    def _require_owner(self, user):
        if user["role"] != OWNER: raise PermissionError("هذه الوظيفة متاحة لحسابي المالك فقط")

    def _require_record_workflow(self, user: dict, kind: str, data: dict, previous: dict | None = None) -> None:
        for action in record_transition_actions(kind, data, previous):
            if not allowed(user, kind, action):
                raise PermissionError(f"ليست لديك صلاحية «{action}» لتنفيذ هذه المرحلة من دورة السجل")

    def _prepare_admission_bed_updates(self, data: dict, previous: dict | None = None) -> list[tuple[str, dict, int]]:
        """Validate and prepare atomic bed occupancy changes for an admission."""
        if str(data.get("status", "")).strip() != "منوم" and str((previous or {}).get("status", "")).strip() != "منوم":
            return []
        updates: list[tuple[str, dict, int]] = []
        old_status = str((previous or {}).get("status", "")).strip()
        old_bed = str((previous or {}).get("bed_code", "")).strip()
        new_status = str(data.get("status", "")).strip()
        new_bed = str(data.get("bed_code", "")).strip()
        with connection() as db:
            if old_status == "منوم" and (new_status != "منوم" or old_bed != new_bed):
                old_row = db.execute("SELECT * FROM records WHERE kind='beds' AND json_extract(payload_json,'$.bed_code')=? LIMIT 1", (old_bed,)).fetchone()
                if old_row:
                    old_data = json.loads(old_row["payload_json"])
                    old_data["bed_status"] = "متاح"
                    old_data.pop("patient_id", None)
                    old_data.pop("patient_name", None)
                    updates.append((old_row["id"], old_data, old_row["revision"]))
            if new_status == "منوم":
                bed_row = db.execute("SELECT * FROM records WHERE kind='beds' AND json_extract(payload_json,'$.bed_code')=? LIMIT 1", (new_bed,)).fetchone()
                if not bed_row:
                    raise ValueError("رقم السرير غير موجود في لوحة الأسرة")
                bed_data = json.loads(bed_row["payload_json"])
                current_patient = str(bed_data.get("patient_id", "")).strip()
                if str(bed_data.get("bed_status", "")).strip() not in {"متاح", "تنظيف"} and current_patient != str(data.get("patient_id", "")):
                    raise ValueError("السرير المختار غير متاح أو مشغول بمريض آخر")
                bed_data["bed_status"] = "مشغول"
                bed_data["patient_id"] = data.get("patient_id", "")
                bed_data["patient_name"] = data.get("patient_name", "")
                updates.append((bed_row["id"], bed_data, bed_row["revision"]))
        return updates

    def _public_user(self, user: dict, csrf: str | None):
        return {
            "id": user["id"], "username": user["username"], "display_name": user["display_name"],
            "role": user["role"], "role_label": ROLE_LABELS.get(user["role"], user["role"]),
            "csrf": csrf, "mfa_enabled": bool(user.get("totp_secret")),
        }

    def _create_record(self, user: dict, kind: str, data: dict):
        rid = str(uuid.uuid4())
        created = now_utc()
        code = str(data.get("file_code") or data.get("case_number") or data.get("code") or "")[:100]
        if kind == "lookups": self._validate_lookup(data)
        if kind in PATIENT_REQUIRED_KINDS | {"care_tasks"}:
            patient_id = str(data.get("patient_id", "")).strip()
            with connection() as db:
                patient = db.execute("SELECT payload_json FROM records WHERE id=? AND kind='patients' AND status<>'archived'", (patient_id,)).fetchone()
            if not patient:
                raise ValueError("اختر ملف مريض موجودًا وغير مؤرشف قبل إنشاء السجل")
            patient_data = json.loads(patient["payload_json"])
            data["patient_name"] = data.get("patient_name") or patient_data.get("name_ar") or patient_data.get("name_en", "")
        if kind == "patients":
            validate_patient_contact_preferences(data)
            validate_patient_identity(data, require_nationality=True)
            national_id = str(data.get("national_id", "")).strip()
            if national_id:
                with connection() as db:
                    duplicate = db.execute("SELECT id FROM records WHERE kind='patients' AND json_extract(payload_json,'$.national_id')=? LIMIT 1", (national_id,)).fetchone()
                if duplicate: raise ValueError("يوجد ملف مريض مسجل بهذا الرقم القومي؛ ابحث عن الملف قبل إنشاء مكرر")
            if not code:
                code = f"UC-{facility_now():%Y%m%d}-{secrets.token_hex(3).upper()}"
            with connection() as db:
                if db.execute("SELECT 1 FROM records WHERE kind='patients' AND code=?", (code,)).fetchone():
                    raise ValueError("رقم الملف مستخدم بالفعل")
            data["file_code"] = code
        if kind == "waiting":
            data.setdefault("requested_at", facility_today())
            data.setdefault("status", "انتظار")
        if kind == "devices":
            if data.get("removed_at"): data["status"] = "تمت الإزالة"
            else: data.setdefault("status", "موجود")
        if kind == "specimens" and not data.get("status"): data["status"] = "تم الجمع"
        if kind == "procedures":
            validate_procedure_encounter_link(data)
            normalize_procedure_checklist(data, user)
        stamp_workflow_fields(kind, data, user)
        validate_medication_safety(kind, data)
        self._validate_clinical_followup(kind, data)
        if kind == "clinical_templates":
            version = int(data.get("version", 0))
            with connection() as db:
                duplicate = db.execute("SELECT id FROM records WHERE kind='clinical_templates' AND lower(json_extract(payload_json,'$.template_name'))=lower(?) AND CAST(json_extract(payload_json,'$.version') AS INTEGER)=? AND status<>'archived' LIMIT 1", (str(data.get("template_name", "")).strip(), version)).fetchone()
            if duplicate:
                raise ValueError("يوجد إصدار مسجل بهذا الاسم والرقم؛ أنشئ إصدارًا جديدًا أو عدّل السجل الحالي")
        if kind in {"waiting", "appointments", "procedures"} and data.get("status") in {"ملغي", "مؤجل", "cancelled", "deferred", "أعيدت جدولته"} and not str(data.get("cancel_reason", "")).strip():
            raise ValueError("أدخل سبب الإلغاء أو التأجيل")
        self._check_schedule_conflict(kind, data)
        admission_bed_updates = self._prepare_admission_bed_updates(data) if kind == "admissions" else []
        movement_stock_update = None
        if kind == "inventory_movements":
            item_code = str(data.get("item_code", "")).strip()
            with connection() as db:
                inventory_row = db.execute("SELECT * FROM records WHERE kind='inventory' AND json_extract(payload_json,'$.item_code')=? LIMIT 1", (item_code,)).fetchone()
            if not inventory_row:
                raise ValueError("كود الصنف غير موجود في سجل المخزون")
            inventory_data = json.loads(inventory_row["payload_json"])
            current = float(inventory_data.get("quantity", 0) or 0)
            quantity = float(data.get("quantity", 0) or 0)
            movement_type = str(data.get("movement_type", "")).strip()
            delta = quantity if movement_type in {"وارد", "مرتجع"} else -quantity
            new_balance = current + delta
            if new_balance < 0:
                raise ValueError("لا يمكن صرف كمية أكبر من الرصيد الحالي")
            data["item_name"] = data.get("item_name") or inventory_data.get("item_name", "")
            data["balance_before"] = current
            data["balance_after"] = new_balance
            inventory_data["quantity"] = new_balance
            reorder = float(inventory_data.get("reorder_level", 0) or 0)
            inventory_data["status"] = "يحتاج طلب" if new_balance <= reorder else "متاح"
            movement_stock_update = (inventory_row["id"], inventory_data, inventory_row["revision"])
        title = str(data.get("name_ar") or data.get("title") or data.get("procedure_type") or data.get("type") or "")[:250]
        status = str(data.get("status") or "new")[:80]
        priority = str(data.get("priority") or "normal")[:80]
        data.setdefault("status", status)
        with connection() as db:
            for bed_id, bed_data, bed_revision in admission_bed_updates:
                result = db.execute("UPDATE records SET status=?,payload_json=?,updated_at=?,revision=revision+1 WHERE id=? AND revision=?", (bed_data.get("bed_status", ""), json.dumps(bed_data, ensure_ascii=False), created, bed_id, bed_revision))
                if result.rowcount != 1:
                    raise RecordConflictError("تغيرت حالة السرير أثناء الحفظ؛ أعد المحاولة")
            if movement_stock_update:
                inventory_id, inventory_data, inventory_revision = movement_stock_update
                stamp = now_utc()
                db.execute("UPDATE records SET status=?,payload_json=?,updated_at=?,revision=revision+1 WHERE id=? AND revision=?", (inventory_data.get("status", "متاح"), json.dumps(inventory_data, ensure_ascii=False), stamp, inventory_id, inventory_revision))
            db.execute("INSERT INTO records(id,kind,code,title,status,priority,payload_json,created_by,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                       (rid, kind, code, title, status, priority, json.dumps(data, ensure_ascii=False), user["id"], created, created))
        audit(user, "record_create", kind, rid, "إضافة سجل")
        self._send(201, {"id": rid, "kind": kind, "data": data, "created_at": created})

    def _update_record(self, user: dict, row: sqlite3.Row, data: dict, action: str, expected_revision: int | None = None):
        expected_revision = row["revision"] if expected_revision is None else expected_revision
        updated = now_utc()
        old_data = json.loads(row["payload_json"])
        validate_signed_record_update(row["kind"], old_data, data)
        if row["kind"] in PATIENT_REQUIRED_KINDS | {"care_tasks"}:
            patient_id = str(data.get("patient_id", "")).strip()
            with connection() as db:
                patient = db.execute("SELECT payload_json FROM records WHERE id=? AND kind='patients' AND status<>'archived'", (patient_id,)).fetchone()
            if not patient:
                raise ValueError("اختر ملف مريض موجودًا وغير مؤرشف قبل تعديل السجل")
            patient_data = json.loads(patient["payload_json"])
            data["patient_name"] = data.get("patient_name") or patient_data.get("name_ar") or patient_data.get("name_en", "")
        if row["kind"] == "patients":
            validate_patient_contact_preferences(data)
            identity_fields = {"nationality", "nationality_country", "national_id", "identity_document_type", "identity_document_no", "gender", "dob"}
            identity_changed = any(old_data.get(key) != data.get(key) for key in identity_fields)
            if identity_changed or any(data.get(key) for key in identity_fields):
                validate_patient_identity(data, require_nationality=identity_changed)
        if row["kind"] == "devices" and data.get("removed_at"): data["status"] = "تمت الإزالة"
        if row["kind"] == "procedures":
            validate_procedure_encounter_link(data)
            normalize_procedure_checklist(data, user, old_data)
        if row["kind"] == "lookups": self._validate_lookup(data, row["id"])
        stamp_workflow_fields(row["kind"], data, user, old_data)
        validate_medication_safety(row["kind"], data)
        self._validate_clinical_followup(row["kind"], data, old_data)
        if row["kind"] == "clinical_templates":
            version = int(data.get("version", 0))
            with connection() as db:
                duplicate = db.execute("SELECT id FROM records WHERE kind='clinical_templates' AND id<>? AND lower(json_extract(payload_json,'$.template_name'))=lower(?) AND CAST(json_extract(payload_json,'$.version') AS INTEGER)=? AND status<>'archived' LIMIT 1", (row["id"], str(data.get("template_name", "")).strip(), version)).fetchone()
            if duplicate:
                raise ValueError("يوجد إصدار مسجل بهذا الاسم والرقم")
        if user["role"] == "NURSE":
            changed = {key for key in set(old_data) | set(data) if old_data.get(key) != data.get(key)}
            if changed - NURSE_UPDATE_FIELDS:
                raise PermissionError("التمريض لا يملك صلاحية تعديل هذه الحقول")
        if row["kind"] == "waiting":
            if old_data.get("priority") != data.get("priority") and not str(data.get("priority_change_reason", "")).strip():
                raise ValueError("أدخل سبب تغيير أولوية الانتظار")
            if data.get("status") in ("ملغي", "مؤجل", "cancelled", "deferred") and old_data.get("status") != data.get("status") and not str(data.get("cancel_reason", "")).strip():
                raise ValueError("أدخل سبب إلغاء أو تأجيل الحالة")
        if row["kind"] in {"appointments", "procedures"} and data.get("status") in {"ملغي", "مؤجل", "cancelled", "deferred", "أعيدت جدولته"} and old_data.get("status") != data.get("status") and not str(data.get("cancel_reason", "")).strip():
            raise ValueError("أدخل سبب الإلغاء أو التأجيل")
        self._check_schedule_conflict(row["kind"], data, row["id"])
        admission_bed_updates = self._prepare_admission_bed_updates(data, old_data) if row["kind"] == "admissions" else []
        title = str(data.get("name_ar") or data.get("title") or data.get("procedure_type") or data.get("type") or row["title"] or "")[:250]
        status = str(data.get("status") or row["status"] or "")[:80]
        priority = str(data.get("priority") or row["priority"] or "")[:80]
        code = str(data.get("file_code") or data.get("case_number") or data.get("code") or row["code"] or "")[:100]
        if row["kind"] == "patients":
            national_id = _normalize_digits(data.get("national_id", "")).strip()
            data["national_id"] = national_id
            if national_id:
                with connection() as db:
                    duplicate = db.execute("SELECT id FROM records WHERE kind='patients' AND json_extract(payload_json,'$.national_id')=? AND id<>? LIMIT 1", (national_id, row["id"])).fetchone()
                if duplicate: raise ValueError("الرقم القومي مرتبط بملف مريض آخر")
        with connection() as db:
            for bed_id, bed_data, bed_revision in admission_bed_updates:
                result = db.execute("UPDATE records SET status=?,payload_json=?,updated_at=?,revision=revision+1 WHERE id=? AND revision=?", (bed_data.get("bed_status", ""), json.dumps(bed_data, ensure_ascii=False), updated, bed_id, bed_revision))
                if result.rowcount != 1:
                    raise RecordConflictError("تغيرت حالة السرير أثناء الحفظ؛ أعد تحميل السجل وحاول مرة أخرى")
            result = db.execute("UPDATE records SET code=?,title=?,status=?,priority=?,payload_json=?,updated_at=?,revision=revision+1 WHERE id=? AND revision=?",
                                (code, title, status, priority, json.dumps(data, ensure_ascii=False), updated, row["id"], expected_revision))
        if result.rowcount != 1:
            raise RecordConflictError("سبقك مستخدم آخر بتعديل هذا السجل. أعد تحميل النسخة الحالية قبل الحفظ.")
        reason = data.get("priority_change_reason") or data.get("cancel_reason") or ""
        audit(user, f"record_{action}", row["kind"], row["id"], f"تحديث سجل {('— ' + str(reason)) if reason else ''}")
        self._send(200, {"ok": True, "id": row["id"], "updated_at": updated, "revision": expected_revision + 1})

    def _validate_lookup(self, data: dict, exclude_id: str | None = None):
        category = str(data.get("category", ""))
        list_name = str(data.get("list_name", "")).strip()
        name_ar = str(data.get("name_ar", "")).strip()
        code = str(data.get("code", "")).strip() or name_ar
        if category not in LOOKUP_CATEGORIES: raise ValueError("اختَر حقلًا صالحًا لاستخدام هذه القيمة")
        if not list_name or len(list_name) > 120: raise ValueError("اسم القائمة مطلوب وبحد أقصى 120 حرفًا")
        if not name_ar or len(name_ar) > 160: raise ValueError("الاسم العربي مطلوب وبحد أقصى 160 حرفًا")
        if len(code) > 100: raise ValueError("كود القيمة يجب ألا يتجاوز 100 حرف")
        with connection() as db:
            duplicate = db.execute(
                "SELECT id FROM records WHERE kind='lookups' AND id<>? AND json_extract(payload_json,'$.category')=? AND coalesce(nullif(json_extract(payload_json,'$.code'),''),json_extract(payload_json,'$.name_ar'))=? LIMIT 1",
                (exclude_id or "", category, code),
            ).fetchone()
        if duplicate: raise ValueError("هذه القيمة مسجلة بالفعل ضمن القائمة المختارة")

    def _validate_clinical_followup(self, kind: str, data: dict, previous: dict | None = None):
        def required(*fields: str) -> None:
            missing = [field for field in fields if not str(data.get(field, "")).strip()]
            if missing:
                raise ValueError("الحقول المطلوبة ناقصة: " + "، ".join(missing))

        def status_in(allowed_statuses: set[str]) -> None:
            status = str(data.get("status", "")).strip()
            if status and status not in allowed_statuses:
                raise ValueError("حالة السجل غير صالحة لهذه الدورة")

        def transition(allowed: dict[str, set[str]]) -> None:
            if not previous:
                return
            old_status = str(previous.get("status", "")).strip()
            new_status = str(data.get("status", "")).strip()
            if old_status and new_status and old_status != new_status and new_status not in allowed.get(old_status, set()):
                raise ValueError(f"لا يمكن نقل الحالة من «{old_status}» إلى «{new_status}» مباشرة")

        if kind == "admissions":
            required("patient_id", "admission_type")
            status_in({"طلب دخول", "قيد التقييم", "مقبول", "منوم", "محول", "خرج", "خروج ضد النصيحة", "ملغي"})
            transition({
                "طلب دخول": {"قيد التقييم", "مقبول", "ملغي"}, "قيد التقييم": {"مقبول", "محول", "ملغي"},
                "مقبول": {"منوم", "محول", "ملغي"}, "منوم": {"محول", "خرج", "خروج ضد النصيحة"},
                "محول": {"منوم", "خرج", "ملغي"},
            })
            status = str(data.get("status", "")).strip()
            if status in {"خرج", "خروج ضد النصيحة"}:
                required("discharge_at", "discharge_summary", "discharged_by")
            if status == "منوم":
                required("room", "bed_code", "admitting_doctor")

        if kind == "lab_orders":
            required("patient_id", "test_name", "ordered_by")
            status_in({"مطلوب", "تم سحب العينة", "مستلمة", "مرفوضة", "قيد التنفيذ", "نتيجة أولية", "مراجعة", "معتمدة", "ملغاة"})
            if data.get("status") == "مرفوضة": required("rejection_reason")
            if data.get("status") in {"نتيجة أولية", "مراجعة", "معتمدة"}: required("result", "result_unit")
            if data.get("status") == "معتمدة": required("reviewed_by", "reviewed_at")

        if kind == "imaging_orders":
            required("patient_id", "imaging_type", "ordered_by")
            status_in({"مطلوب", "مجدول", "تم التنفيذ", "مسودة تقرير", "مراجعة", "معتمد", "ملغى"})
            if data.get("status") == "معتمد": required("report", "reported_by", "reported_at")

        if kind == "nursing_notes":
            required("patient_id", "note_type", "note", "author")
            status_in({"مسودة", "موقعة", "مغلقة"})
            if data.get("status") in {"موقعة", "مغلقة"}: required("signed_by", "signed_at")

        if kind == "nursing_observations":
            required("patient_id", "observed_at", "recorded_by")
            status_in({"مسودة", "مسجلة", "مراجعة", "موقعة", "مغلقة"})
            if data.get("status") in {"موقعة", "مغلقة"}: required("signed_by", "signed_at")
            numeric_ranges = {
                "temperature": (25, 45), "pulse": (20, 240), "respiratory_rate": (4, 80),
                "systolic": (50, 260), "diastolic": (20, 160), "spo2": (50, 100), "pain_score": (0, 10),
            }
            for field, (low, high) in numeric_ranges.items():
                value = str(data.get(field, "")).strip()
                if not value:
                    continue
                try:
                    number = float(value)
                except (TypeError, ValueError):
                    raise ValueError(f"قيمة {field} يجب أن تكون رقمًا")
                if not low <= number <= high:
                    raise ValueError(f"قيمة {field} خارج النطاق المقبول")
            systolic = str(data.get("systolic", "")).strip()
            diastolic = str(data.get("diastolic", "")).strip()
            if systolic and diastolic and float(diastolic) >= float(systolic):
                raise ValueError("الضغط الانبساطي يجب أن يكون أقل من الانقباضي")

        if kind == "medication_administrations":
            required("patient_id", "medication", "dose", "route", "scheduled_at")
            status_in({"مجدول", "أُعطي", "مرفوض", "لم يُعط", "ملغى"})
            if data.get("status") == "أُعطي": required("administered_at", "administered_by")
            if data.get("status") in {"مرفوض", "لم يُعط"}: required("reason")
            if data.get("allergy_checked") not in {"تمت المراجعة", "توجد حساسية"}:
                raise ValueError("أكد مراجعة الحساسية قبل جدولة أو إعطاء الدواء")
            if data.get("allergy_checked") == "توجد حساسية" and not str(data.get("allergy_override_reason", "")).strip():
                raise ValueError("سجل سبب تجاوز الحساسية قبل متابعة الدواء")
            if data.get("interaction_reviewed") not in {"تمت المراجعة", "يوجد تداخل"}:
                raise ValueError("أكد مراجعة التداخلات الدوائية قبل جدولة أو إعطاء الدواء")
            if data.get("interaction_reviewed") == "يوجد تداخل" and not str(data.get("interaction_override_reason", "")).strip():
                raise ValueError("سجل سبب تجاوز التداخل الدوائي قبل متابعة الدواء")

        if kind == "prescriptions":
            status_in({"مسودة", "مكتوبة", "مراجعة", "مصروفة", "موقوفة", "ملغاة"})
            if data.get("status") == "مصروفة": required("dispensed_by", "dispensed_at")
            if data.get("status") in {"موقوفة", "ملغاة"}: required("reason")

        if kind == "surgical_safety":
            required("patient_id", "procedure_id", "phase")
            status_in({"مسودة", "تم التحقق", "مكتملة", "استثناء"})
            if data.get("status") == "مكتملة":
                required("identity_confirmed", "site_confirmed", "consent_confirmed", "team_confirmed", "completed_by", "completed_at")

        if kind == "consents":
            required("patient_id", "consent_type", "decision")
            status_in({"مسودة", "مقدمة", "موقعة", "مرفوضة", "مسحوبة"})
            if data.get("status") == "موقعة": required("signed_by", "signed_at")
            if data.get("decision") == "مرفوضة" and not str(data.get("refusal_reason", "")).strip():
                raise ValueError("سجّل سبب رفض الموافقة")

        if kind == "referrals":
            required("patient_id", "destination", "reason", "referred_by")
            status_in({"مسودة", "مطلوبة", "مقبولة", "تمت", "مرفوضة", "ملغاة"})
            if data.get("status") == "تمت": required("outcome", "completed_at")

        if kind == "care_tasks":
            required("task", "assigned_to", "due_at")
            status_in({"جديدة", "قيد التنفيذ", "معلقة", "مكتملة", "ملغاة"})
            if data.get("status") == "مكتملة": required("completed_by", "completed_at")

        if kind == "problem_list":
            required("patient_id", "problem", "recorded_by")
            status_in({"نشطة", "محلولة", "غير نشطة"})
            if data.get("status") == "محلولة": required("resolved_at", "resolution")
            if data.get("code") and not data.get("code_system"):
                raise ValueError("حدد نظام الترميز عند إدخال كود التشخيص")

        if kind == "allergies":
            required("patient_id", "allergen", "reaction", "severity")
            status_in({"مشتبه بها", "متحقق منها", "غير نشطة", "منفية"})
            if data.get("status") == "متحقق منها": required("verified_by", "reviewed_at")

        if kind == "formulary":
            required("generic_name", "strength", "route", "form")
            status_in({"نشط", "موقوف", "منتهي"})
            if data.get("high_alert") not in {None, "", "نعم", "لا"}:
                raise ValueError("اختر قيمة صحيحة للدواء عالي الخطورة")

        if kind == "drug_interactions":
            required("medication_a", "medication_b", "severity", "recommendation")
            if str(data.get("medication_a", "")).strip().casefold() == str(data.get("medication_b", "")).strip().casefold():
                raise ValueError("لا يمكن تسجيل تداخل الدواء مع نفسه")
            status_in({"نشط", "موقوف"})

        if kind == "blood_requests":
            required("patient_id", "component", "blood_group", "units", "requested_by")
            status_in({"مطلوب", "قيد التجهيز", "تم التوافق", "معتمدة", "تم الصرف", "مرفوضة", "ملغاة"})
            try:
                if int(data.get("units", 0)) < 1:
                    raise ValueError
            except (TypeError, ValueError):
                raise ValueError("عدد وحدات الدم يجب أن يكون رقمًا صحيحًا أكبر من صفر")
            if data.get("status") == "تم التوافق": required("crossmatch_result", "crossmatched_at")
            if data.get("status") == "تم الصرف": required("issued_at")

        if kind == "insurance_claims":
            required("patient_id", "payer", "claim_no", "amount")
            status_in({"مسودة", "جاهزة للتقديم", "مقدمة", "قيد المراجعة", "معتمدة", "مرفوضة", "مسددة", "ملغاة"})
            try:
                if float(data.get("amount", 0)) < 0 or (data.get("approved_amount") not in {None, ""} and float(data.get("approved_amount")) < 0):
                    raise ValueError
            except (TypeError, ValueError):
                raise ValueError("مبالغ المطالبة يجب أن تكون أرقامًا غير سالبة")
            if data.get("status") == "معتمدة": required("approved_amount", "approved_at")
            if data.get("status") == "مرفوضة": required("rejected_reason")
            if data.get("status") == "مسددة": required("paid_at")

        if kind == "quality_events":
            required("event_type", "severity", "description", "reported_by")
            status_in({"مسودة", "مبلغ عنها", "قيد المراجعة", "خطة تصحيحية", "مغلقة"})
            if data.get("status") == "قيد المراجعة": required("reviewed_by", "reviewed_at")
            if data.get("status") == "خطة تصحيحية": required("corrective_action", "assigned_to")
            if data.get("status") == "مغلقة": required("corrective_action", "closed_at", "closed_by")

        if kind == "clinical_templates":
            required("template_name", "specialty", "version", "schema_json")
            try:
                version = int(data.get("version", 0))
                schema = json.loads(str(data.get("schema_json", "[]")))
            except (TypeError, ValueError, json.JSONDecodeError) as exc:
                raise ValueError("تعريف قالب التخصص يجب أن يحتوي إصدارًا صحيحًا وschema بصيغة JSON") from exc
            if version < 1 or not isinstance(schema, list) or not 1 <= len(schema) <= 200:
                raise ValueError("قالب التخصص يجب أن يحتوي من 1 إلى 200 حقلًا")
            field_names = set()
            for field in schema:
                if not isinstance(field, dict) or not 1 <= len(str(field.get("name", "")).strip()) <= 80:
                    raise ValueError("كل حقل في قالب التخصص يحتاج اسمًا صحيحًا")
                name = str(field["name"]).strip()
                if name in field_names or any(ch not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_" for ch in name):
                    raise ValueError("أسماء حقول القالب يجب أن تكون فريدة وبأحرف إنجليزية أو شرطة سفلية")
                field_type = str(field.get("type", "text")).strip()
                if field_type not in {"text", "textarea", "number", "date", "datetime-local", "select", "checkbox"}:
                    raise ValueError("نوع حقل القالب غير مدعوم")
                if "options" in field and (not isinstance(field["options"], list) or len(field["options"]) > 100):
                    raise ValueError("خيارات حقل القالب يجب أن تكون قائمة قصيرة")
                field_names.add(name)
            data["schema_json"] = json.dumps(schema, ensure_ascii=False)
            status_in({"مسودة", "تجريبية", "معتمدة", "موقوفة"})
            if data.get("status") == "معتمدة":
                required("approved_by", "approved_at")
            for json_field in ("workflow_json", "print_layout_json"):
                raw_json = str(data.get(json_field, "")).strip()
                if raw_json:
                    try:
                        parsed = json.loads(raw_json)
                    except json.JSONDecodeError as exc:
                        raise ValueError(f"{json_field} يجب أن يكون JSON صحيحًا") from exc
                    if not isinstance(parsed, (dict, list)):
                        raise ValueError(f"{json_field} يجب أن يكون كائنًا أو قائمة JSON")

        if kind == "inventory":
            try:
                quantity = float(data.get("quantity", 0) or 0)
                reorder = float(data.get("reorder_level", 0) or 0)
            except (TypeError, ValueError):
                raise ValueError("الكمية وحد إعادة الطلب يجب أن يكونا أرقامًا")
            if quantity < 0 or reorder < 0:
                raise ValueError("لا يمكن تسجيل كمية سالبة في المخزون")
            if quantity <= reorder and data.get("status") not in {"نفد", "موقوف"}:
                data["status"] = "يحتاج طلب"
            elif not str(data.get("status", "")).strip():
                data["status"] = "متاح"
        if kind == "inventory_movements":
            try:
                quantity = float(data.get("quantity", 0) or 0)
            except (TypeError, ValueError):
                raise ValueError("كمية حركة المخزون يجب أن تكون رقمًا")
            if quantity <= 0:
                raise ValueError("يجب أن تكون كمية الحركة أكبر من صفر")
            if str(data.get("movement_type", "")).strip() not in {"وارد", "منصرف", "تالف", "مرتجع", "تسوية"}:
                raise ValueError("اختر نوع حركة مخزون صحيح")
        if kind == "complaints":
            if len(str(data.get("description", "")).strip()) < 10:
                raise ValueError("اكتب تفاصيل الشكوى بشكل أوضح")
            if data.get("status") == "مغلقة" and not str(data.get("resolution", "")).strip():
                raise ValueError("اكتب الإجراء التصحيحي قبل إغلاق الشكوى")
            rating = str(data.get("satisfaction_rating", "")).strip()
            if rating:
                try:
                    if not 1 <= int(rating) <= 5:
                        raise ValueError
                except (TypeError, ValueError):
                    raise ValueError("تقييم رضا المريض يجب أن يكون من 1 إلى 5")
        if kind == "training":
            if len(str(data.get("user_name", "")).strip()) < 2 or len(str(data.get("module_name", "")).strip()) < 2:
                raise ValueError("اسم المستخدم والوحدة التدريبية مطلوبان")
            score = str(data.get("assessment_score", "")).strip()
            if score:
                try:
                    if not 0 <= float(score) <= 100:
                        raise ValueError
                except (TypeError, ValueError):
                    raise ValueError("درجة التقييم يجب أن تكون بين 0 و100")
        if kind == "prescriptions":
            if data.get("allergy_checked") not in {"تمت المراجعة", "توجد حساسية"}:
                raise ValueError("أكد مراجعة الحساسية قبل حفظ الوصفة")
            if data.get("allergy_checked") == "توجد حساسية" and not str(data.get("allergy_override_reason", "")).strip():
                raise ValueError("سجل سبب تجاوز الحساسية قبل حفظ الوصفة")
            if data.get("interaction_reviewed") not in {"تمت المراجعة", "يوجد تداخل"}:
                raise ValueError("أكد مراجعة التداخلات الدوائية قبل حفظ الوصفة")
            if data.get("interaction_reviewed") == "يوجد تداخل" and not str(data.get("interaction_override_reason", "")).strip():
                raise ValueError("سجل سبب تجاوز التداخل الدوائي قبل حفظ الوصفة")
            if not str(data.get("dose", "")).strip() or not str(data.get("frequency", "")).strip():
                raise ValueError("سجّل الجرعة والتكرار قبل حفظ الوصفة")
        if kind == "procedures":
            status = str(data.get("status", "")).strip()
            if status in {"جاهز", "مؤكد", "بدأ", "مكتمل"}:
                checklist = data.get("preparation_checklist") or []
                if isinstance(checklist, list) and checklist:
                    incomplete = [item for item in checklist if isinstance(item, dict) and item.get("completed") is not True]
                    if incomplete:
                        raise ValueError("لا يمكن نقل الإجراء إلى هذه المرحلة قبل إكمال قائمة التحضير")
            if status == "مكتمل" and not any(str(data.get(key, "")).strip() for key in ("findings", "operative_note", "post_diag")):
                raise ValueError("سجّل نتيجة الإجراء أو المذكرة الجراحية قبل إغلاق الحالة كمكتملة")
            if data.get("discharge_status") in {"خرج", "تم الخروج", "discharged"} and not str(data.get("discharge_instructions", "")).strip():
                raise ValueError("أدخل تعليمات الخروج قبل تسجيل خروج المريض")
        if kind == "devices" and data.get("status") == "تمت الإزالة" and not str(data.get("removed_at", "")).strip():
            raise ValueError("سجّل تاريخ الإزالة قبل إغلاق متابعة الدعامة أو القسطرة")
        if kind == "specimens":
            if data.get("status") == "أُرسلت" and not str(data.get("sent_to_lab", "")).strip():
                raise ValueError("حدّد المعمل المستلم قبل تسجيل إرسال العينة")
            if data.get("status") == "تمت المراجعة" and not all(str(data.get(key, "")).strip() for key in ("result", "reviewed_by", "reviewed_at")):
                raise ValueError("قبل إغلاق المتابعة سجّل النتيجة واسم المراجع وتاريخ المراجعة")

    def _records(self, kind: str, query: dict, user: dict):
        q = str(query.get("q", [""])[0]).strip().lower()
        status = str(query.get("status", [""])[0]).strip()
        limit = min(500, max(1, int(query.get("limit", ["200"])[0])))
        where, args = ["kind=?"], [kind]
        if status: where.append("status=?"); args.append(status)
        if q:
            search_parts = ["lower(coalesce(title,'')) LIKE ?", "lower(coalesce(code,'')) LIKE ?"]
            args.extend([f"%{q}%"] * 2)
            visible_fields = safe_record_fields(kind, user)
            if visible_fields is None:
                search_parts.append("lower(payload_json) LIKE ?")
                args.append(f"%{q}%")
            else:
                for field in sorted(visible_fields):
                    search_parts.append(f"lower(coalesce(json_extract(payload_json, '$.{field}'),'')) LIKE ?")
                    args.append(f"%{q}%")
            where.append("(" + " OR ".join(search_parts) + ")")
        ordering = "CASE priority WHEN 'طارئ' THEN 0 WHEN 'emergency' THEN 0 WHEN 'عاجل' THEN 1 WHEN 'urgent' THEN 1 WHEN 'مستعجل' THEN 2 WHEN 'elevated' THEN 2 ELSE 3 END, json_extract(payload_json,'$.requested_at') ASC, created_at ASC" if kind == "waiting" else "updated_at DESC"
        with connection() as db:
            rows = db.execute(f"SELECT * FROM records WHERE {' AND '.join(where)} ORDER BY {ordering} LIMIT ?", (*args, limit)).fetchall()
        items = [item for row in rows if (item := safe_record(row, user))]
        if kind == "waiting":
            today = datetime.now().date()
            for item in items:
                requested = item["data"].get("requested_at")
                try: item["data"]["actual_days"] = max(0, (today - datetime.fromisoformat(requested[:10]).date()).days)
                except Exception: item["data"]["actual_days"] = 0
        return {"items": items, "total": len(items)}

    def _check_schedule_conflict(self, kind: str, data: dict, exclude_id: str | None = None):
        if kind not in ("appointments", "procedures") or not data.get("scheduled_at"):
            return
        try:
            start = datetime.fromisoformat(str(data["scheduled_at"]).replace("Z", "+00:00"))
        except ValueError:
            raise ValueError("صيغة تاريخ ووقت الحجز غير صحيحة")
        duration = max(1, int(data.get("duration_min") or (30 if kind == "appointments" else 60)))
        end = start.timestamp() + duration * 60
        requested_doctor = str(data.get("doctor") or data.get("surgeon") or "").strip().casefold()
        requested_assistant = str(data.get("assistant") or "").strip().casefold()
        requested_room = str(data.get("room") or "").strip().casefold()
        requested_device = str(data.get("device_id") or data.get("device_code") or data.get("equipment") or "").strip().casefold()
        patient_id = str(data.get("patient_id") or "")
        with connection() as db:
            rows = db.execute("SELECT id,kind,payload_json FROM records WHERE kind IN ('appointments','procedures') AND id<>?", (exclude_id or "",)).fetchall()
        for row in rows:
            existing = json.loads(row["payload_json"])
            if str(existing.get("status", "")).casefold() in ("ملغي", "cancelled", "archived", "مؤجل"):
                continue
            when = existing.get("scheduled_at")
            if not when: continue
            try:
                old_start = datetime.fromisoformat(str(when).replace("Z", "+00:00"))
                old_end = old_start.timestamp() + max(1, int(existing.get("duration_min") or (30 if row["kind"] == "appointments" else 60))) * 60
            except (ValueError, TypeError):
                continue
            if start.timestamp() >= old_end or old_start.timestamp() >= end: continue
            old_doctor = str(existing.get("doctor") or existing.get("surgeon") or "").strip().casefold()
            old_assistant = str(existing.get("assistant") or "").strip().casefold()
            old_room = str(existing.get("room") or "").strip().casefold()
            old_device = str(existing.get("device_id") or existing.get("device_code") or existing.get("equipment") or "").strip().casefold()
            same_patient = patient_id and patient_id == str(existing.get("patient_id") or "")
            same_doctor = requested_doctor and requested_doctor == old_doctor
            same_assistant = requested_assistant and requested_assistant == old_assistant
            same_room = requested_room and requested_room == old_room
            same_device = requested_device and requested_device == old_device
            if same_patient or same_doctor or same_assistant or same_room or same_device:
                resource = "المريض" if same_patient else ("الطبيب" if same_doctor else ("المساعد" if same_assistant else ("الغرفة" if same_room else "الجهاز")))
                raise ValueError(f"تعارض في الموعد: {resource} مرتبط بحجز آخر خلال نفس الفترة")

    def _dashboard(self, user: dict):
        today = facility_today()
        refresh_clinical_followup_alerts()
        if user["role"] in (OWNER, "ADMIN"):
            refresh_storage_alert()
        with connection() as db:
            count = lambda kind, extra="", args=(): db.execute(f"SELECT COUNT(*) FROM records WHERE kind=? {extra}", (kind, *args)).fetchone()[0]
            patients = count("patients")
            wait = count("waiting", "AND status NOT IN ('archived','cancelled','scheduled')")
            urgent = count("waiting", "AND priority IN ('urgent','emergency','عاجل') AND status NOT IN ('archived','cancelled','scheduled')")
            upcoming = db.execute("SELECT * FROM records WHERE kind='appointments' AND substr(json_extract(payload_json,'$.scheduled_at'),1,10)=? ORDER BY json_extract(payload_json,'$.scheduled_at') LIMIT 10", (today,)).fetchall()
            procedures = db.execute("SELECT * FROM records WHERE kind='procedures' AND substr(json_extract(payload_json,'$.scheduled_at'),1,10)=? ORDER BY json_extract(payload_json,'$.scheduled_at') LIMIT 8", (today,)).fetchall()
            rooms = db.execute("SELECT * FROM records WHERE kind='rooms' ORDER BY title").fetchall()
            audits = db.execute("SELECT username,action,entity,summary,created_at FROM audit_log ORDER BY id DESC LIMIT 8").fetchall()
            devices_due = db.execute("SELECT COUNT(*) FROM records WHERE kind='devices' AND status NOT IN ('archived','تمت الإزالة','مفقود') AND date(json_extract(payload_json,'$.removal_due_at'))<=date(?) AND json_extract(payload_json,'$.removal_due_at')<>''", (today,)).fetchone()[0]
            specimens_pending = db.execute("SELECT COUNT(*) FROM records WHERE kind='specimens' AND status IN ('أُرسلت','النتيجة معلقة')").fetchone()[0]
        appointments = [safe_record(row, user) for row in upcoming] if allowed(user, "appointments", "view") else []
        procedures_today = [safe_record(row, user) for row in procedures] if allowed(user, "procedures", "view") else []
        return {
            "patients": patients, "waiting": wait, "urgent": urgent,
            "appointments_today": [item for item in appointments if item],
            "procedures_today": [item for item in procedures_today if item],
            "devices_due_count": devices_due if allowed(user, "devices", "view") else 0,
            "specimens_pending_count": specimens_pending if allowed(user, "specimens", "view") else 0,
            "followup_worklist": dashboard_followup_worklist(user, today),
            "announcements": visible_announcements(user, upcoming_only=True)["items"],
            "rooms": [safe_record(row, user) for row in rooms] if allowed(user, "rooms", "view") else [],
            "activity": [dict(row) for row in audits] if user["role"] in {OWNER, "ADMIN", "AUDITOR_VIEWER"} else [],
            "alerts": list_system_alerts() if user["role"] in {OWNER, "ADMIN"} else [],
        }

    def _operating_board(self, user: dict, query: dict):
        selected = str(query.get("date", [""])[0]).strip() or facility_today()
        try:
            datetime.strptime(selected, "%Y-%m-%d")
        except ValueError:
            raise ValueError("التاريخ المطلوب غير صحيح")
        with connection() as db:
            rows = db.execute("SELECT * FROM records WHERE kind='procedures' AND substr(json_extract(payload_json,'$.scheduled_at'),1,10)=? ORDER BY json_extract(payload_json,'$.scheduled_at'), created_at", (selected,)).fetchall()
        items = [item for row in rows if (item := safe_record(row, user))]
        lanes = {key: [] for key in ("طلب", "تحضير", "جاهز", "مجدول", "مؤكد", "بدأ", "مكتمل", "مؤجل", "ملغي", "أخرى")}
        for item in items:
            status = str(item["data"].get("status") or "أخرى")
            lanes.setdefault(status, []).append(item)
        audit(user, "operating_board_view", "procedures", selected, "عرض لوحة تشغيل العمليات والمناظير")
        return {"date": selected, "items": items, "lanes": lanes}

    def _reports(self, query: dict):
        start = query.get("from", [""])[0]
        end = query.get("to", [""])[0]
        with connection() as db:
            kinds = {row["kind"]: row["n"] for row in db.execute("SELECT kind,COUNT(*) n FROM records GROUP BY kind")}
            waiting = db.execute("SELECT priority,COUNT(*) n FROM records WHERE kind='waiting' AND status NOT IN ('cancelled','scheduled','archived') GROUP BY priority").fetchall()
            no_show = db.execute("SELECT COUNT(*) FROM records WHERE kind='appointments' AND status IN ('no_show','لم يحضر')").fetchone()[0]
            complications = db.execute("SELECT COUNT(*) FROM records WHERE kind='procedures' AND json_extract(payload_json,'$.complications') NOT IN ('','null')").fetchone()[0]
            inventory_low = db.execute("SELECT COUNT(*) FROM records WHERE kind='inventory' AND status NOT IN ('archived','موقوف') AND CAST(COALESCE(json_extract(payload_json,'$.quantity'),'0') AS REAL) <= CAST(COALESCE(json_extract(payload_json,'$.reorder_level'),'0') AS REAL)").fetchone()[0]
            insurance_pending = db.execute("SELECT COUNT(*) FROM records WHERE kind='invoices' AND json_extract(payload_json,'$.claim_status') IN ('مقدم','يحتاج استكمال','submitted','needs_info')").fetchone()[0]
            insurance_claims_pending = db.execute("SELECT COUNT(*) FROM records WHERE kind='insurance_claims' AND status IN ('جاهزة للتقديم','مقدمة','قيد المراجعة')").fetchone()[0]
            blood_requests_pending = db.execute("SELECT COUNT(*) FROM records WHERE kind='blood_requests' AND status IN ('مطلوب','قيد التجهيز','تم التوافق','معتمدة')").fetchone()[0]
            quality_open = db.execute("SELECT COUNT(*) FROM records WHERE kind='quality_events' AND status NOT IN ('مغلقة','archived')").fetchone()[0]
            medication_not_given = db.execute("SELECT COUNT(*) FROM records WHERE kind='medication_administrations' AND status IN ('مرفوض','لم يُعط')").fetchone()[0]
            complaints_open = db.execute("SELECT COUNT(*) FROM records WHERE kind='complaints' AND status NOT IN ('مغلقة','closed','archived')").fetchone()[0]
            today = facility_today()
            maintenance_due = db.execute("SELECT COUNT(*) FROM records WHERE kind='maintenance' AND status NOT IN ('مغلق','archived') AND date(json_extract(payload_json,'$.next_due_at'))<=date(?) AND json_extract(payload_json,'$.next_due_at')<>''", (today,)).fetchone()[0]
            procedure_categories = db.execute("SELECT COALESCE(json_extract(payload_json,'$.category'),'غير محدد') category,COUNT(*) n FROM records WHERE kind='procedures' GROUP BY category ORDER BY n DESC").fetchall()
            training_expired = db.execute("SELECT COUNT(*) FROM records WHERE kind='training' AND status NOT IN ('موقوف','archived') AND date(json_extract(payload_json,'$.expires_at'))<date(?) AND json_extract(payload_json,'$.expires_at')<>''", (today,)).fetchone()[0]
            training_due = db.execute("SELECT COUNT(*) FROM records WHERE kind='training' AND status NOT IN ('موقوف','archived') AND date(json_extract(payload_json,'$.expires_at')) BETWEEN date(?) AND date(?, '+30 day')", (today, today)).fetchone()[0]
            satisfaction = db.execute("SELECT AVG(CAST(json_extract(payload_json,'$.satisfaction_rating') AS REAL)) FROM records WHERE kind='complaints' AND json_extract(payload_json,'$.satisfaction_rating') BETWEEN '1' AND '5'").fetchone()[0]
            total_procs = kinds.get("procedures", 0)
            dates = db.execute("SELECT payload_json FROM records WHERE kind='waiting'").fetchall()
        elapsed = []
        for row in dates:
            try:
                d = json.loads(row[0]).get("requested_at", "")[:10]
                if d: elapsed.append(max(0, (datetime.now().date() - datetime.fromisoformat(d).date()).days))
            except Exception: pass
        return {
            "counts": kinds,
            "waiting_by_priority": [dict(row) for row in waiting],
            "avg_waiting_days": round(sum(elapsed) / len(elapsed), 1) if elapsed else 0,
            "no_show_count": no_show,
            "no_show_percent": round(no_show * 100 / max(1, kinds.get("appointments", 0)), 1),
            "complication_count": complications,
            "complication_percent": round(complications * 100 / max(1, total_procs), 1),
            "inventory_low": inventory_low, "insurance_pending": insurance_pending, "insurance_claims_pending": insurance_claims_pending, "blood_requests_pending": blood_requests_pending, "quality_open": quality_open, "medication_not_given": medication_not_given, "complaints_open": complaints_open, "maintenance_due": maintenance_due,
            "procedure_categories": [dict(row) for row in procedure_categories],
            "training_expired": training_expired, "training_due": training_due, "satisfaction_average": round(float(satisfaction), 2) if satisfaction is not None else 0,
            "range": {"from": start, "to": end},
        }


def build_recovery_kit() -> tuple[bytes, str, str]:
    """Bundle the newest backup with offline recovery instructions; never bundle the key."""
    backups = list(BACKUP_DIR.glob("*.zip")) + list(BACKUP_DIR.glob("*.ucb"))
    backups = [item for item in backups if item.is_file()]
    if not backups:
        raise ValueError("أنشئ نسخة احتياطية أولًا قبل تجهيز حزمة الاسترداد")
    latest = max(backups, key=lambda item: item.stat().st_mtime)
    stamp = facility_now().strftime("%Y-%m-%d_%H-%M-%S")
    kit_name = f"UroCare_Recovery_Kit_{stamp}.zip"
    instructions = """UroCare Suite - USB Recovery Instructions

This kit contains an encrypted UroCare backup and does NOT contain the recovery key.
Keep these three items on USB storage: this recovery-kit ZIP, the separately downloaded
UroCare_Backup_Recovery_Key.txt, and the offline Windows installation ZIP.

If the old non-Windows data drive survived:
1. Install UroCare again and choose the same parent folder containing UroCare.
2. The installer recognizes the existing database and recovery key, makes a safety copy,
   and keeps the existing data in place.

If the old data drive was erased or failed:
1. Install UroCare to a new, empty data folder and complete initial owner setup.
2. Sign in, open Backups > Restore, choose this recovery-kit ZIP, and enter the separate
   recovery key. The app validates the backup and makes a safety backup before restoring.
3. After restore, sign in with the owner account credentials from the backup.

Do not store the recovery key beside the backup unless the USB itself is encrypted and
physically protected. Keep an additional backup copy on a separate device.
"""
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.write(latest, latest.name)
        archive.writestr("RECOVERY-INSTRUCTIONS.txt", instructions)
    return output.getvalue(), kit_name, latest.name


def unwrap_backup_container(upload: bytes, depth: int = 0) -> bytes:
    """Read a ZIP backup or recovery kit, while continuing to accept legacy UCB files."""
    if upload.startswith(b"UROCARE1"):
        return upload
    if depth > 2:
        raise ValueError("ملف الاسترداد يحتوي مستويات ضغط غير مدعومة")
    try:
        with zipfile.ZipFile(io.BytesIO(upload)) as archive:
            members = archive.infolist()
            if not members or any(item.is_dir() or item.filename != Path(item.filename).name or "\\" in item.filename for item in members):
                raise ValueError("ملف ZIP يحتوي مسارات غير مسموحة")
            if any(item.flag_bits & 1 for item in members):
                raise ValueError("لا تستخدم كلمة مرور ZIP؛ محتوى النسخة مشفر بمفتاح الاستعادة")
            for item in members:
                if item.file_size > len(upload) + 1024 * 1024 or item.file_size > max(1024 * 1024, item.compress_size * 2):
                    raise ValueError("حجم محتوى ZIP غير متوقع؛ تأكد من اختيار نسخة UroCare سليمة")
            if len(members) == 1 and members[0].filename.lower().endswith(".ucb"):
                encrypted = archive.read(members[0])
            elif (len(members) == 2
                  and sum(item.filename.lower().endswith((".zip", ".ucb")) for item in members) == 1
                  and sum(item.filename == "RECOVERY-INSTRUCTIONS.txt" for item in members) == 1):
                backup_member = next(item for item in members if item.filename.lower().endswith((".zip", ".ucb")))
                nested = archive.read(backup_member)
                encrypted = unwrap_backup_container(nested, depth + 1) if backup_member.filename.lower().endswith(".zip") else nested
            else:
                raise ValueError("ملف ZIP ليس نسخة احتياطية أو حزمة استرداد UroCare")
    except zipfile.BadZipFile as exc:
        raise ValueError("ملف النسخة ليس ZIP صالحًا أو أنه تالف") from exc
    if not encrypted.startswith(b"UROCARE1"):
        raise ValueError("ملف ZIP لا يحتوي نسخة UroCare صالحة")
    return encrypted


def restore_backup(encrypted: bytes, key_text: str | None, user: dict) -> dict:
    if Fernet is None: raise ValueError("حزمة فك تشفير النسخ غير متاحة")
    encrypted = unwrap_backup_container(encrypted)
    if not encrypted.startswith(b"UROCARE1") or len(encrypted) < 40: raise ValueError("صيغة النسخة غير مدعومة")
    expected_digest = encrypted[8:40].hex()
    token = encrypted[40:]
    key = key_text.encode() if key_text else default_backup_key()
    try:
        raw = Fernet(key).decrypt(token)
    except (InvalidToken, ValueError):
        raise ValueError("تعذر فك النسخة؛ تحقق من مفتاح الاستعادة")
    if not hmac.compare_digest(hashlib.sha256(raw).hexdigest(), expected_digest):
        raise ValueError("فشل التحقق من سلامة النسخة")
    if key_text and len(key) != 44:
        raise ValueError("مفتاح النسخة غير صالح")
    work = Path(tempfile.mkdtemp(prefix="urocare_restore_", dir=DATA_DIR))
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as zf:
            names = zf.namelist()
            if "urocare.sqlite3" not in names or "manifest.json" not in names:
                raise ValueError("ملف النسخة ناقص")
            for name in names:
                path = Path(name)
                if path.is_absolute() or ".." in path.parts:
                    raise ValueError("ملف النسخة يحتوي مسارًا غير آمن")
            manifest = json.loads(zf.read("manifest.json"))
            if manifest.get("app") != "UroCare Suite" or manifest.get("format") != 1:
                raise ValueError("إصدار النسخة غير متوافق")
            zf.extractall(work)
        candidate = work / "urocare.sqlite3"
        check_db = sqlite3.connect(candidate)
        try:
            result = check_db.execute("PRAGMA integrity_check").fetchone()[0]
            if result != "ok": raise ValueError("قاعدة بيانات النسخة تالفة")
            owners = check_db.execute("SELECT COUNT(*) FROM users WHERE role=?", (OWNER,)).fetchone()[0]
            if owners != 2: raise ValueError("النسخة لا تحتوي حسابي المالك المحميين")
            record_columns = {row[1] for row in check_db.execute("PRAGMA table_info(records)")}
            if "revision" not in record_columns:
                check_db.execute("ALTER TABLE records ADD COLUMN revision INTEGER NOT NULL DEFAULT 1")
            # Sessions are installation-specific. Never revive cookies from a backup.
            check_db.execute("DELETE FROM sessions")
            check_db.commit()
            check_db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            check_db.execute("PRAGMA journal_mode=DELETE").fetchone()
        finally:
            check_db.close()
        safety = _create_backup_internal("pre_restore")
        incoming_uploads = work / "uploads"
        with BACKUP_LOCK, DB_LOCK:
            for suffix in ("-wal", "-shm"):
                try: Path(str(DB_PATH) + suffix).unlink()
                except FileNotFoundError: pass
            replacement = DATA_DIR / "urocare.restore.sqlite3"
            shutil.copy2(candidate, replacement)
            os.replace(replacement, DB_PATH)
            restore_uploads = DATA_DIR / "uploads.restore"
            if restore_uploads.exists(): shutil.rmtree(restore_uploads)
            if incoming_uploads.exists(): shutil.copytree(incoming_uploads, restore_uploads)
            else: restore_uploads.mkdir()
            old_uploads = DATA_DIR / "uploads.old"
            if old_uploads.exists(): shutil.rmtree(old_uploads)
            if UPLOAD_DIR.exists(): os.replace(UPLOAD_DIR, old_uploads)
            os.replace(restore_uploads, UPLOAD_DIR)
            if old_uploads.exists(): shutil.rmtree(old_uploads, ignore_errors=True)
            if key_text:
                temp_key = KEY_PATH.with_suffix(".restore.tmp")
                temp_key.write_bytes(key)
                try: os.chmod(temp_key, 0o600)
                except OSError: pass
                os.replace(temp_key, KEY_PATH)
        with connection() as db:
            actor_exists = db.execute("SELECT 1 FROM users WHERE id=? AND username=?", (user["id"], user["username"])).fetchone()
        audit(user if actor_exists else {"id": None, "username": user["username"]}, "backup_restore", "backup", manifest.get("created_at", ""), f"استعادة نسخة؛ نسخة الأمان: {safety['name']}")
        return {"ok": True, "restored_at": now_utc(), "backup_created_at": manifest.get("created_at"), "safety_backup": safety["name"]}
    finally:
        shutil.rmtree(work, ignore_errors=True)


def verify_backup_bytes(upload: bytes, key_text: str | None, name: str, size: int) -> dict:
    """Verify backup bytes without restoring or modifying application data."""
    if Fernet is None:
        raise ValueError("حزمة فك تشفير النسخ غير متاحة")
    try:
        encrypted = unwrap_backup_container(upload)
        if len(encrypted) < 40 or not encrypted.startswith(b"UROCARE1"):
            raise ValueError("صيغة النسخة غير مدعومة")
        expected_digest = encrypted[8:40].hex()
        try:
            key = key_text.encode() if key_text else default_backup_key()
            raw = Fernet(key).decrypt(encrypted[40:])
        except (InvalidToken, ValueError) as exc:
            raise ValueError("تعذر فك النسخة بالمفتاح الحالي") from exc
        actual_digest = hashlib.sha256(raw).hexdigest()
        if not hmac.compare_digest(actual_digest, expected_digest):
            raise ValueError("فشل التحقق من سلامة النسخة")
        work = Path(tempfile.mkdtemp(prefix="urocare_verify_", dir=DATA_DIR))
        try:
            with zipfile.ZipFile(io.BytesIO(raw)) as zf:
                names = zf.namelist()
                if "urocare.sqlite3" not in names or "manifest.json" not in names:
                    raise ValueError("ملف النسخة ناقص")
                archive_bytes = 0
                for member_name in names:
                    member = Path(member_name)
                    if member.is_absolute() or ".." in member.parts:
                        raise ValueError("ملف النسخة يحتوي مسارًا غير آمن")
                    info = zf.getinfo(member_name)
                    if info.file_size > 512 * 1024 * 1024 or archive_bytes + info.file_size > 2 * 1024 * 1024 * 1024:
                        raise ValueError("حجم محتوى النسخة غير متوقع")
                    archive_bytes += info.file_size
                    # Read every member in chunks so ZIP CRC errors and damaged
                    # attachments are detected before the owner trusts the backup.
                    with zf.open(info, "r") as stream:
                        while stream.read(1024 * 1024):
                            pass
                manifest = json.loads(zf.read("manifest.json"))
                if manifest.get("app") != "UroCare Suite" or manifest.get("format") != 1:
                    raise ValueError("إصدار النسخة غير متوافق")
                database = work / "urocare.sqlite3"
                database.write_bytes(zf.read("urocare.sqlite3"))
            check_db = sqlite3.connect(database)
            try:
                integrity = check_db.execute("PRAGMA integrity_check").fetchone()[0]
                if integrity != "ok":
                    raise ValueError("قاعدة بيانات النسخة تالفة")
            finally:
                check_db.close()
            return {
                "ok": True,
                "name": name,
                "size": size,
                "created_at": manifest.get("created_at", ""),
                "kind": manifest.get("kind", ""),
                "database_bytes": database.stat().st_size,
                "members": len(names),
                "archive_bytes": archive_bytes,
                "sha256": actual_digest,
            }
        finally:
            shutil.rmtree(work, ignore_errors=True)
    except (OSError, zipfile.BadZipFile, json.JSONDecodeError, sqlite3.Error) as exc:
        raise ValueError("تعذر فحص النسخة؛ قد يكون الملف تالفًا") from exc


def verify_backup_file(target: Path) -> dict:
    """Verify a stored backup without restoring or modifying application data."""
    try:
        return verify_backup_bytes(target.read_bytes(), None, target.name, target.stat().st_size)
    except OSError as exc:
        raise ValueError("تعذر قراءة ملف النسخة") from exc


def choose_host() -> str:
    if HOST_OVERRIDE: return HOST_OVERRIDE
    return "127.0.0.1"


def main() -> None:
    init_db()
    if getattr(sys, "frozen", False) and (sys.stdout is None or sys.stderr is None):
        log = open(DATA_DIR / "server.log", "a", encoding="utf-8", buffering=1)
        if sys.stdout is None: sys.stdout = log
        if sys.stderr is None: sys.stderr = log
    worker = threading.Thread(target=backup_worker, name="urocare-backups", daemon=True)
    worker.start()
    host = choose_host()
    tls_context, ca_cert_path = create_tls_context()
    server = ThreadingHTTPServer((host, PORT), Handler)
    server.socket = tls_context.wrap_socket(server.socket, server_side=True)
    server.daemon_threads = True
    print(f"UroCare Suite running on https://{host}:{PORT}")
    print(f"Local trust certificate: {ca_cert_path}")
    if host == "127.0.0.1": print("First setup is restricted to this computer.")
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
