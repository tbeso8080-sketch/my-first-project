@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "TARGET=%ProgramData%\UroCare"
if not defined UROCARE_INSTALL_USER_SID (
  for /f "usebackq delims=" %%S in (`powershell.exe -NoProfile -Command "[Security.Principal.WindowsIdentity]::GetCurrent().User.Value"`) do set "UROCARE_INSTALL_USER_SID=%%S"
)
if not exist "%~dp0python.exe" (
  echo Missing python.exe. Extract the complete ZIP package first.
  pause
  endlocal & exit /b 2
)
if not exist "%~dp0app.py" (
  echo Missing app.py. The package is incomplete.
  pause
  endlocal & exit /b 2
)
if not exist "%~dp0verify_portable_package.py" (
  echo Missing package verifier. Do not install this package.
  pause
  endlocal & exit /b 6
)
"%~dp0python.exe" "%~dp0verify_portable_package.py" "%~dp0."
if errorlevel 1 (
  echo Package integrity check failed. Re-download from a trusted source.
  pause
  endlocal & exit /b 7
)
"%~dp0python.exe" -c "import ssl, sqlite3, cryptography, cffi, tzdata; from cryptography.hazmat.bindings import _rust" >nul 2>&1
if errorlevel 1 (
  echo The bundled Python runtime or Windows libraries are damaged or incomplete.
  echo Re-download the complete UroCare ZIP package and extract it again.
  pause
  endlocal & exit /b 3
)
fltmc >nul 2>&1
if errorlevel 1 (
  set "UROCARE_INSTALLER=%~f0"
  powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$p=Start-Process -FilePath $env:UROCARE_INSTALLER -Verb RunAs -Wait -PassThru; exit $p.ExitCode"
  set "UROCARE_EXIT=!errorlevel!"
  endlocal & exit /b !UROCARE_EXIT!
)
if not exist "%TARGET%" mkdir "%TARGET%"
if errorlevel 1 (
  echo Cannot create installation folder: %TARGET%
  pause
  endlocal & exit /b 4
)
robocopy "%~dp0." "%TARGET%" /E /XD "%~dp0data" "%TARGET%\data" /XF "*.zip" >nul
if errorlevel 8 (
  echo Failed to copy UroCare to %TARGET%.
  pause
  endlocal & exit /b 2
)
"%TARGET%\python.exe" -c "import ssl, sqlite3, cryptography, cffi, tzdata; from cryptography.hazmat.bindings import _rust" >nul 2>&1
if errorlevel 1 (
  echo Installed files failed the runtime check. Re-run installation from the complete ZIP.
  pause
  endlocal & exit /b 5
)
"%TARGET%\python.exe" "%TARGET%\verify_portable_package.py" "%TARGET%"
if errorlevel 1 (
  echo Installed package failed its integrity check. Do not start it.
  pause
  endlocal & exit /b 8
)
if not exist "%TARGET%\data" mkdir "%TARGET%\data"
if errorlevel 1 (
  echo Cannot create the protected data folder: %TARGET%\data
  pause
  endlocal & exit /b 9
)
if not defined UROCARE_INSTALL_USER_SID (
  echo Cannot identify the Windows account that will run UroCare.
  echo No application was started. Re-run the installer while signed in as the intended Windows user.
  pause
  endlocal & exit /b 10
)
icacls "%TARGET%" /reset /T /C >nul
if errorlevel 1 (
  echo Could not reset old installation permissions safely.
  pause
  endlocal & exit /b 11
)
icacls "%TARGET%" /inheritance:r /T /C >nul
if errorlevel 1 (
  echo Could not protect the installed program files.
  pause
  endlocal & exit /b 15
)
icacls "%TARGET%" /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" "*S-1-5-32-545:(OI)(CI)RX" /T /C >nul
if errorlevel 1 (
  echo Could not apply the program-file access policy.
  pause
  endlocal & exit /b 16
)
icacls "%TARGET%\data" /remove:g "*S-1-5-32-545" /T /C >nul
if errorlevel 1 (
  echo Could not restrict access to the UroCare data folder.
  pause
  endlocal & exit /b 17
)
icacls "%TARGET%\data" /grant:r "*%UROCARE_INSTALL_USER_SID%:(OI)(CI)M" /T /C >nul
if errorlevel 1 (
  echo Could not grant the installing Windows account access to UroCare data.
  pause
  endlocal & exit /b 18
)
"%TARGET%\python.exe" "%TARGET%\verify_portable_package.py" "%TARGET%"
if errorlevel 1 (
  echo Installed package failed its integrity check. Do not start it.
  pause
  endlocal & exit /b 8
)
echo UroCare was installed to %TARGET%.
echo Program files are read-only for standard Windows users; the data folder is writable by the installing account.
echo Close this installer, then run Start-UroCare.cmd from %TARGET% as your normal Windows user.
echo Do not choose Run as administrator when starting UroCare.
pause
endlocal & exit /b 0
