@echo off
setlocal EnableExtensions
set "PYTHONDONTWRITEBYTECODE=1"
cd /d "%~dp0."
if errorlevel 1 (
  echo Cannot enter the UroCare package folder. Move or re-extract it to a local folder such as C:\UroCare-Portable-Windows.
  pause
  exit /b 9
)
whoami /groups | findstr /c:"S-1-16-12288" /c:"S-1-16-16384" >nul
if not errorlevel 1 echo Notice: UroCare is running with elevated Windows permissions.
if not exist "%~dp0python.exe" (
  echo UroCare portable runtime is missing. Re-extract the complete package.
  pause
  exit /b 2
)
if not exist "%~dp0verify_portable_package.py" (
  echo UroCare package verifier is missing. Do not start this package.
  pause
  exit /b 4
)
"%~dp0python.exe" "%~dp0verify_portable_package.py" .
if errorlevel 1 (
  echo Package integrity check failed. Do not start UroCare; re-download it from a trusted source.
  pause
  exit /b 5
)
if not exist "%~dp0data" mkdir "%~dp0data"
set "UROCARE_DATA_DIR=%~dp0data"
"%~dp0python.exe" -c "import ssl, sqlite3, cryptography, cffi, tzdata; from cryptography.hazmat.bindings import _rust" >nul 2>&1
if errorlevel 1 (
  echo UroCare runtime check failed. Re-extract or reinstall the complete package.
  pause
  exit /b 3
)
echo Starting UroCare at https://127.0.0.1:8765
start "UroCare Server" "%~dp0python.exe" "%~dp0app.py"
set "UROCARE_READY=0"
for /l %%N in (1,1,15) do (
  powershell.exe -NoProfile -Command "$c=New-Object Net.Sockets.TcpClient; try {$c.Connect('127.0.0.1',8765); $c.Close(); exit 0} catch {exit 1}" >nul 2>&1
  if not errorlevel 1 (
    set "UROCARE_READY=1"
    goto :urocare_ready
  )
  timeout /t 1 /nobreak >nul
)
:urocare_ready
if "%UROCARE_READY%" neq "1" (
  echo UroCare server did not start on port 8765.
  echo Check the separate UroCare Server window for the exact error.
  pause
  exit /b 10
)
start "" "https://127.0.0.1:8765"
endlocal
