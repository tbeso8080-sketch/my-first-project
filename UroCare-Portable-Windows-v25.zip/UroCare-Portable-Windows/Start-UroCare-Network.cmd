@echo off
setlocal EnableExtensions
cd /d "%~dp0."
if errorlevel 1 (
  echo Cannot enter the UroCare package folder.
  pause
  exit /b 9
)
set "UROCARE_HOST=0.0.0.0"
echo Network mode: UroCare will listen on this computer's private network address.
echo Use the server computer name or private IP with port 8765 from trusted devices only.
call "%~dp0Start-UroCare.cmd"
set "RESULT=%errorlevel%"
endlocal & exit /b %RESULT%
